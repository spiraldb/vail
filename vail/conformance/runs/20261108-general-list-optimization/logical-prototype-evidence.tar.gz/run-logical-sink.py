import pathlib, subprocess, json, os, hashlib, psutil, signal, statistics

root = pathlib.Path('/private/tmp/vail-general-list-20261108/logical-sink')
root.mkdir()
exe = pathlib.Path('/private/tmp/vail-split-sort-target/release/examples/logical_list_cost')
source = pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail')
paths = [
    'crates/vail-execution/src/logical_lists.rs',
    'crates/vail-execution/src/logical_expr.rs',
    'crates/vail-execution/src/expressions.rs',
    'crates/vail-execution/src/list_flatmap.rs',
    'crates/vail-execution/examples/logical_list_cost.rs',
]
pins = {
    'source': {p: hashlib.sha256((source / p).read_bytes()).hexdigest() for p in paths},
    'executable': hashlib.sha256(exe.read_bytes()).hexdigest(),
    'scope': 'Generated public two-projection experiment, not Hail workload. Full Arrow oracle before timing. Preparation and evaluation wall measured; CPU unmeasured.',
    'modes': {
        'before': {'VAIL_DISABLE_LOGICAL_LIST_FUSION': '1'},
        'logical': {},
        'sink': {'VAIL_EXPERIMENT_MAP_FILTER_SINK': '1'},
    },
}
(root / 'pins.json').write_text(json.dumps(pins, indent=2))
records = []
summaries = []
for case in ['maps', 'filter_map', 'identity', 'single']:
    for rows in [1, 16, 4096]:
        for i, mode in enumerate(['before', 'logical', 'sink', 'sink', 'logical', 'before', 'before', 'logical', 'sink', 'sink', 'logical', 'before']):
            assert hashlib.sha256(exe.read_bytes()).hexdigest() == pins['executable']
            out = root / f'{case}-{rows}-{i}-{mode}'
            out.mkdir()
            env = {k: v for k, v in os.environ.items() if not k.startswith('VAIL_')}
            env.update(RAYON_NUM_THREADS='4', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
            env.update(pins['modes'][mode])
            process = None
            try:
                with (out / 'stdout').open('w') as stdout, (out / 'stderr').open('w') as stderr:
                    process = subprocess.Popen([str(exe), case, str(rows)], env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                    birth = psutil.Process(process.pid).create_time()
                    code = process.wait(timeout=20)
            finally:
                if process is not None:
                    if process.poll() is None:
                        assert psutil.Process(process.pid).create_time() == birth and os.getpgid(process.pid) == process.pid
                        os.killpg(process.pid, signal.SIGTERM)
                        process.wait(timeout=3)
                    try:
                        os.killpg(process.pid, 0)
                        raise RuntimeError('Process group remains; stop')
                    except ProcessLookupError:
                        pass
                    (out / 'exit.json').write_text(json.dumps({'returncode': process.returncode, 'group_absent': True}))
            assert code == 0, (case, rows, mode, (out / 'stderr').read_text()[-2500:])
            record = json.loads((out / 'stdout').read_text())
            assert record['validated'] and record['disabled'] == (mode == 'before')
            record.update(mode=mode, process=i)
            records.append(record)
            (root / 'records.json').write_text(json.dumps(records, indent=2))
        summary = {'case': case, 'rows': rows}
        for field in ['prepare_seconds', 'prepare_plus_first_seconds', 'evaluation_wall_seconds']:
            values = {
                mode: statistics.median(
                    statistics.median(r[field]) if isinstance(r[field], list) else r[field]
                    for r in records if r['case'] == case and r['rows'] == rows and r['mode'] == mode
                ) for mode in pins['modes']
            }
            for mode in ['logical', 'sink']:
                values[mode + '_over_before'] = values[mode] / values['before']
            summary[field] = values
        summaries.append(summary)
        (root / 'summary.json').write_text(json.dumps(summaries, indent=2))
        print(json.dumps(summary), flush=True)
assert {p: hashlib.sha256((source / p).read_bytes()).hexdigest() for p in paths} == pins['source']
(root / 'complete.json').write_text(json.dumps({'processes': len(records), 'all_oracles_pass': True, 'post_source_and_executable_pins': True}))
