//! Public projection pipelines, with fixture construction and validation untimed.
use arrow_array::{Array, ArrayRef, Int32Array, ListArray, RecordBatch, StructArray};
use arrow_buffer::{NullBuffer, OffsetBuffer};
use arrow_schema::{DataType, Field, Schema, SchemaRef};
use datafusion_expr::{
    LogicalPlan, LogicalPlanBuilder, execution_props::ExecutionProps,
    logical_plan::builder::LogicalTableSource, physical_planning_context::PhysicalPlanningContext,
};
use datafusion_optimizer::{Optimizer, optimizer::OptimizerContext};
use datafusion_physical_expr::{PhysicalExpr, create_physical_expr};
use serde_json::{Value, json};
use std::{
    sync::Arc,
    time::{Duration, Instant},
};
use vail_execution::{
    expressions::Expr,
    logical_expr::{lower_logical, prepare_list_regions},
};

enum Program {
    Input,
    Projection {
        input: Box<Program>,
        schema: SchemaRef,
        expressions: Vec<Arc<dyn PhysicalExpr>>,
    },
}
impl Program {
    fn prepare(plan: &LogicalPlan) -> Self {
        match plan {
            LogicalPlan::TableScan(_) => Self::Input,
            LogicalPlan::SubqueryAlias(alias) => Self::prepare(&alias.input),
            LogicalPlan::Projection(projection) => {
                let expressions = projection
                    .expr
                    .iter()
                    .map(|expression| {
                        let expression =
                            prepare_list_regions(expression.clone(), projection.input.schema())
                                .unwrap();
                        create_physical_expr(
                            &expression,
                            projection.input.schema(),
                            &ExecutionProps::new(),
                            &PhysicalPlanningContext::default(),
                        )
                        .unwrap()
                    })
                    .collect();
                Self::Projection {
                    input: Box::new(Self::prepare(&projection.input)),
                    schema: Arc::new(projection.schema.as_arrow().clone()),
                    expressions,
                }
            }
            other => panic!("unexpected operator in projection-only experiment: {other:?}"),
        }
    }
    fn evaluate(&self, batch: &RecordBatch) -> RecordBatch {
        match self {
            Self::Input => batch.clone(),
            Self::Projection {
                input,
                schema,
                expressions,
            } => {
                let input = input.evaluate(batch);
                let columns = expressions
                    .iter()
                    .map(|expression| {
                        expression
                            .evaluate(&input)
                            .unwrap()
                            .into_array(input.num_rows())
                            .unwrap()
                    })
                    .collect();
                RecordBatch::try_new(schema.clone(), columns).unwrap()
            }
        }
    }
}
fn variable(name: &str) -> Value {
    json!({"op":"lambda_variable","name":name})
}
fn integer(value: i32) -> Value {
    json!({"op":"literal","dtype":"int32","value":value})
}
fn binary(operator: &str, left: Value, right: Value) -> Value {
    json!({"op":"binary","operator":operator,"left":left,"right":right})
}
fn map(value: Value, parameter: &str, body: Value) -> Value {
    json!({"op":"array_map","value":value,"parameter":parameter,"body":body})
}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    let case = args.get(1).map(String::as_str).unwrap_or("maps");
    let rows: usize = args.get(2).map(|s| s.parse().unwrap()).unwrap_or(4096);
    let width = 32;
    let mut input_values = vec![];
    let mut expected_values = vec![];
    let mut offsets = vec![0i32];
    let mut expected_offsets = vec![0i32];
    let mut validity = vec![];
    for row in 0..rows {
        let valid = row % 17 != 16;
        validity.push(valid);
        for column in 0..width {
            let index = row * width + column;
            let value = (index % 31 != 30).then_some(((index * 17 + row * 13) % 1000) as i32 - 500);
            input_values.push(value);
            if valid {
                let value = value.map(|v| if case == "identity" { v } else { v + 1 });
                match case {
                    "filter_map" => {
                        if let Some(value) = value.filter(|v| *v > 0) {
                            expected_values.push(Some(value));
                        }
                    }
                    "maps" => expected_values.push(value.map(|v| v * 3)),
                    "identity" | "single" => expected_values.push(value),
                    _ => panic!("unknown case"),
                }
            }
        }
        offsets.push(input_values.len() as i32);
        expected_offsets.push(expected_values.len() as i32);
    }
    let input: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(offsets.into()),
        Arc::new(Int32Array::from(input_values)),
        Some(NullBuffer::from(validity.clone())),
    ));
    let batch = RecordBatch::try_new(
        Arc::new(Schema::new(vec![Field::new(
            "xs",
            input.data_type().clone(),
            true,
        )])),
        vec![input],
    )
    .unwrap();
    let expected_values: ArrayRef = if case == "filter_map" {
        let numbers: ArrayRef = Arc::new(Int32Array::from(expected_values.clone()));
        let twice: ArrayRef = Arc::new(Int32Array::from_iter(
            expected_values.iter().map(|v| v.map(|v| v * 2)),
        ));
        Arc::new(StructArray::new(
            vec![
                Arc::new(Field::new("value", DataType::Int32, true)),
                Arc::new(Field::new("twice", DataType::Int32, true)),
            ]
            .into(),
            vec![numbers, twice],
            None,
        ))
    } else {
        Arc::new(Int32Array::from(expected_values))
    };
    let expected = ListArray::new(
        Arc::new(Field::new_list_field(
            expected_values.data_type().clone(),
            true,
        )),
        OffsetBuffer::new(expected_offsets.into()),
        expected_values,
        Some(NullBuffer::from(validity)),
    );
    let first: Expr = serde_json::from_value(map(
        json!({"op":"column","name":"xs"}),
        "x",
        if case == "identity" {
            variable("x")
        } else {
            binary("add", variable("x"), integer(1))
        },
    ))
    .unwrap();
    let second: Expr = serde_json::from_value(if case == "filter_map" {
        map(
            json!({"op":"array_filter","value":{"op":"column","name":"middle"},"parameter":"y",
            "predicate":binary("gt",variable("y"),integer(0))}),
            "z",
            json!({"op":"struct","fields":[
                ["value",variable("z")],["twice",binary("mul",variable("z"),integer(2))]]}),
        )
    } else {
        map(
            json!({"op":"column","name":"middle"}),
            "y",
            if case == "identity" {
                variable("y")
            } else {
                binary("mul", variable("y"), integer(3))
            },
        )
    })
    .unwrap();
    let start = Instant::now();
    let source = LogicalPlanBuilder::scan(
        "input",
        Arc::new(LogicalTableSource::new(batch.schema())),
        None,
    )
    .unwrap()
    .build()
    .unwrap();
    let first = lower_logical(&first, source.schema())
        .unwrap()
        .alias(if case == "single" { "out" } else { "middle" });
    let first = LogicalPlanBuilder::from(source)
        .project(vec![first])
        .unwrap()
        .build()
        .unwrap();
    let plan = if case == "single" {
        first
    } else {
        let second = lower_logical(&second, first.schema()).unwrap().alias("out");
        LogicalPlanBuilder::from(first)
            .project(vec![second])
            .unwrap()
            .build()
            .unwrap()
    };
    let plan = Optimizer::new()
        .optimize(plan, &OptimizerContext::new(), |_, _| {})
        .unwrap();
    let program = Program::prepare(&plan);
    let preparation = start.elapsed().as_secs_f64();
    let start = Instant::now();
    let output = program.evaluate(&batch);
    let first_evaluation = start.elapsed().as_secs_f64();
    assert_eq!(output.column(0).as_ref(), &expected);
    let mut samples = vec![];
    for _ in 0..5 {
        let start = Instant::now();
        let mut count = 0;
        while start.elapsed() < Duration::from_millis(20) {
            std::hint::black_box(program.evaluate(&batch));
            count += 1;
        }
        samples.push(start.elapsed().as_secs_f64() / count as f64);
    }
    println!(
        "{}",
        json!({"case":case,"rows":rows,"width":width,"validated":true,
        "disabled":std::env::var_os("VAIL_DISABLE_LOGICAL_LIST_FUSION").is_some(),
        "prepare_seconds":preparation,"first_evaluation_seconds":first_evaluation,
        "prepare_plus_first_seconds":preparation+first_evaluation,"evaluation_wall_seconds":samples,
        "optimized_plan":plan.display_indent().to_string()})
    );
}
