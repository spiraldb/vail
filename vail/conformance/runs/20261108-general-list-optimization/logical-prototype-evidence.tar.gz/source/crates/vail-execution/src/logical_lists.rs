//! Keep ordinary list operations visible until relational projections combine.
use super::*;
use datafusion_common::datatype::FieldExt;
use datafusion_common::tree_node::TreeNodeRecursion;
use datafusion_common::tree_node::{Transformed, TreeNode};
use datafusion_expr::expr::{HigherOrderFunction, Lambda, LambdaVariable};
use std::collections::HashMap;

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
struct CallbackKey {
    native: crate::expression_identity::Identity,
    body: Arc<LogicalExpr>,
    field: arrow_schema::FieldRef,
    slot: String,
    options: crate::expressions::PreparationOptions,
    output: DataType,
}

pub(super) type Analysis = Option<Arc<HashSet<String>>>;

fn analyze(body: &Expr, shared: &HashSet<usize>) -> Analysis {
    let mut names = HashSet::new();
    let mut seen = HashSet::new();
    let mut pending = vec![body];
    while let Some(node) = pending.pop() {
        if !seen.insert(node as *const Expr as usize) { continue; }
        if shared.contains(&(node as *const Expr as usize))
            || crate::expression_effects::own_effect(node) != crate::expression_effects::Effects::Pure
            || matches!(node, Expr::Column { .. } | Expr::Global { .. } | Expr::ExternalGlobal { .. }) {
            return None;
        }
        if let Expr::LambdaVariable { name, .. } = node {
            names.insert(name.clone()); if names.len() > 1 { return None; }
        }
        let mut index = 0;
        let mut binder = false;
        node.for_each_child(&mut |child| {
            binder |= !node.child_binders(index).is_empty();
            index += 1; pending.push(child);
        });
        if binder { return None; }
    }
    Some(Arc::new(names))
}

// A virtual Call/Locus/Set/Dict accessor may validate or normalize its input.
// Only ordinary struct/tuple reads participate in this initial container rule.
fn ordinary_fields(body: &Expr, parameter: &str, element: &Type) -> bool {
    fn resolve<'a>(
        node: &Expr,
        parameter: &str,
        element: &'a Type,
        memo: &mut HashMap<usize, Option<&'a Type>>,
        fields: &mut HashMap<usize, HashMap<&'a str, &'a Type>>,
    ) -> Option<&'a Type> {
        let key = node as *const Expr as usize;
        if let Some(value) = memo.get(&key) {
            return *value;
        }
        let value = match node {
            Expr::LambdaVariable { name, .. } | Expr::Column { name } if name == parameter => {
                Some(element)
            }
            Expr::GetField { value, name } => {
                match resolve(value, parameter, element, memo, fields) {
                    Some(Type::Struct { r#struct }) => {
                        let index = fields.entry(r#struct.as_ptr() as usize).or_insert_with(|| {
                            let mut index = HashMap::new();
                            for (name, ty) in r#struct {
                                index.entry(name.as_str()).or_insert(ty);
                            }
                            index
                        });
                        index.get(name.as_str()).copied()
                    }
                    Some(Type::Tuple { tuple }) => name
                        .strip_prefix("__vail_tuple_")
                        .and_then(|s| s.parse::<usize>().ok())
                        .and_then(|i| tuple.get(i)),
                    _ => None,
                }
            }
            _ => None,
        };
        memo.insert(key, value);
        value
    }
    let mut memo = HashMap::new();
    let mut fields = HashMap::new();
    let mut allowed = true;
    body.visit_unique(&mut |node| match node {
        Expr::GetField { .. } => {
            allowed &= resolve(node, parameter, element, &mut memo, &mut fields).is_some()
        }
        Expr::LambdaVariable {
            dtype: Some(declared),
            ..
        } => allowed &= declared == element,
        _ => {}
    });
    allowed
}

pub(super) fn lower_list(
    expression: &Expr,
    schema: &DFSchema,
    globals: &Schema,
    bindings: &BTreeMap<String, usize>,
    scope: &[String],
    context: &LoweringContext,
) -> Result<Option<LogicalExpr>, ExprError> {
    if !context.visible_lists || !scope.is_empty() {
        return Ok(None);
    }
    let (value, parameter, body, filter) = match expression {
        Expr::ArrayMap {
            value,
            parameter,
            body,
        } => (value, parameter, body, false),
        Expr::ArrayFilter {
            value,
            parameter,
            predicate,
        } => (value, parameter, predicate, true),
        _ => return Ok(None),
    };
    let analysis = context
        .list_analysis
        .borrow_mut()
        .entry(body.as_ref() as *const Expr as usize)
        .or_insert_with(|| analyze(body, &context.shared))
        .clone();
    let Some(reserved) = analysis else {
        return Ok(None);
    };
    if reserved.len() != 1 || !reserved.contains(parameter) {
        return Ok(None);
    }
    // Existing direct-output flatmaps retain their current preparation path.
    let mut source = value.as_ref();
    let mut visited = Vec::new();
    let allowed = loop {
        let key = source as *const Expr as usize;
        if let Some(allowed) = context.list_spines.borrow().get(&key) {
            break *allowed;
        }
        visited.push(key);
        match source {
            Expr::ArrayMap { value, .. } | Expr::ArrayFilter { value, .. } => source = value,
            Expr::ArrayFlatten { .. } | Expr::ArrayFold { .. } => break false,
            _ => break true,
        }
    };
    context
        .list_spines
        .borrow_mut()
        .extend(visited.into_iter().map(|key| (key, allowed)));
    if !allowed {
        return Ok(None);
    }
    let input = lower(value, schema, globals, bindings, scope, context)?;
    let input_type = if let Some(dtype) = context
        .arrow_types
        .borrow()
        .get(&(value.as_ref() as *const Expr as usize))
    {
        dtype.clone()
    } else {
        input.get_type(schema)?
    };
    let logical_type = Type::from_arrow(&input_type)?;
    if logical_type.to_arrow()? != input_type {
        return Ok(None);
    }
    let Type::Array {
        array: element_type,
    } = logical_type
    else {
        return Ok(None);
    };
    if !ordinary_fields(body, parameter, &element_type) {
        return Ok(None);
    }
    let DataType::List(element) = &input_type else {
        return Ok(None);
    };
    let mut name = "__vail_lambda".to_owned();
    while reserved.contains(&name) {
        name.push('_');
    }
    // Admission above excludes nested binders: every occurrence of this name
    // belongs to this callback. Column/Global/ExternalGlobal remain separate.
    fn rename(
        node: &Expr,
        shared: bool,
        old: &str,
        name: &str,
        memo: &mut HashMap<usize, Arc<Expr>>,
    ) -> Result<RebuiltExpr, ExprError> {
        let key = node as *const Expr as usize;
        if shared {
            if let Some(cached) = memo.get(&key) {
                return Ok(RebuiltExpr::Shared(cached.clone()));
            }
        }
        let value = if let Expr::LambdaVariable { name: variable, .. } = node {
            if variable == old {
                Expr::Column {
                    name: name.to_owned(),
                }
            } else {
                node.clone()
            }
        } else {
            node.try_map_children_rebuilt(|child, shared| rename(child, shared, old, name, memo))?
        };
        if shared {
            let value = Arc::new(value);
            memo.insert(key, value.clone());
            Ok(RebuiltExpr::Shared(value))
        } else {
            Ok(RebuiltExpr::Owned(value))
        }
    }
    let native_body = rename(body, false, parameter, &name, &mut HashMap::new())?.into_owned();
    let parameter_field = element.clone().renamed(&name);
    let frame = DFSchema::try_from(Schema::new(vec![parameter_field]))?;
    let expected_type = native_body.dtype(frame.as_arrow())?.to_arrow()?;
    let callback_context = LoweringContext::new(&native_body, true, context.options.clone());
    let body = lower(
        &native_body,
        &frame,
        &Schema::empty(),
        &BTreeMap::new(),
        &[],
        &callback_context,
    )?;
    let body = coerce_type(body, expected_type.clone(), &frame)?;
    let mut opaque = false;
    body.apply(|node| {
        opaque |= matches!(node, LogicalExpr::ScalarFunction(call) if semantic_kernel(&call.func).is_some());
        Ok(datafusion_common::tree_node::TreeNodeRecursion::Continue)
    })?;
    if opaque {
        return Ok(None);
    }
    let body = body.transform_up(|node| {
        Ok(if matches!(&node,LogicalExpr::Column(column) if column.name == name && column.relation.is_none()) {
            Transformed::yes(LogicalExpr::LambdaVariable(LambdaVariable::new(name.clone(),Some(element.clone()))))
        } else { Transformed::no(node) })
    })?.data;
    let key = CallbackKey {
        native: crate::expression_identity::Identity::new(native_body),
        body: Arc::new(body.clone()),
        field: element.clone(),
        slot: name.clone(),
        options: context.options.clone(),
        output: expected_type.clone(),
    };
    let mut marker_options = context.options.clone();
    marker_options.cache_return_field = true;
    let marker = crate::kernel_identity::scalar_with_options(
        "vail_list_callback",
        key,
        Signature::exact(vec![expected_type.clone()], Volatility::Immutable),
        expected_type.clone(),
        Arc::new(|args| Ok(args.args[0].clone())),
        Some(marker_options),
    );
    let body = marker.call(vec![body]);
    let function = if filter {
        datafusion_functions_nested::array_filter::array_filter_higher_order_function()
    } else {
        datafusion_functions_nested::array_transform::array_transform_higher_order_function()
    };
    let invocation = LogicalExpr::HigherOrderFunction(HigherOrderFunction::new(
        function,
        vec![input, LogicalExpr::Lambda(Lambda::new(vec![name], body))],
    ));
    let output_type = if filter {
        input_type
    } else {
        DataType::List(Arc::new(arrow_schema::Field::new_list_field(
            expected_type,
            true,
        )))
    };
    context
        .arrow_types
        .borrow_mut()
        .insert(expression as *const Expr as usize, output_type);
    Ok(Some(invocation))
}

pub(super) type FieldCache = HashMap<usize, Arc<StructDescriptor>>;
pub(super) struct StructDescriptor {
    dtype: DataType,
    identity: usize,
    fingerprint: u64,
    indices: HashMap<String, usize>,
}
impl StructDescriptor {
    fn matches(&self, dtype: &DataType) -> bool {
        matches!(dtype, DataType::Struct(fields) if fields.as_ptr() as usize == self.identity)
            || dtype == &self.dtype
    }
}
struct StructField {
    parent: Arc<StructDescriptor>,
    index: usize,
    output: arrow_schema::FieldRef,
    signature: Signature,
    name: String,
}
impl std::fmt::Debug for StructField {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.name)
    }
}
impl PartialEq for StructField {
    fn eq(&self, other: &Self) -> bool {
        self.index == other.index
            && self.parent.fingerprint == other.parent.fingerprint
            && self.parent.matches(&other.parent.dtype)
    }
}
impl Eq for StructField {}
impl std::hash::Hash for StructField {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        std::hash::Hash::hash(&self.parent.fingerprint, state);
        std::hash::Hash::hash(&self.index, state);
    }
}
impl datafusion_expr::ScalarUDFImpl for StructField {
    fn name(&self) -> &str {
        &self.name
    }
    fn signature(&self) -> &Signature {
        &self.signature
    }
    fn return_type(&self, args: &[DataType]) -> DfResult<DataType> {
        if args.len() != 1 || !self.parent.matches(&args[0]) {
            return Err(DataFusionError::Plan(
                "ordinary field input type changed".into(),
            ));
        }
        Ok(self.output.data_type().clone())
    }
    fn return_field_from_args(
        &self,
        args: datafusion_expr::ReturnFieldArgs,
    ) -> DfResult<arrow_schema::FieldRef> {
        if args.arg_fields.len() != 1 || !self.parent.matches(args.arg_fields[0].data_type()) {
            return Err(DataFusionError::Plan(
                "ordinary field input descriptor changed".into(),
            ));
        }
        Ok(self.output.clone())
    }
    fn invoke_with_args(
        &self,
        args: datafusion_expr::ScalarFunctionArgs,
    ) -> DfResult<ColumnarValue> {
        let scalar = matches!(&args.args[0], ColumnarValue::Scalar(_));
        let value = args.args[0]
            .clone()
            .into_array(if scalar { 1 } else { args.number_rows })?;
        let parent = value
            .as_any()
            .downcast_ref::<StructArray>()
            .ok_or_else(|| {
                DataFusionError::Execution("ordinary field requires struct input".into())
            })?;
        let child = parent.column(self.index);
        let output = if parent.null_count() == 0 || child.data_type() == &DataType::Null {
            child.clone()
        } else {
            if matches!(
                child.data_type(),
                DataType::Union(..) | DataType::RunEndEncoded(..)
            ) {
                return Err(DataFusionError::Execution(
                    "field layout cannot carry a validity mask".into(),
                ));
            }
            let nulls = NullBuffer::union(parent.nulls(), child.nulls());
            // SAFETY: a valid StructArray gives parent and child equal logical
            // lengths, including slices. The union only clears validity bits;
            // the valid child's type, values, offsets and children stay intact.
            // Admitted canonical layouts support validity; maskless layouts are
            // also rejected above if an unexpected physical input reaches here.
            let data = unsafe {
                child
                    .to_data()
                    .into_builder()
                    .nulls(nulls)
                    .build_unchecked()
            };
            make_array(data)
        };
        if scalar {
            crate::expressions::scalar_at(&output, 0)
                .map(ColumnarValue::Scalar)
                .map_err(|e| DataFusionError::Execution(e.to_string()))
        } else {
            Ok(ColumnarValue::Array(output))
        }
    }
}

// Unlike DF's ordinary get_field, a Hail read includes its ancestors' validity.
// Indices, descriptor identity and result Field are prepared once per callback.
pub(super) fn field(
    expression: &Expr,
    source: &Expr,
    input: LogicalExpr,
    name: &str,
    schema: &DFSchema,
    context: &LoweringContext,
) -> Result<LogicalExpr, ExprError> {
    use std::hash::{Hash, Hasher};
    let input_type = if let Some(dtype) = context
        .arrow_types
        .borrow()
        .get(&(source as *const Expr as usize))
    {
        dtype.clone()
    } else {
        input.get_type(schema)?
    };
    let DataType::Struct(fields) = &input_type else {
        return Err(ExprError::Invalid(
            "ordinary field requires struct input".into(),
        ));
    };
    let identity = fields.as_ptr() as usize;
    let descriptor = context
        .field_descriptors
        .borrow_mut()
        .entry(identity)
        .or_insert_with(|| {
            let mut indices = HashMap::new();
            for (index, field) in fields.iter().enumerate() {
                indices.entry(field.name().clone()).or_insert(index);
            }
            let mut hash = std::collections::hash_map::DefaultHasher::new();
            input_type.hash(&mut hash);
            Arc::new(StructDescriptor {
                dtype: input_type.clone(),
                identity,
                fingerprint: hash.finish(),
                indices,
            })
        })
        .clone();
    let index = *descriptor
        .indices
        .get(name)
        .ok_or_else(|| ExprError::Invalid(format!("struct field {name:?} absent")))?;
    let output_type = fields[index].data_type().clone();
    context
        .arrow_types
        .borrow_mut()
        .insert(source as *const Expr as usize, input_type);
    context
        .arrow_types
        .borrow_mut()
        .insert(expression as *const Expr as usize, output_type.clone());
    let function = datafusion_expr::ScalarUDF::from(StructField {
        parent: descriptor,
        index,
        output: Arc::new(arrow_schema::Field::new("", output_type, true)),
        signature: Signature::any(1, Volatility::Immutable),
        name: format!("vail_struct_field_{index}"),
    });
    Ok(function.call(vec![input]))
}

struct Callback<'a> {
    key: &'a CallbackKey,
    filter: bool,
    input: DataType,
    output: DataType,
    source: &'a LogicalExpr,
}
fn callback(expression: &LogicalExpr) -> Option<Callback<'_>> {
    use datafusion_functions_nested::{array_filter::ArrayFilter, array_transform::ArrayTransform};
    let LogicalExpr::HigherOrderFunction(function) = expression else {
        return None;
    };
    let implementation: &dyn std::any::Any = function.func.inner().as_ref();
    let filter = if implementation.is::<ArrayFilter>() {
        true
    } else if implementation.is::<ArrayTransform>() {
        false
    } else {
        return None;
    };
    let [source, LogicalExpr::Lambda(lambda)] = function.args.as_slice() else {
        return None;
    };
    let LogicalExpr::ScalarFunction(marker) = lambda.body.as_ref() else {
        return None;
    };
    let scalar = marker
        .func
        .inner()
        .downcast_ref::<crate::kernel_identity::Scalar<CallbackKey>>()?;
    let key = scalar.key();
    let [body] = marker.args.as_slice() else {
        return None;
    };
    if lambda.params.as_slice() != [key.slot.as_str()] || body != key.body.as_ref() {
        return None;
    }
    let input = DataType::List(key.field.clone());
    let output = if filter {
        input.clone()
    } else {
        DataType::List(Arc::new(arrow_schema::Field::new_list_field(
            key.output.clone(),
            true,
        )))
    };
    Some(Callback {
        key,
        filter,
        input,
        output,
        source,
    })
}

enum Candidate {
    None,
    Declined,
    Prepared(LogicalExpr),
}
fn prepare_region(expression: &LogicalExpr, schema: &DFSchema) -> Candidate {
    let Some(first) = callback(expression) else {
        return Candidate::None;
    };
    let options = first.key.options.clone();
    let output = first.output.clone();
    let mut stages = vec![first];
    loop {
        let previous = stages.last().unwrap();
        let Some(next) = callback(previous.source) else {
            break;
        };
        if next.output != previous.input || next.key.options != options {
            return Candidate::Declined;
        }
        stages.push(next);
    }
    let last = stages.last().unwrap();
    let source = last.source;
    // Infer only the one leaf and complete region, not every nested suffix.
    if source.get_type(schema).ok().as_ref() != Some(&last.input)
        || expression.get_type(schema).ok().as_ref() != Some(&output)
    {
        return Candidate::Declined;
    }
    let input_type = last.input.clone();
    let options = if stages.len() > 1 { options.for_composed_lists() } else { options };
    fn rebind(
        node: &Expr,
        shared: bool,
        slot: &str,
        name: &str,
        memo: &mut HashMap<usize, Arc<Expr>>,
    ) -> Result<RebuiltExpr, ExprError> {
        let key = node as *const Expr as usize;
        if shared {
            if let Some(value) = memo.get(&key) {
                return Ok(RebuiltExpr::Shared(value.clone()));
            }
        }
        let value = if matches!(node, Expr::Column { name } if name == slot) {
            Expr::LambdaVariable {
                name: name.into(),
                dtype: None,
            }
        } else {
            node.try_map_children_rebuilt(|child, shared| rebind(child, shared, slot, name, memo))?
        };
        if shared {
            let value = Arc::new(value);
            memo.insert(key, value.clone());
            Ok(RebuiltExpr::Shared(value))
        } else {
            Ok(RebuiltExpr::Owned(value))
        }
    }
    let mut native = Expr::Column {
        name: "__vail_list_source".into(),
    };
    for (index, stage) in stages.iter().rev().enumerate() {
        let parameter = format!("__vail_logical_item_{index}");
        let Ok(body) = rebind(
            stage.key.native.expression(),
            false,
            &stage.key.slot,
            &parameter,
            &mut HashMap::new(),
        ) else {
            return Candidate::Declined;
        };
        native = if stage.filter {
            Expr::ArrayFilter {
                value: Arc::new(native),
                parameter,
                predicate: Arc::new(body.into_owned()),
            }
        } else {
            Expr::ArrayMap {
                value: Arc::new(native),
                parameter,
                body: Arc::new(body.into_owned()),
            }
        };
    }
    let Ok(frame) = DFSchema::try_from(Schema::new(vec![arrow_schema::Field::new(
        "__vail_list_source",
        input_type,
        true,
    )])) else {
        return Candidate::Declined;
    };
    let Ok(prepared) = logical_kernel_with_options(
        &native,
        &frame,
        &Schema::empty(),
        &BTreeMap::new(),
        &[],
        &options,
    ) else {
        return Candidate::Declined;
    };
    if prepared.get_type(&frame).ok().as_ref() != Some(&output) {
        return Candidate::Declined;
    }
    let LogicalExpr::ScalarFunction(mut prepared) = prepared else {
        return Candidate::Declined;
    };
    if prepared.args.len() != 1 {
        return Candidate::Declined;
    }
    prepared.args = vec![source.clone()];
    Candidate::Prepared(LogicalExpr::ScalarFunction(prepared))
}

pub(super) fn prepare(expression: LogicalExpr, schema: &DFSchema) -> DfResult<LogicalExpr> {
    Ok(expression
        .transform_down(|expression| {
            Ok(match prepare_region(&expression, schema) {
                Candidate::None => Transformed::no(expression),
                Candidate::Declined => Transformed::new(expression, false, TreeNodeRecursion::Jump),
                // The one opaque source stays unchanged, including any scopes beneath it.
                Candidate::Prepared(prepared) => {
                    Transformed::new(prepared, true, TreeNodeRecursion::Jump)
                }
            })
        })?
        .data)
}
