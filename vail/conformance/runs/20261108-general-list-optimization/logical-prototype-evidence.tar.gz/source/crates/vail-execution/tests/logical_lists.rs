use arrow_array::{
    Array, ArrayRef, BooleanArray, Int32Array, ListArray, RecordBatch, StringArray, StructArray,
};
use arrow_buffer::{NullBuffer, OffsetBuffer};
use arrow_schema::{DataType, Field};
use datafusion_common::DFSchema;
use datafusion_expr::{
    execution_props::ExecutionProps, physical_planning_context::PhysicalPlanningContext,
};
use datafusion_physical_expr::create_physical_expr;
use serde_json::{Value, json};
use std::sync::Arc;
use vail_execution::{
    expressions::{Expr, lower},
    logical_expr::{lower_logical, prepare_list_regions},
};

fn variable(name: &str) -> Value {
    json!({"op":"lambda_variable","name":name})
}
fn integer(value: i32) -> Value {
    json!({"op":"literal","dtype":"int32","value":value})
}
fn binary(operator: &str, left: Value, right: Value) -> Value {
    json!({"op":"binary","operator":operator,"left":left,"right":right})
}
fn map(value: Value, parameter: &str, body: Value) -> Value {
    json!({"op":"array_map","value":value,"parameter":parameter,"body":body})
}
fn check(expression: Value, batch: &RecordBatch, expected: &ArrayRef) {
    let expression: Expr = serde_json::from_value(expression).unwrap();
    let schema = DFSchema::try_from(batch.schema().as_ref().clone()).unwrap();
    let logical = lower_logical(&expression, &schema).unwrap();
    let prepared = prepare_list_regions(logical.clone(), &schema).unwrap();
    let mut programs = vec![lower(&expression, batch.schema_ref()).unwrap()];
    for expression in [logical, prepared] {
        programs.push(
            create_physical_expr(
                &expression,
                &schema,
                &ExecutionProps::new(),
                &PhysicalPlanningContext::default(),
            )
            .unwrap(),
        );
    }
    for program in programs {
        for (start, len) in [(0, batch.num_rows()), (0, 0), (1, batch.num_rows() - 1)] {
            let result = program
                .evaluate(&batch.slice(start, len))
                .unwrap()
                .into_array(len)
                .unwrap();
            assert_eq!(result.as_ref(), expected.slice(start, len).as_ref());
        }
    }
}

#[test]
fn maps_and_filter_preserve_values_null_lists_and_empty_lists() {
    let values = Arc::new(Int32Array::from(vec![
        Some(-1),
        None,
        Some(2),
        Some(200),
        Some(300),
        Some(4),
        Some(4),
    ]));
    let lists: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 3, 5, 5, 7].into()),
        values,
        Some(NullBuffer::from(vec![true, false, true, true])),
    ));
    let batch = RecordBatch::try_from_iter([("xs", lists)]).unwrap();
    let first = map(
        json!({"op":"column","name":"xs"}),
        "x",
        binary("add", variable("x"), integer(1)),
    );
    let filtered = json!({"op":"array_filter","value":first,"parameter":"y",
        "predicate":binary("gt",variable("y"),integer(0))});
    let result = map(filtered, "z", binary("mul", variable("z"), integer(2)));
    let expected: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 1, 1, 1, 3].into()),
        Arc::new(Int32Array::from(vec![6, 10, 10])),
        Some(NullBuffer::from(vec![true, false, true, true])),
    ));
    check(result, &batch, &expected);
}

#[test]
fn field_reads_include_null_ancestors_in_sliced_children() {
    let child: ArrayRef = Arc::new(Int32Array::from(vec![
        Some(99),
        Some(10),
        Some(20),
        None,
        Some(40),
        Some(50),
    ]));
    let records = StructArray::new(
        vec![Arc::new(Field::new("x", DataType::Int32, true))].into(),
        vec![child],
        Some(NullBuffer::from(vec![true, true, false, true, true, true])),
    )
    .slice(1, 5);
    let lists: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(records.data_type().clone(), true)),
        OffsetBuffer::new(vec![0, 3, 5].into()),
        Arc::new(records),
        Some(NullBuffer::from(vec![true, false])),
    ));
    let batch = RecordBatch::try_from_iter([("xs", lists)]).unwrap();
    let read = map(
        json!({"op":"column","name":"xs"}),
        "entry",
        json!({"op":"get_field","value":variable("entry"),"name":"x"}),
    );
    let result = map(
        read,
        "value",
        json!({"op":"if_else","condition":binary("gt",variable("value"),integer(0)),
        "consequent":variable("value"),"alternate":{"op":"literal","dtype":"int32","value":null}}),
    );
    let expected: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 3, 3].into()),
        Arc::new(Int32Array::from(vec![Some(10), None, None])),
        Some(NullBuffer::from(vec![true, false])),
    ));
    check(result, &batch, &expected);
}

#[test]
fn outer_row_capture_keeps_its_own_row_domain() {
    let lists: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 2, 3].into()),
        Arc::new(Int32Array::from(vec![Some(1), None, Some(7)])),
        None,
    ));
    let batch = RecordBatch::try_from_iter([
        ("xs", lists),
        ("bias", Arc::new(Int32Array::from(vec![2, 10])) as ArrayRef),
    ])
    .unwrap();
    let result = map(
        json!({"op":"column","name":"xs"}),
        "x",
        binary("add", variable("x"), json!({"op":"column","name":"bias"})),
    );
    let expected: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 2, 3].into()),
        Arc::new(Int32Array::from(vec![Some(3), None, Some(17)])),
        None,
    ));
    check(result, &batch, &expected);
}

#[test]
fn borrowed_nested_fields_preserve_payloads_and_independent_bitmap_offsets() {
    let strings: ArrayRef = Arc::new(
        StringArray::from(vec![
            Some("skip0"),
            Some("skip1"),
            Some("r0"),
            Some("A"),
            Some("hidden"),
            None,
            Some("B"),
            Some("r5"),
        ])
        .slice(2, 6),
    );
    let numbers: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 1, 3, 4, 4, 4, 5].into()),
        Arc::new(Int32Array::from(vec![0, 1, 2, 99, 5])),
        Some(NullBuffer::from(vec![true, true, true, true, false, true])),
    ));
    let records: ArrayRef = Arc::new(StructArray::new(
        vec![Arc::new(Field::new("x", DataType::Int32, true))].into(),
        vec![Arc::new(Int32Array::from(vec![
            Some(0),
            Some(1),
            Some(2),
            Some(10),
            None,
            Some(5),
        ]))],
        Some(NullBuffer::from(vec![true, true, true, false, true, true])),
    ));
    let fields = vec![
        Arc::new(Field::new("label", strings.data_type().clone(), true)),
        Arc::new(Field::new("numbers", numbers.data_type().clone(), true)),
        Arc::new(Field::new("record", records.data_type().clone(), true)),
    ]
    .into();
    let parent = StructArray::new(
        fields,
        vec![strings, numbers, records],
        Some(NullBuffer::from(vec![true, true, true, false, true, true, true, true]).slice(1, 6)),
    )
    .slice(1, 4);
    let lists: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(parent.data_type().clone(), true)),
        OffsetBuffer::new(vec![0, 3, 4].into()),
        Arc::new(parent),
        None,
    ));
    let batch = RecordBatch::try_from_iter([("xs", lists)]).unwrap();
    let read = |name: &str| json!({"op":"get_field","value":variable("entry"),"name":name});
    let expression = map(
        json!({"op":"column","name":"xs"}),
        "entry",
        json!({"op":"struct","fields":[["label",read("label")],["numbers",read("numbers")],["record",read("record")]]}),
    );
    let strings: ArrayRef = Arc::new(StringArray::from(vec![Some("A"), None, None, Some("B")]));
    let numbers: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Int32, true)),
        OffsetBuffer::new(vec![0, 2, 2, 2, 2].into()),
        Arc::new(Int32Array::from(vec![1, 2])),
        Some(NullBuffer::from(vec![true, false, true, false])),
    ));
    let records: ArrayRef = Arc::new(StructArray::new(
        vec![Arc::new(Field::new("x", DataType::Int32, true))].into(),
        vec![Arc::new(Int32Array::from(vec![
            Some(1),
            Some(2),
            Some(10),
            None,
        ]))],
        Some(NullBuffer::from(vec![true, false, false, true])),
    ));
    let fields = vec![
        Arc::new(Field::new("label", strings.data_type().clone(), true)),
        Arc::new(Field::new("numbers", numbers.data_type().clone(), true)),
        Arc::new(Field::new("record", records.data_type().clone(), true)),
    ]
    .into();
    let expected = StructArray::new(fields, vec![strings, numbers, records], None);
    let expected: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(expected.data_type().clone(), true)),
        OffsetBuffer::new(vec![0, 3, 4].into()),
        Arc::new(expected),
        None,
    ));
    check(expression, &batch, &expected);
}

#[test]
fn whole_call_field_keeps_its_logical_type_metadata() {
    use vail_execution::expressions::project_batch;
    let fixture =
        RecordBatch::try_from_iter([("id", Arc::new(Int32Array::from(vec![0, 1])) as ArrayRef)])
            .unwrap();
    let constructor: Expr = serde_json::from_value(json!({"op":"cast","dtype":"call","value":
        {"op":"struct","fields":[["__vail_call_alleles",{"op":"array","element_type":"int32","elements":[integer(0),integer(1)]}],
            ["__vail_call_phased",{"op":"literal","dtype":"bool","value":false}]]}})).unwrap();
    let calls = project_batch(&fixture, &[("call".into(), constructor)]).unwrap();
    let call = calls.column(0).clone();
    let expected_call =
        arrow_select::nullif::nullif(call.as_ref(), &BooleanArray::from(vec![false, true]))
            .unwrap();
    let parent = StructArray::new(
        vec![Arc::new(Field::new("call", call.data_type().clone(), true))].into(),
        vec![call],
        Some(NullBuffer::from(vec![true, false])),
    );
    let xs: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(parent.data_type().clone(), true)),
        OffsetBuffer::new(vec![0, 1, 2].into()),
        Arc::new(parent),
        None,
    ));
    let batch = RecordBatch::try_from_iter([("xs", xs)]).unwrap();
    let expected: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(
            expected_call.data_type().clone(),
            true,
        )),
        OffsetBuffer::new(vec![0, 1, 2].into()),
        expected_call,
        None,
    ));
    check(
        map(
            json!({"op":"column","name":"xs"}),
            "entry",
            json!({"op":"get_field","value":variable("entry"),"name":"call"}),
        ),
        &batch,
        &expected,
    );
}
