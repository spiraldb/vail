import pathlib,subprocess,json,os,hashlib,psutil,signal,statistics,time
root=pathlib.Path('/private/tmp/vail-general-list-20261108/logical-micro');root.mkdir()
exe=pathlib.Path('/private/tmp/vail-split-sort-target/release/examples/logical_list_cost')
source=pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail')
paths=['crates/vail-execution/src/logical_lists.rs','crates/vail-execution/src/logical_expr.rs','crates/vail-execution/src/expressions.rs','crates/vail-execution/examples/logical_list_cost.rs']
pins={'source':{p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths},'executable':hashlib.sha256(exe.read_bytes()).hexdigest(),'scope':'generated public two-projection experiment, not Hail workload; full Arrow oracle before timing; wall/preparation measured, no CPU claim'}
(root/'pins.json').write_text(json.dumps(pins,indent=2));records=[]
for case in ['maps','filter_map','identity','single']:
 for rows in [1,16,4096]:
  for i,mode in enumerate(['before','after','after','before','before','after','after','before']):
   assert hashlib.sha256(exe.read_bytes()).hexdigest()==pins['executable']
   out=root/f'{case}-{rows}-{i}-{mode}';out.mkdir()
   env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_')}
   env.update(RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
   if mode=='before':env['VAIL_DISABLE_LOGICAL_LIST_FUSION']='1'
   p=None
   try:
    with (out/'stdout').open('w') as so,(out/'stderr').open('w') as se:
     p=subprocess.Popen([str(exe),case,str(rows)],env=env,stdout=so,stderr=se,start_new_session=True)
     birth=psutil.Process(p.pid).create_time();code=p.wait(timeout=20)
   finally:
    if p is not None:
     if p.poll() is None:
      assert psutil.Process(p.pid).create_time()==birth and os.getpgid(p.pid)==p.pid
      os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
     try:os.killpg(p.pid,0);raise RuntimeError('group remains; stop')
     except ProcessLookupError:pass
     (out/'exit.json').write_text(json.dumps({'returncode':p.returncode,'group_absent':True}))
   assert code==0,(case,rows,mode,(out/'stderr').read_text()[-2500:])
   record=json.loads((out/'stdout').read_text());assert record['validated'] and record['disabled']==(mode=='before')
   record.update(mode=mode,process=i);records.append(record)
   (root/'records.json').write_text(json.dumps(records,indent=2))
  summary={}
  for field in ['prepare_seconds','prepare_plus_first_seconds','evaluation_wall_seconds']:
   v={m:statistics.median((statistics.median(r[field]) if isinstance(r[field],list) else r[field]) for r in records if r['case']==case and r['rows']==rows and r['mode']==m) for m in ['before','after']}
   v['after_over_before']=v['after']/v['before'];summary[field]=v
  print(case,rows,json.dumps(summary),flush=True)
assert {p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths}==pins['source']
