from pathlib import Path
import subprocess,json,hashlib,os
repo=Path('/private/tmp/vail-list-flatmap-20261106');root=Path(__file__).parent
paths=['vail/crates/vail-execution/src/expressions.rs','vail/crates/vail-execution/src/lib.rs'];saved={p:(repo/p).read_bytes()for p in paths}
def hashes():return{p:hashlib.sha256((repo/p).read_bytes()).hexdigest()for p in paths}
before=hashes()
try:
 for p in paths:(repo/p).write_bytes(subprocess.check_output(['git','show','ec0cca2ca:'+p],cwd=repo))
 baseline=hashes()
 env=dict(os.environ,RUSTC_WRAPPER='/Users/danielking/.cargo/bin/kache',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/private/tmp/vail-split-sort-target')
 cmd=['cargo','test','--release','--offline','-p','vail-execution','--test','map_index','indexed_float_arithmetic_keeps_bits_and_operand_order','--','--nocapture']
 with(root/'baseline-ieee.log').open('w')as log:r=subprocess.run(cmd,cwd=repo/'vail',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 print('baselineIEEEreturn',r.returncode,flush=True)
finally:
 for p,data in saved.items():(repo/p).write_bytes(data)
 restored=hashes();assert restored==before
 (root/'ieee-restoration.json').write_text(json.dumps({'before':before,'baseline':locals().get('baseline'),'restored':restored,'exact':True,'returncode':locals().get('r').returncode if 'r'in locals()else None},indent=2))
