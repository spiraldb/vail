from pathlib import Path
import json, statistics as st, hashlib
r=Path(__file__).parent
records=json.loads((r/'final-records.json').read_text());pins=json.loads((r/'pins.json').read_text())
assert len(records)==32
cases=list(dict.fromkeys(x['case'] for x in records));summary=[]
for case in cases:
 row={'case':case}
 for mode in ['before','after']:
  a=[x for x in records if x['case']==case and x['mode']==mode];assert len(a)==4
  assert all(x['validated'] and x['identity_verified_before_queries'] and x['cleanup']['reaped'] and x['cleanup']['group_absent'] and x['cleanup']['returncode']==0 and len(x['samples'])==5 and x['native_sha256']==pins['native'][mode] for x in a)
  row[mode]={metric:st.median(st.median(y[metric] for y in x['samples']) for x in a) for metric in ['wall_seconds','cpu_seconds']}
 row['change_percent']={metric:100*(row['after'][metric]/row['before'][metric]-1) for metric in row['before']};summary.append(row)
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
base=Path(pins['fixture']);members={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()};assert members==set(pins['fixture_files'])
post={}
for relative,expected in pins['fixture_files'].items():
 p=base/relative;record={'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};assert record==expected;post[relative]=record
(r/'post-input-hashes.json').write_text(json.dumps(post,indent=2)+'\n')
(r/'complete.json').write_text(json.dumps({'workers':32,'timed_samples':160,'all_complete_arrow_validations_passed':True,'all_groups_absent':True,'all_native_frontend_input_oracle_pins_passed':True,'final_content_hashes':len(post),'cpu':'whole-process across threads; no global4-thread cap','rss':'includes validation; sampled6GiB worker guard is not hard process-tree bound'},indent=2)+'\n')
micro=json.loads((r/'micro-records.json').read_text());assert len(micro)==160
ms=[]
for case,rows,width in dict.fromkeys((x['case'],x['rows'],x['width']) for x in micro):
 row={'case':case,'rows':rows,'width':width}
 for mode in ['before','after']:
  a=[x for x in micro if (x['case'],x['rows'],x['width'],x['mode'])==(case,rows,width,mode)];assert len(a)==4 and all(x['validated'] and x['cleanup']['group_absent'] and x['cleanup']['returncode']==0 for x in a)
  row[mode]={'eval_seconds':st.median(st.median(x['evaluation_wall_seconds']) for x in a),'warm_prepare_seconds':st.median(st.median(x['warmed_preparation_seconds']) for x in a),'cold_prepare_plus_first_seconds':st.median(x['prepare_plus_first_seconds'] for x in a)}
 row['eval_speedup']=row['before']['eval_seconds']/row['after']['eval_seconds'];row['change_percent']={metric:100*(row['after'][metric]/row['before'][metric]-1) for metric in row['before']};ms.append(row)
(r/'micro-summary.json').write_text(json.dumps(ms,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('Post-content hashes: ',len(post));print('All workers/cleanup/identities validated')
