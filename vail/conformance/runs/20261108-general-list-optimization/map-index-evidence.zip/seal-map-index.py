from pathlib import Path
import json,hashlib,subprocess,zipfile,os
r=Path('/private/tmp/vail-general-list-20261108');repo=Path('/private/tmp/vail-list-flatmap-20261106');payload={}
for sub in ['map-index','map-index-revision']:
 for directory,dirs,files in os.walk(r/sub,followlinks=False):
  dirs[:]=[d for d in dirs if d not in {'env','wheels','executables','references','__pycache__'} and not (Path(directory)/d).is_symlink()]
  for name in files:
   p=Path(directory)/name
   if not p.is_symlink() and p.suffix not in {'.so','.whl','.arrow','.pyc'}:
    assert p.stat().st_size<16*1024**2,p
    payload[str(p.relative_to(r))]=p.read_bytes()
for p in r.glob('map-index-*.log'):payload[p.name]=p.read_bytes()
sourcefiles=['vail/crates/vail-execution/src/expressions.rs','vail/crates/vail-execution/src/lib.rs','vail/crates/vail-execution/src/map_index.rs','vail/crates/vail-execution/tests/map_index.rs','vail/crates/vail-execution/examples/map_index_cost.rs','vail/python/tests/test_indexed_maps.py']
for commit in ['dff1064bb001713471e1b17a89d7015c1790eae7','5ec368937a9bcec059329ee835c17074b50fe6df','777d42054','30783876b24484cc80549d175faf15bab765f676']:
 full=subprocess.check_output(['git','rev-parse',commit],cwd=repo,text=True).strip()
 for rel in sourcefiles:
  result=subprocess.run(['git','show',full+':'+rel],cwd=repo,capture_output=True)
  if result.returncode==0:payload[f'source/{full}/{rel}']=result.stdout
 payload[f'source/{full}/diff.patch']=subprocess.check_output(['git','diff','ec0cca2ca0bfee714a74eb2844a541ccd460e900',full,'--',*sourcefiles],cwd=repo)
payload['seal-map-index.py']=Path(__file__).read_bytes()
manifest={k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(payload.items())}
archive=r/'map-index-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for k,v in sorted(payload.items()):z.writestr(k,v)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'manifest.json'}
 assert json.loads(z.read('manifest.json'))==manifest
 for k,rec in manifest.items():
  b=z.read(k);assert len(b)==rec['bytes'] and hashlib.sha256(b).hexdigest()==rec['sha256']
seal={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'payloads':len(manifest),'verified':True,'source':'30783876b24484cc80549d175faf15bab765f676','excluded':['native/executable binaries','wheels','environments','large Arrow refs'],'initial_and_revised_cohorts_retained':True}
(r/'map-index-evidence.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
