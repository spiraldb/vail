p='vail/crates/vail-execution/src/expressions.rs';s=open(p).read();needle='''    local_cse_names: HashSet<String>,
}''';assert s.count(needle)==1;s=s.replace(needle,'''    local_cse_names: HashSet<String>,
    mask_roots: HashMap<(usize, usize), Option<Type>>,
    mask_fields: HashMap<usize, (arrow_schema::Fields, HashMap<String, usize>)>,
}''')
start=s.index('pub(crate) fn masks_borrowed_read(');end=s.index('\nfn lower_uncached(',start)
s=s[:start]+'''pub(crate) fn masks_borrowed_read(value: &Expr, alternate: &Expr) -> bool {
    if !matches!(alternate, Expr::Literal { value, .. } if value.is_null()) {
        return false;
    }
    let mut read = value;
    while let Expr::GetField { value, .. } = read { read = value; }
    matches!(read, Expr::Column { .. } | Expr::LambdaVariable { .. })
}

/// Certify canonical storage once per root binding. Field indices are shared
/// across all reads of each retained Struct descriptor during preparation.
fn borrowed_read_layout<'a>(
    value: &Expr, schema: &'a Schema, scope: &[(String, Type, usize)],
    memo: &mut CompilationMemo, context: usize,
) -> Option<&'a DataType> {
    let mut path = Vec::new();
    let mut root = value;
    while let Expr::GetField { value, name } = root {
        path.push(name);
        root = value;
    }
    let index = match root {
        Expr::Column { name } => schema.index_of(name).ok()?,
        Expr::LambdaVariable { name, .. } => scope.iter().rev().find(|(bound, _, _)| bound == name)?.2,
        _ => return None,
    };
    let mut dtype = schema.field(index).data_type();
    let mut logical = memo.mask_roots.entry((context, index)).or_insert_with(|| {
        let ty = Type::from_arrow(dtype).ok()?;
        (ty.to_arrow().ok()? == *dtype).then_some(ty)
    }).as_ref()?;
    for name in path.into_iter().rev() {
        let DataType::Struct(fields) = dtype else { return None; };
        let key = fields.as_ptr() as usize;
        let (_, indices) = memo.mask_fields.entry(key).or_insert_with(|| (
            fields.clone(), fields.iter().enumerate().map(|(i, f)| (f.name().clone(), i)).collect(),
        ));
        let index = *indices.get(name)?;
        logical = match logical {
            Type::Struct { r#struct } => &r#struct[index].1,
            Type::Tuple { tuple } => &tuple[index],
            _ => return None,
        };
        dtype = fields[index].data_type();
    }
    Some(dtype)
}
''' +s[end:]
s=s.replace('''            if masks_borrowed_read(consequent, alternate, |value| {
                value.dtype_scoped(schema, globals.schema(), scope, memo, context)
            }) {''','''            if masks_borrowed_read(consequent, alternate) {''').replace('''borrowed_read_layout(consequent, schema, scope).as_ref() == Some(&dtype)''','''borrowed_read_layout(consequent, schema, scope, memo, context) == Some(&dtype)''')
open(p,'w').write(s)
p='vail/crates/vail-execution/src/logical_expr.rs';s=open(p).read();s=s.replace('''crate::expressions::masks_borrowed_read(consequent, alternate, |value| {
                value.dtype_with_globals(schema.as_arrow(), globals)
            })''','''crate::expressions::masks_borrowed_read(consequent, alternate)''');open(p,'w').write(s)
