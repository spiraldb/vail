p='vail/crates/vail-execution/src/expressions.rs';s=open(p).read();old='''                HailKind::Mask => {
                    let predicate = down::<BooleanArray>(args[0].as_ref())?;
                    let keep = match predicate.nulls() {
                        Some(nulls) => predicate.values() & nulls.inner(),
                        None => predicate.values().clone(),
                    };
                    nullif(args[1].as_ref(), &BooleanArray::new(!&keep, None))
                        .map_err(Into::into)
                }
''';assert old in s;s=s.replace(old,'''                HailKind::Mask => unreachable!("masking preserves scalar form above"),
''')
s=s.replace('''pub(crate) fn masks_borrowed_read(value: &Expr, alternate: &Expr) -> bool {''','''pub(crate) fn masks_borrowed_read(
    value: &Expr,
    alternate: &Expr,
    mut type_of: impl FnMut(&Expr) -> Result<Type, ExprError>,
) -> bool {''').replace('''while let Expr::GetField { value, name } = read {
        if name == "__vail_call_unphased_diploid_gt_index" {''','''while let Expr::GetField { value, .. } = read {
        if !matches!(type_of(value), Ok(Type::Struct { .. } | Type::Tuple { .. })) {''')
s=s.replace('''if masks_borrowed_read(consequent, alternate) {''','''if masks_borrowed_read(consequent, alternate, |value| {
                value.dtype_scoped(schema, globals.schema(), scope, memo, context)
            }) {''')
needle='''        Ok(Arc::new(Self {
            kind: self.kind.clone(),
            args: children,''';repl='''        if matches!(self.kind, HailKind::Mask) && !Arc::ptr_eq(&children[1], &self.args[1]) {
            // Replacements have not been certified as infallible borrowed reads.
            return Ok(Arc::new(CaseExpr::try_new(
                None, vec![(children[0].clone(), children[1].clone())], None,
            )?));
        }
'''+needle;assert s.count(needle)==1;s=s.replace(needle,repl)
needle='''        if matches!(self.kind, HailKind::RestoreArrowType) {''';repl='''        if matches!(self.kind, HailKind::Mask) {
            let predicate = self.args[0].evaluate(batch)?;
            if let ColumnarValue::Scalar(ScalarValue::Boolean(value)) = predicate {
                return if value == Some(true) {
                    self.args[1].evaluate(batch)
                } else {
                    Ok(ColumnarValue::Scalar(ScalarValue::try_from(&self.dtype)?))
                };
            }
            let predicate = predicate.into_array(len)?;
            let predicate = down::<BooleanArray>(predicate.as_ref())?;
            if !predicate.has_true() {
                return Ok(ColumnarValue::Array(new_null_array(&self.dtype, len)));
            }
            match self.args[1].evaluate(batch)? {
                ColumnarValue::Array(value) => {
                    let keep = match predicate.nulls() {
                        Some(nulls) => predicate.values() & nulls.inner(),
                        None => predicate.values().clone(),
                    };
                    return Ok(ColumnarValue::Array(nullif(
                        value.as_ref(), &BooleanArray::new(!&keep, None),
                    )?));
                }
                ColumnarValue::Scalar(value) => {
                    // CASE broadcasts only selected scalar lanes. Broadcasting a
                    // nested scalar before masking would copy unused payload.
                    let frame = RecordBatch::try_from_iter([
                        ("keep", Arc::new(predicate.clone()) as ArrayRef),
                    ])?;
                    return CaseExpr::try_new(None, vec![(
                        Arc::new(Column::new("keep", 0)), Arc::new(Literal::new(value)),
                    )], None)?.evaluate(&frame);
                }
            }
        }
'''+needle;s=s.replace(needle,repl,1)
open(p,'w').write(s)
p='vail/crates/vail-execution/src/logical_expr.rs';s=open(p).read().replace('''crate::expressions::masks_borrowed_read(consequent, alternate)''','''crate::expressions::masks_borrowed_read(consequent, alternate, |value| {
                value.dtype_with_globals(schema.as_arrow(), globals)
            })''');open(p,'w').write(s)
