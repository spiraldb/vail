# Reuse the exact validated real-workload worker, replacing only its timed loop
# with a fixed five-second profiling window after all full-output checks.
from pathlib import Path
import sys
root=Path('/private/tmp/vail-general-list-20261108')
s=(root/'worker.py').read_text();start=s.index('# Timed function is the ORIGINAL upstream body')
s=s[:start]+'''
(out/'profile-ready').write_text('ready')
end=time.monotonic()+5
count=0
while time.monotonic()<end:
 assert ns[case](fixture) is None
 count+=1
meta.update(profile_actions=count,validated=True)
(out/'result.json').write_text(json.dumps(meta,indent=2))
'''
exec(compile(s,str(root/'worker.py'),'exec'))
