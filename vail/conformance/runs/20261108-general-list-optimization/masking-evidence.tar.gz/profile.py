import os,pathlib,subprocess,json,time,psutil,signal
root=pathlib.Path('/private/tmp/vail-general-list-20261108')
for mode,python in [('before','/private/tmp/vail-flatmap-test-env-20261106/bin/python'),('after',str(root/'masking-env/bin/python'))]:
 out=root/('profile-'+mode);out.mkdir()
 env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_') and k!='PYTHONPATH'}
 env.update(RUN_MODE=mode,RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',TOKIO_WORKER_THREADS='4')
 p=None;sampler=None;rec={}
 def absent(pid):
  try:os.killpg(pid,0);return False
  except ProcessLookupError:return True
 def clean(proc,identity):
  if proc.poll() is None:
   current=psutil.Process(proc.pid)
   assert current.create_time()==identity and os.getpgid(proc.pid)==proc.pid and current.uids().effective==os.geteuid()
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
  assert absent(proc.pid)
  return {'pid':proc.pid,'returncode':proc.returncode,'group_absent':True}
 with (out/'stdout').open('w') as stdout,(out/'stderr').open('w') as stderr:
  try:
   p=subprocess.Popen([python,str(root/'profile-worker.py'),str(out),'test_matrix_table_filter_entries'],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   ident=psutil.Process(p.pid).create_time();end=time.monotonic()+30
   while not (out/'profile-ready').exists():
    assert p.poll() is None and time.monotonic()<end
    time.sleep(.02)
   with (out/'sample.stdout').open('w') as so,(out/'sample.stderr').open('w') as se:
    sampler=subprocess.Popen(['/usr/bin/sample',str(p.pid),'1','1','-file',str(out/'sample.txt')],stdout=so,stderr=se,start_new_session=True)
    sid=psutil.Process(sampler.pid).create_time();rec['sample_returncode']=sampler.wait(timeout=10)
   rec['worker_returncode']=p.wait(timeout=15)
  finally:
   if sampler is not None:rec['sampler_cleanup']=clean(sampler,sid)
   if p is not None:rec['worker_cleanup']=clean(p,ident)
   (out/'receipt.json').write_text(json.dumps(rec,indent=2))
  assert rec['sample_returncode']==0 and rec['worker_returncode']==0
 print(mode,rec,flush=True)
