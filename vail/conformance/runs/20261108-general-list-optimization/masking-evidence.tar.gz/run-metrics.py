import subprocess,pathlib,os,time,json,psutil,signal,hashlib
root=pathlib.Path('/private/tmp/vail-general-list-20261108');out=root/'operator-profile';out.mkdir()
exe=pathlib.Path('/private/tmp/vail-split-sort-target/release/examples/replay_projection')
env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_')}
env.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
rec={'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'example_source_sha256':hashlib.sha256(pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail/crates/vail-table/examples/replay_projection.rs').read_bytes()).hexdigest(),'production':'3fac5cc13b3cf6712ddefc1aac17146860c613a6','scope':'public Rust native projection full-value collect operator metrics; not Python construction/count timings or stack attribution'}
p=None
with (out/'stdout').open('w') as so,(out/'stderr').open('w') as se:
 try:
  p=subprocess.Popen([str(exe),str(root),'/private/tmp/vail-generic-list-20261104/inputs-1000/first-1000.mt/generation-1504a10fe8374230ae45c737c41f357d/core'],env=env,stdout=so,stderr=se,start_new_session=True)
  identity=psutil.Process(p.pid).create_time();deadline=time.monotonic()+30
  while p.poll() is None:
   assert time.monotonic()<deadline
   assert psutil.Process(p.pid).memory_info().rss<6*1024**3
   time.sleep(.05)
  rec['returncode']=p.returncode
 finally:
  if p and p.poll() is None:
   at=psutil.Process(p.pid);assert at.create_time()==identity and os.getpgid(p.pid)==p.pid
   os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
  if p:
   try:os.killpg(p.pid,0);raise AssertionError('owned group remains')
   except ProcessLookupError:rec['group_absent']=True
  (out/'receipt.json').write_text(json.dumps(rec,indent=2))
assert rec['returncode']==0
print(json.dumps(rec),flush=True)
