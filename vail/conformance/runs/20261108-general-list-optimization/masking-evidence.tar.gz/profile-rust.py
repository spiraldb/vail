import os,pathlib,subprocess,json,time,psutil,signal,hashlib
root=pathlib.Path('/private/tmp/vail-general-list-20261108');out=root/'rust-profile';out.mkdir()
exe=pathlib.Path('/private/tmp/vail-split-sort-target/release/examples/replay_projection')
source=pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail/crates/vail-table/examples/replay_projection.rs')
for name,key in [('filter-fields.json','fields_sha256'),('filter-core-reference.arrow','reference_sha256')]:
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==json.loads((root/'filter-export.json').read_text())[key]
env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_')}
env.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
p=None;sampler=None;rec={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'production_source':'3fac5cc13b3cf6712ddefc1aac17146860c613a6','sample_duration_seconds':1,'sample_interval_ms':1,'scope':'public RustTableIR replay of actual exported projection; excludes Python construction; primitive/null literals use JSON form'}
def absent(pid):
 try:os.killpg(pid,0);return False
 except ProcessLookupError:return True
def clean(proc,ident):
 if proc.poll() is None:
  at=psutil.Process(proc.pid)
  assert at.create_time()==ident and at.uids().effective==os.geteuid() and os.getpgid(proc.pid)==proc.pid
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
 assert absent(proc.pid)
 return {'pid':proc.pid,'returncode':proc.returncode,'group_absent':True}
with (out/'stdout').open('w') as stdout,(out/'stderr').open('w') as stderr:
 try:
  assert not (root/'replay-ready').exists()
  p=subprocess.Popen([str(exe),str(root),'/private/tmp/vail-generic-list-20261104/inputs-1000/first-1000.mt/generation-1504a10fe8374230ae45c737c41f357d/core'],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  ident=psutil.Process(p.pid).create_time();end=time.monotonic()+30
  while not (root/'replay-ready').exists():
   assert p.poll() is None and time.monotonic()<end
   assert psutil.Process(p.pid).memory_info().rss<6*1024**3
   time.sleep(.02)
  with (out/'sample.stdout').open('w') as so,(out/'sample.stderr').open('w') as se:
   sampler=subprocess.Popen(['/usr/bin/sample',str(p.pid),'1','1','-file',str(out/'sample.txt')],stdout=so,stderr=se,start_new_session=True)
   sid=psutil.Process(sampler.pid).create_time();rec['sample_returncode']=sampler.wait(timeout=20)
  rec['worker_returncode']=p.wait(timeout=10)
 finally:
  if sampler is not None:rec['sampler_cleanup']=clean(sampler,sid)
  if p is not None:rec['worker_cleanup']=clean(p,ident)
  (out/'receipt.json').write_text(json.dumps(rec,indent=2))
assert rec['worker_returncode']==0 and rec['sample_returncode']==0
print(json.dumps(rec),flush=True)
