import json,pathlib,hashlib
import vail as hl
import pyarrow as pa
from vail._native import NativeExpr,NativeType,NativeArrow
root=pathlib.Path('/private/tmp/vail-general-list-20261108')
m=hl.read_matrix_table('/private/tmp/vail-generic-list-20261104/inputs-1000/first-1000.mt');m=m.filter_entries((m.GQ>8)&(m.DP>2))
ir=m._mir.core._native.ir()
while ir['node']=='TableMapGlobals':ir=ir['child']
assert ir['node']=='TableMapRows'
def dtype(t):
 if t.kind=='struct':return {'struct':[[n,dtype(c)] for n,c in zip(t.field_names,t.children)]}
 if t.kind in ['array','set','interval']:return {t.kind:dtype(t.children[0])}
 if not t.children:return t.kind
 raise ValueError(str(t))
count=0
def convert(v):
 global count
 if isinstance(v,NativeExpr):
  count+=1;assert count<200
  return {k:convert(x) for k,x in v.items()}
 if isinstance(v,NativeType):return dtype(v)
 if isinstance(v,NativeArrow):return pa.table(v).column(0)[0].as_py()
 if isinstance(v,dict):return {k:convert(x) for k,x in v.items()}
 if isinstance(v,(tuple,list)):return [convert(x) for x in v]
 if v is None or isinstance(v,(str,int,float,bool)):return v
 raise ValueError(type(v))
fields=convert(ir['fields']);(root/'filter-fields.json').write_text(json.dumps(fields,indent=2))
expected=m._mir.core.to_arrow()
with pa.OSFile(str(root/'filter-core-reference.arrow'),'wb') as f:
 with pa.ipc.new_file(f,expected.schema) as w:w.write_table(expected)
(root/'filter-export.json').write_text(json.dumps({'native_scalar_nodes_expanded':count,'rows':expected.num_rows,'schema':str(expected.schema),'reference_sha256':hashlib.sha256((root/'filter-core-reference.arrow').read_bytes()).hexdigest(),'fields_sha256':hashlib.sha256((root/'filter-fields.json').read_bytes()).hexdigest()},indent=2))
print('exported',count,expected.num_rows)
