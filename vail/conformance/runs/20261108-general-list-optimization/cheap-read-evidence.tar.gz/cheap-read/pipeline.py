import pathlib, subprocess, os, time, signal, json, psutil
root=pathlib.Path(__file__).parent
repo=pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail')
python='/Users/danielking/projects/vail/vail/.venv/bin/python'
env=os.environ.copy()
env.update(RUSTC_WRAPPER='/Users/danielking/.cargo/bin/kache',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/private/tmp/vail-split-sort-target')
steps=[
 ('rust-tests',['cargo','test','--release','--offline','-p','vail-execution','--lib','--test','local_lambda_cse','--test','conditionals','--test','masked_read','--test','list_flatmap','--test','semantic_preparation'],900),
 ('example-build',['cargo','build','--release','--offline','-p','vail-execution','--example','cse_cost'],900),
 ('wheel-build',[python,'-m','maturin','build','--release','--offline','--out',str(root/'wheels'),'-i',python],1200),
 ('micro',[python,str(root/'run-micro.py')],180),
 ('python-gate',[python,str(root/'install-and-gate.py')],300),
 ('actual-benchmarks',[python,str(root/'run.py')],600),
]
receipts=[]
for name,command,budget in steps:
 print('START',name,flush=True)
 start=time.monotonic();p=None
 try:
  with (root/f'{name}.log').open('w') as log:
   p=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   birth=psutil.Process(p.pid).create_time()
   code=p.wait(timeout=budget)
 finally:
  if p is not None:
   if p.poll() is None:
    assert psutil.Process(p.pid).create_time()==birth and os.getpgid(p.pid)==p.pid
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:
     assert psutil.Process(p.pid).create_time()==birth and os.getpgid(p.pid)==p.pid
     os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   try:os.killpg(p.pid,0);raise RuntimeError('stage group remains; stop')
   except ProcessLookupError:pass
   receipts.append({'name':name,'command':command,'returncode':p.returncode,'group_absent':True,'seconds':time.monotonic()-start})
   (root/'pipeline-receipts.json').write_text(json.dumps(receipts,indent=2))
 assert code==0,(name,code)
 print('DONE',name,round(time.monotonic()-start,2),flush=True)
