import pathlib, os, subprocess, json, hashlib, statistics, time, signal, psutil
root=pathlib.Path(__file__).parent
repo=pathlib.Path('/private/tmp/vail-list-flatmap-20261106')
source=repo/'vail/crates/vail-execution/examples/scalar_tiling_cost.rs'
exe=pathlib.Path('/private/tmp/vail-split-sort-target/release/examples/scalar_tiling_cost')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_sha256':sha(source),'executable_sha256':sha(exe),'rows':[8192,1048576],'tile_rows':2048,'cpu_measured':False,'production':'same prepared public expression; diagnostic only, no policy change'}
(root/'pins.json').write_text(json.dumps(pins,indent=2))
records=[]
def interrupted(sig,frame):raise KeyboardInterrupt(f'signal {sig}')
for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,interrupted)
def absent(pid):
 try:os.killpg(pid,0);return False
 except ProcessLookupError:return True
def cleanup(p,birth):
 if p.poll() is None:
  proc=psutil.Process(p.pid);assert proc.create_time()==birth and proc.uids().effective==os.geteuid() and os.getpgid(p.pid)==p.pid
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:
   assert psutil.Process(p.pid).create_time()==birth and os.getpgid(p.pid)==p.pid
   os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
 end=time.monotonic()+3
 while not absent(p.pid) and time.monotonic()<end:time.sleep(.05)
 assert absent(p.pid),'owned group remains'
 return {'pid':p.pid,'returncode':p.returncode,'group_absent':True}
for case in ['probability','polynomial','cheap']:
 for rows in pins['rows']:
  for i,mode in enumerate(['whole','tiled','tiled','whole','whole','tiled','tiled','whole']):
   assert sha(exe)==pins['executable_sha256'] and sha(source)==pins['source_sha256']
   out=root/'observations'/f'{case}-{rows}-{i}-{mode}';out.mkdir(parents=True)
   env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_') and k!='PYTHONPATH'}
   env.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
   p=None;code=None;error=None
   try:
    with (out/'stdout').open('w')as stdout,(out/'stderr').open('w')as stderr:
     p=subprocess.Popen([str(exe),case,str(rows),mode],cwd='/private/tmp',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
     birth=psutil.Process(p.pid).create_time()
     try:code=p.wait(timeout=30)
     except subprocess.TimeoutExpired:code=124
   except BaseException as e:error=repr(e);raise
   finally:
    cleaned=cleanup(p,birth)if p else{'no_worker_started':True}
    (out/'exit.json').write_text(json.dumps({'code':code,'error':error,'cleanup':cleaned}))
   assert code==0,(out,(out/'stderr').read_text())
   r=json.loads((out/'stdout').read_text());assert r['validated'] and r['whole_tiled_bits_identical'] and r['case']==case and r['rows']==rows and r['mode']==mode and len(r['evaluation_wall_seconds'])==5
   r.update(process=i,cleanup=cleaned);records.append(r);(root/'records.json').write_text(json.dumps(records,indent=2))
  group=[r for r in records if r['case']==case and r['rows']==rows]
  summary={'case':case,'rows':rows}
  for name in ['prepare_seconds','first_seconds','evaluation_wall_seconds']:
   v={m:statistics.median(statistics.median(r[name])if isinstance(r[name],list)else r[name]for r in group if r['mode']==m)for m in ['whole','tiled']}
   summary[name]={**v,'tiled_percent_change':100*(v['tiled']/v['whole']-1),'speedup':v['whole']/v['tiled']}
  print(json.dumps(summary),flush=True)
assert len(records)==48 and sha(exe)==pins['executable_sha256'] and sha(source)==pins['source_sha256']
(root/'complete.json').write_text(json.dumps({'processes':48,'validated':True,'all_groups_absent':True,'pins_unchanged':True,'cpu_measured':False}))
