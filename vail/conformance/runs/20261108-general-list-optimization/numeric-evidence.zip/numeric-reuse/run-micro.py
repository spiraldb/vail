import os, pathlib, subprocess, json, hashlib, time, signal, statistics, psutil

root = pathlib.Path('/private/tmp/vail-general-list-20261108/numeric-reuse')
pins = json.loads((root / 'micro-pins.json').read_text())
outroot = root / 'micro'
outroot.mkdir()
records = []
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def interrupted(signum, frame):
    raise KeyboardInterrupt(f'signal {signum}')
for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, interrupted)
def absent(pid):
    try:
        os.killpg(pid, 0)
        return False
    except ProcessLookupError:
        return True
def clean(p, birth):
    if p.poll() is None:
        proc = psutil.Process(p.pid)
        assert proc.create_time() == birth and proc.uids().effective == os.geteuid() and os.getpgid(p.pid) == p.pid
        os.killpg(p.pid, signal.SIGTERM)
        try:
            p.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc = psutil.Process(p.pid)
            assert proc.create_time() == birth and os.getpgid(p.pid) == p.pid
            os.killpg(p.pid, signal.SIGKILL)
            p.wait(timeout=3)
    until = time.monotonic() + 3
    while not absent(p.pid) and time.monotonic() < until:
        time.sleep(.05)
    assert absent(p.pid), 'owned process group remains'
    return {'pid': p.pid, 'returncode': p.returncode, 'group_absent': True}
for case in ('identity', 'borrowed', 'temporary', 'shared', 'map'):
    for count in (1, 16, 131072):
        for index, mode in enumerate(('before', 'after', 'after', 'before', 'before', 'after', 'after', 'before')):
            exe = root / 'executables' / mode
            assert sha(exe) == pins['executables'][mode]
            out = outroot / f'{case}-{count}-{index}-{mode}'
            out.mkdir()
            env = {k: v for k, v in os.environ.items() if not k.startswith('VAIL_') and k != 'PYTHONPATH'}
            env.update(RAYON_NUM_THREADS='4', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
            p = None
            code = None
            error = None
            try:
                with (out / 'stdout').open('w') as stdout, (out / 'stderr').open('w') as stderr:
                    p = subprocess.Popen([str(exe), case, str(count)], env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                    birth = psutil.Process(p.pid).create_time()
                    try:
                        code = p.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        code = 124
            except BaseException as exc:
                error = repr(exc)
                raise
            finally:
                cleanup = clean(p, birth) if p else {'no_worker_started': True}
                (out / 'exit.json').write_text(json.dumps({'code': code, 'error': error, 'cleanup': cleanup}))
            assert code == 0, (out, (out / 'stderr').read_text())
            record = json.loads((out / 'stdout').read_text())
            assert record['validated'] and record['case'] == case and record['values'] == count and len(record['evaluation_wall_seconds']) == 5
            record.update(mode=mode, process=index, cleanup=cleanup)
            records.append(record)
            (root / 'micro-records.json').write_text(json.dumps(records, indent=2))
        cohort = [r for r in records if r['case'] == case and r['values'] == count]
        summary = {'case': case, 'values': count}
        for name in ('prepare_seconds', 'first_seconds', 'prepare_plus_first_seconds', 'warmed_preparation_seconds', 'evaluation_wall_seconds'):
            values = {}
            for mode in ('before', 'after'):
                values[mode] = statistics.median(statistics.median(r[name]) if isinstance(r[name], list) else r[name] for r in cohort if r['mode'] == mode)
            summary[name] = dict(values, percent_change=100 * (values['after'] / values['before'] - 1))
        print(json.dumps(summary), flush=True)
assert all(sha(root / 'executables' / mode) == pins['executables'][mode] for mode in pins['executables'])
(root / 'micro-complete.json').write_text(json.dumps({'processes': len(records), 'all_validated': True, 'executables_unchanged': True, 'cpu_measured': False}))
