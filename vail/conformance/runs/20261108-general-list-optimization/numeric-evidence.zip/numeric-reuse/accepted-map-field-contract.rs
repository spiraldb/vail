use std::sync::Arc;
use arrow_array::{Array, ArrayRef, BooleanArray, Int32Array, ListArray, RecordBatch};
use arrow_buffer::OffsetBuffer;
use arrow_schema::{DataType, Field};
use datafusion_common::DFSchema;
use datafusion_expr::{execution_props::ExecutionProps, physical_planning_context::PhysicalPlanningContext};
use datafusion_physical_expr::create_physical_expr;
use serde_json::json;
use vail_execution::{expressions::{Expr,lower},logical_expr::lower_logical};
fn main(){
 let input:ArrayRef=Arc::new(ListArray::new(Arc::new(Field::new_list_field(DataType::Int32,true)),OffsetBuffer::new(vec![0,2].into()),Arc::new(Int32Array::from(vec![None,Some(1)])),None));
 let batch=RecordBatch::try_from_iter([("xs",input)]).unwrap();
 let expr:Expr=serde_json::from_value(json!({"op":"array_map","value":{"op":"array_map","value":{"op":"column","name":"xs"},"parameter":"x","body":{"op":"binary","operator":"add","left":{"op":"lambda_variable","name":"x"},"right":{"op":"literal","dtype":"int32","value":1}}},"parameter":"y","body":{"op":"is_missing","value":{"op":"lambda_variable","name":"y"}}})).unwrap();
 let schema=DFSchema::try_from(batch.schema().as_ref().clone()).unwrap();
 let logical=lower_logical(&expr,&schema).unwrap();
 let programs=[lower(&expr,batch.schema_ref()).unwrap(),create_physical_expr(&logical,&schema,&ExecutionProps::new(),&PhysicalPlanningContext::default()).unwrap()];
 let mut fields=vec![];
 for (i,program) in programs.into_iter().enumerate(){
  let actual=program.evaluate(&batch).unwrap().into_array(1).unwrap();
  let expected=ListArray::new(Arc::new(Field::new_list_field(DataType::Boolean,i==1)),OffsetBuffer::new(vec![0,2].into()),Arc::new(BooleanArray::from(vec![true,false])),None);
  assert_eq!(actual.as_ref(),&expected);
  fields.push(format!("{:?}",actual.data_type()));
 }
 println!("{}",json!({"accepted_source":"945de6999d9c609b51b38e64894aed1fd0be6a84","both_independent_full_oracles_pass":true,"native_then_logical":fields}));
}
