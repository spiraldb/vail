from pathlib import Path
import subprocess, os, json, hashlib, psutil, signal, shutil, time
root=Path(__file__).parent
repo=Path('/private/tmp/vail-list-flatmap-20261106')
target=Path('/private/tmp/vail-split-sort-target')
paths=['vail/crates/vail-execution/src/numeric_literal.rs','vail/crates/vail-execution/src/expressions.rs','vail/crates/vail-execution/src/lib.rs','vail/crates/vail-table/src/logical.rs']
saved={name:(repo/name).read_bytes() for name in paths}
before={name:hashlib.sha256(data).hexdigest() for name,data in saved.items()}
env=dict(os.environ,RUSTC_WRAPPER='/Users/danielking/.cargo/bin/kache',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(target))
receipts=[]
def run(name,command,expected=0):
    process=None
    start=time.monotonic()
    try:
        with (root/(name+'.log')).open('w') as log:
            process=subprocess.Popen(command,cwd=repo/'vail',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            birth=psutil.Process(process.pid).create_time()
            code=process.wait(timeout=900)
    finally:
        if process is not None:
            if process.poll() is None:
                assert psutil.Process(process.pid).create_time()==birth and os.getpgid(process.pid)==process.pid
                os.killpg(process.pid,signal.SIGTERM)
                try: process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    assert psutil.Process(process.pid).create_time()==birth and os.getpgid(process.pid)==process.pid
                    os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
            try: os.killpg(process.pid,0);raise RuntimeError('owned group remains')
            except ProcessLookupError: pass
            receipts.append({'name':name,'command':command,'returncode':process.returncode,'group_absent':True,'seconds':time.monotonic()-start})
            (root/'artifact-preparation-receipts.json').write_text(json.dumps(receipts,indent=2))
    assert code==expected,(name,code)
    print(name,code,flush=True)
try:
    (repo/paths[0]).write_bytes((root/'before-dag-memo.rs').read_bytes())
    run('pre-memo-counterfactual',['cargo','test','--release','--offline','-p','vail-execution','--test','numeric_literal','rewrite_preparation_does_not_expand_shared_expression_diamonds','--','--nocapture'],101)
    (repo/paths[0]).write_bytes(saved[paths[0]])
    for name in paths[1:]:
        (repo/name).write_bytes(subprocess.check_output(['git','show','945de6999d9c609b51b38e64894aed1fd0be6a84:'+name],cwd=repo))
    baseline={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in paths[1:]}
    run('baseline-allocation-counterfactual',['cargo','test','--release','--offline','-p','vail-execution','--test','masked_read','arithmetic','--','--nocapture'],101)
    run('baseline-example-build',['cargo','build','--release','--offline','-p','vail-execution','--example','numeric_literal_cost'])
    (root/'executables').mkdir(exist_ok=True)
    shutil.copy2(target/'release/examples/numeric_literal_cost',root/'executables/before')
finally:
    for name,data in saved.items(): (repo/name).write_bytes(data)
    restored={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in paths}
    assert restored==before
    (root/'source-restoration.json').write_text(json.dumps({'candidate_before':before,'accepted_baseline':locals().get('baseline'),'candidate_restored':restored,'exact':True},indent=2))
run('candidate-example-build',['cargo','build','--release','--offline','-p','vail-execution','--example','numeric_literal_cost'])
shutil.copy2(target/'release/examples/numeric_literal_cost',root/'executables/after')
pins={'source_commit':(root/'candidate-commit.txt').read_text().strip(),'baseline_production':'945de6999d9c609b51b38e64894aed1fd0be6a84','candidate_sources':before,'executables':{mode:hashlib.sha256((root/'executables'/mode).read_bytes()).hexdigest() for mode in ['before','after']},'example_sha256':hashlib.sha256((repo/'vail/crates/vail-execution/examples/numeric_literal_cost.rs').read_bytes()).hexdigest(),'scope':'native public expression programs; normal Cargo builds; no compiled library copying; preparation separate; full Arrow oracles before evaluation wall timings; CPU unmeasured'}
(root/'micro-pins.json').write_text(json.dumps(pins,indent=2))
print(json.dumps(pins),flush=True)
