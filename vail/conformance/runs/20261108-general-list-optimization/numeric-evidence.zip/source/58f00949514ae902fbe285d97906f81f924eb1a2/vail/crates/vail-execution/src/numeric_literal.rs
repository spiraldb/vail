//! Reuse uniquely owned primitive temporaries without changing logical algebra.
use arrow_array::{
    ArrayRef, PrimitiveArray, RecordBatch,
    types::{ArrowPrimitiveType, Float32Type, Float64Type, Int32Type, Int64Type},
};
use arrow_buffer::ScalarBuffer;
use arrow_schema::{DataType, FieldRef, Schema};
use datafusion_common::{Result, ScalarValue, exec_err};
use datafusion_expr::{
    ColumnarValue, Operator, interval_arithmetic::Interval, sort_properties::ExprProperties,
};
use datafusion_physical_expr::{
    PhysicalExpr, ScalarFunctionExpr,
    expressions::{BinaryExpr, CaseExpr, CastExpr, Column, LambdaVariable, Literal},
};
use std::{
    collections::HashMap,
    fmt,
    hash::{Hash, Hasher},
    sync::Arc,
};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum Number {
    I32(i32),
    I64(i64),
    F32(u32),
    F64(u64),
}
impl Number {
    fn dtype(self) -> DataType {
        match self {
            Self::I32(_) => DataType::Int32,
            Self::I64(_) => DataType::Int64,
            Self::F32(_) => DataType::Float32,
            Self::F64(_) => DataType::Float64,
        }
    }
    fn new(value: &ScalarValue) -> Option<Self> {
        Some(match value {
            ScalarValue::Int32(Some(v)) => Self::I32(*v),
            ScalarValue::Int64(Some(v)) => Self::I64(*v),
            ScalarValue::Float32(Some(v)) => Self::F32(v.to_bits()),
            ScalarValue::Float64(Some(v)) => Self::F64(v.to_bits()),
            _ => return None,
        })
    }
}

// Returning the typed metadata releases this evaluated Arc before the caller
// asks Arrow whether its value buffer is uniquely owned.
fn primitive<T: ArrowPrimitiveType>(value: ArrayRef) -> Result<PrimitiveArray<T>> {
    value
        .as_any()
        .downcast_ref::<PrimitiveArray<T>>()
        .cloned()
        .ok_or_else(|| datafusion_common::exec_datafusion_err!("numeric operand type changed"))
}
fn apply<T: ArrowPrimitiveType, F: Fn(T::Native) -> T::Native>(
    value: ArrayRef,
    function: F,
) -> Result<ArrayRef> {
    let (_, values, nulls) = primitive::<T>(value)?.into_parts();
    // Validity is immutable. A shared bitmap must not prevent reuse of an
    // otherwise unique value buffer; Arrow still decides value ownership.
    let values = match values.into_inner().into_mutable() {
        Ok(mut values) => {
            for value in values.typed_data_mut::<T::Native>() {
                *value = function(*value);
            }
            ScalarBuffer::from(values)
        }
        Err(values) => ScalarBuffer::<T::Native>::from(values)
            .iter()
            .copied()
            .map(function)
            .collect(),
    };
    Ok(Arc::new(PrimitiveArray::<T>::new(values, nulls)))
}

fn borrowed(source: &Arc<dyn PhysicalExpr>) -> bool {
    let source = crate::expressions::metadata_inner(source);
    source.is::<Column>() || source.is::<LambdaVariable>() || source.is::<Literal>()
}

fn declared_type(source: &Arc<dyn PhysicalExpr>, schema: &Schema) -> Option<DataType> {
    let source = crate::expressions::metadata_inner(source);
    if let Some(variable) = source.downcast_ref::<LambdaVariable>() {
        Some(variable.field().data_type().clone())
    } else if let Some(reuse) = source.downcast_ref::<ReuseNumeric>() {
        Some(reuse.number.dtype())
    } else if source.is::<Column>()
        || source.is::<Literal>()
        || source.is::<ScalarFunctionExpr>()
        || source.is::<CastExpr>()
    {
        source.data_type(schema).ok()
    } else {
        None
    }
}

// The first arithmetic operation on a borrowed lane remains DF's operation.
// Its immediate, typed operands certify the temporary it produces, without
// inferring the type of a growing arithmetic suffix again.
fn temporary_type(source: &Arc<dyn PhysicalExpr>, schema: &Schema) -> Option<DataType> {
    declared_type(source, schema).or_else(|| {
        let (operand, number, _, _) = candidate(crate::expressions::metadata_inner(source))?;
        (declared_type(&operand, schema) == Some(number.dtype())).then(|| number.dtype())
    })
}

#[derive(Debug)]
struct ReuseNumeric {
    original: Arc<dyn PhysicalExpr>,
    source: Arc<dyn PhysicalExpr>,
    number: Number,
    operator: Operator,
    literal_left: bool,
    wrapping_integers: bool,
}
impl PartialEq for ReuseNumeric {
    fn eq(&self, other: &Self) -> bool {
        self.original.eq(&other.original)
            && self.number == other.number
            && self.operator == other.operator
            && self.literal_left == other.literal_left
            && self.wrapping_integers == other.wrapping_integers
    }
}
impl Eq for ReuseNumeric {}
impl Hash for ReuseNumeric {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.original.hash(state);
        self.number.hash(state);
        self.operator.hash(state);
        self.literal_left.hash(state);
        self.wrapping_integers.hash(state);
    }
}
impl fmt::Display for ReuseNumeric {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "ReuseNumeric({})", self.original)
    }
}
impl PhysicalExpr for ReuseNumeric {
    fn fmt_sql(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.original.fmt_sql(f)
    }
    fn data_type(&self, schema: &Schema) -> Result<DataType> {
        self.original.data_type(schema)
    }
    fn nullable(&self, schema: &Schema) -> Result<bool> {
        self.original.nullable(schema)
    }
    fn return_field(&self, schema: &Schema) -> Result<FieldRef> {
        self.original.return_field(schema)
    }
    fn children(&self) -> Vec<&Arc<dyn PhysicalExpr>> {
        self.original.children()
    }
    fn with_new_children(
        self: Arc<Self>,
        children: Vec<Arc<dyn PhysicalExpr>>,
    ) -> Result<Arc<dyn PhysicalExpr>> {
        let old = self.original.children();
        if children.len() != old.len() {
            return exec_err!("numeric child count changed");
        }
        if old
            .iter()
            .zip(&children)
            .all(|(old, new)| Arc::ptr_eq(old, new))
        {
            return Ok(self);
        }
        let original = self.original.clone().with_new_children(children)?;
        // DF rebases typed lambda lanes into a compact frame. Revalidate only
        // operands with their own proven type; arbitrary replacements fall back.
        let Some((source, number, operator, literal_left)) = candidate(&original) else {
            return Ok(original);
        };
        // A rebase supplies typed lambda lanes, never an arbitrary column frame.
        let known_type = temporary_type(&source, &Schema::empty());
        if !borrowed(&source)
            && known_type == Some(number.dtype())
            && (self.wrapping_integers || matches!(number, Number::F32(_) | Number::F64(_)))
        {
            return Ok(Arc::new(Self {
                original,
                source,
                number,
                operator,
                literal_left,
                wrapping_integers: self.wrapping_integers,
            }));
        }
        Ok(original)
    }
    fn get_properties(&self, children: &[ExprProperties]) -> Result<ExprProperties> {
        self.original.get_properties(children)
    }
    fn evaluate_bounds(&self, children: &[&Interval]) -> Result<Interval> {
        self.original.evaluate_bounds(children)
    }
    fn propagate_constraints(
        &self,
        interval: &Interval,
        children: &[&Interval],
    ) -> Result<Option<Vec<Interval>>> {
        self.original.propagate_constraints(interval, children)
    }
    #[allow(deprecated)]
    fn evaluate_statistics(
        &self,
        children: &[&datafusion_expr::statistics::Distribution],
    ) -> Result<datafusion_expr::statistics::Distribution> {
        self.original.evaluate_statistics(children)
    }
    fn evaluate(&self, batch: &RecordBatch) -> Result<ColumnarValue> {
        let value = self.source.evaluate(batch)?;
        macro_rules! run {
            ($ty:ty, $variant:ident, $function:expr) => {{
                let function = $function;
                match value {
                    ColumnarValue::Array(value) => {
                        Ok(ColumnarValue::Array(apply::<$ty, _>(value, function)?))
                    }
                    ColumnarValue::Scalar(ScalarValue::$variant(value)) => Ok(
                        ColumnarValue::Scalar(ScalarValue::$variant(value.map(function))),
                    ),
                    _ => exec_err!("numeric scalar operand type changed"),
                }
            }};
        }
        macro_rules! arithmetic {
            ($ty:ty, $variant:ident, $constant:expr, $add:expr, $sub:expr, $mul:expr) => {{
                let constant = $constant;
                match (self.operator, self.literal_left) {
                    (Operator::Plus, true) => run!($ty, $variant, |v| ($add)(constant, v)),
                    (Operator::Plus, false) => run!($ty, $variant, |v| ($add)(v, constant)),
                    (Operator::Minus, true) => run!($ty, $variant, |v| ($sub)(constant, v)),
                    (Operator::Minus, false) => run!($ty, $variant, |v| ($sub)(v, constant)),
                    (Operator::Multiply, true) => run!($ty, $variant, |v| ($mul)(constant, v)),
                    (Operator::Multiply, false) => run!($ty, $variant, |v| ($mul)(v, constant)),
                    _ => unreachable!(),
                }
            }};
        }
        match self.number {
            Number::I32(v) => arithmetic!(
                Int32Type,
                Int32,
                v,
                i32::wrapping_add,
                i32::wrapping_sub,
                i32::wrapping_mul
            ),
            Number::I64(v) => arithmetic!(
                Int64Type,
                Int64,
                v,
                i64::wrapping_add,
                i64::wrapping_sub,
                i64::wrapping_mul
            ),
            Number::F32(v) => arithmetic!(
                Float32Type,
                Float32,
                f32::from_bits(v),
                |a: f32, b: f32| a + b,
                |a: f32, b: f32| a - b,
                |a: f32, b: f32| a * b
            ),
            Number::F64(v) => arithmetic!(
                Float64Type,
                Float64,
                f64::from_bits(v),
                |a: f64, b: f64| a + b,
                |a: f64, b: f64| a - b,
                |a: f64, b: f64| a * b
            ),
        }
    }
}

fn candidate(
    expression: &Arc<dyn PhysicalExpr>,
) -> Option<(Arc<dyn PhysicalExpr>, Number, Operator, bool)> {
    let binary = expression.downcast_ref::<BinaryExpr>()?;
    let operator = *binary.op();
    if !matches!(
        operator,
        Operator::Plus | Operator::Minus | Operator::Multiply
    ) {
        return None;
    }
    let operand = if let Some(literal) = binary
        .right()
        .downcast_ref::<Literal>()
        .and_then(|v| Number::new(v.value()))
    {
        Some((binary.left().clone(), literal, false))
    } else {
        binary
            .left()
            .downcast_ref::<Literal>()
            .and_then(|v| Number::new(v.value()))
            .map(|literal| (binary.right().clone(), literal, true))
    };
    operand.map(|(source, number, literal_left)| (source, number, operator, literal_left))
}
fn reuse(
    expression: Arc<dyn PhysicalExpr>,
    schema: &Schema,
    wrapping_integers: bool,
) -> Result<Arc<dyn PhysicalExpr>> {
    let Some((source, number, operator, literal_left)) = candidate(&expression) else {
        return Ok(expression);
    };
    if borrowed(&source) {
        return Ok(expression);
    }
    let expected = number.dtype();
    let source_type = if wrapping_integers {
        Some(source.data_type(schema)?)
    } else {
        temporary_type(&source, schema)
    };
    // For these operators, two identical numeric primitive types produce the
    // same type. Do not recursively infer a growing arithmetic suffix again.
    if (!wrapping_integers && matches!(number, Number::I32(_) | Number::I64(_)))
        || source_type != Some(expected)
    {
        return Ok(expression);
    }
    Ok(Arc::new(ReuseNumeric {
        original: expression,
        source,
        number,
        operator,
        literal_left,
        wrapping_integers,
    }))
}

/// Only the native constructor with an explicit wrapping policy calls this.
pub(crate) fn native_wrapping(
    expression: Arc<dyn PhysicalExpr>,
    schema: &Schema,
) -> Result<Arc<dyn PhysicalExpr>> {
    reuse(expression, schema, true)
}

/// Preserve logical algebra. DF integer overflow policy is not exposed here,
/// so the ordinary physical rewrite admits floating arithmetic only.
pub fn rewrite_floats(
    expression: Arc<dyn PhysicalExpr>,
    schema: &Schema,
) -> Result<Arc<dyn PhysicalExpr>> {
    fn visit(
        expression: Arc<dyn PhysicalExpr>,
        schema: &Schema,
        memo: &mut HashMap<usize, Arc<dyn PhysicalExpr>>,
    ) -> Result<Arc<dyn PhysicalExpr>> {
        let key = Arc::as_ptr(&expression) as *const () as usize;
        if let Some(rewritten) = memo.get(&key) {
            return Ok(rewritten.clone());
        }
        // These children use the same frame. Lambdas and private callback
        // nodes prepare their arithmetic through the native scoped path.
        let same_frame = expression.is::<BinaryExpr>()
            || expression.is::<ScalarFunctionExpr>()
            || expression.is::<CaseExpr>()
            || expression.is::<CastExpr>()
            || expression.is::<Column>()
            || expression.is::<Literal>();
        let rewritten = if !same_frame {
            expression
        } else {
            let mut changed = false;
            let mut children = Vec::with_capacity(expression.children().len());
            for child in expression.children() {
                let rewritten = visit(child.clone(), schema, memo)?;
                changed |= !Arc::ptr_eq(child, &rewritten);
                children.push(rewritten);
            }
            let expression = if changed {
                expression.with_new_children(children)?
            } else {
                expression
            };
            reuse(expression, schema, false)?
        };
        memo.insert(key, rewritten.clone());
        Ok(rewritten)
    }
    // Retain every original node while address keys describe this one schema.
    let original = expression.clone();
    let rewritten = visit(expression, schema, &mut HashMap::new());
    drop(original);
    rewritten
}
