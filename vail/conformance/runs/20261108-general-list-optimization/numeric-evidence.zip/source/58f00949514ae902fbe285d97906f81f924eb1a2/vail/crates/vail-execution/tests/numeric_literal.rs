use arrow_array::{
    Array, ArrayRef, Float32Array, Float64Array, Int32Array, Int64Array, RecordBatch,
};
use arrow_schema::DataType;
use datafusion_common::ScalarValue;
use datafusion_expr::{ColumnarValue, Operator};
use datafusion_physical_expr::{
    PhysicalExpr,
    expressions::{BinaryExpr, Column, Literal},
};
use std::sync::Arc;
use std::{
    alloc::{GlobalAlloc, Layout, System},
    cell::Cell,
};
thread_local! { static ALLOCATED: Cell<Option<usize>> = const { Cell::new(None) }; }
struct Allocator;
fn charge(bytes: usize) {
    let _ = ALLOCATED.try_with(|sum| {
        if let Some(old) = sum.get() {
            sum.set(Some(old + bytes));
        }
    });
}
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        charge(layout.size());
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        charge(layout.size());
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, bytes: usize) -> *mut u8 {
        charge(bytes);
        unsafe { System.realloc(ptr, layout, bytes) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}
#[global_allocator]
static ALLOCATOR: Allocator = Allocator;
use vail_execution::{
    expressions::{BinaryOperator, Expr, lower},
    numeric_literal::rewrite_floats,
};

fn expression(value: ScalarValue, operator: BinaryOperator, left: bool) -> Expr {
    let column = Arc::new(Expr::Column { name: "x".into() });
    let literal = Arc::new(Expr::RuntimeLiteral { value });
    let (left, right) = if left {
        (literal, column)
    } else {
        (column, literal)
    };
    Expr::Binary {
        operator,
        left,
        right,
    }
}

#[test]
fn computed_temporaries_preserve_wrapping_and_ieee_steps() {
    macro_rules! check {
        ($array:ty, $variant:ident, $values:expr, $one:expr, $constant:expr, $add:expr, $sub:expr, $mul:expr, $same:expr) => {{
            let source: ArrayRef = Arc::new(<$array>::from($values));
            let before = source.to_data();
            let batch = RecordBatch::try_from_iter([("x", source.clone())])
                .unwrap()
                .slice(1, 6);
            for left in [false, true] {
                for operator in [
                    BinaryOperator::Add,
                    BinaryOperator::Sub,
                    BinaryOperator::Mul,
                ] {
                    let first = Arc::new(expression(
                        ScalarValue::$variant(Some($one)),
                        BinaryOperator::Add,
                        false,
                    ));
                    let constant = Arc::new(Expr::RuntimeLiteral {
                        value: ScalarValue::$variant(Some($constant)),
                    });
                    let (a, b) = if left {
                        (constant, first)
                    } else {
                        (first, constant)
                    };
                    let program = lower(
                        &Expr::Binary {
                            operator,
                            left: a,
                            right: b,
                        },
                        batch.schema_ref(),
                    )
                    .unwrap();
                    for (start, len) in [(0, 6), (1, 4), (0, 0)] {
                        let input = batch.slice(start, len);
                        let values = input.column(0).as_any().downcast_ref::<$array>().unwrap();
                        let output = program.evaluate(&input).unwrap().into_array(len).unwrap();
                        let output = output.as_any().downcast_ref::<$array>().unwrap();
                        for (i, value) in values.iter().enumerate() {
                            assert_eq!(output.is_null(i), value.is_none());
                            if let Some(value) = value {
                                let first = ($add)(value, $one);
                                let (a, b) = if left {
                                    ($constant, first)
                                } else {
                                    (first, $constant)
                                };
                                let expected = match operator {
                                    BinaryOperator::Add => ($add)(a, b),
                                    BinaryOperator::Sub => ($sub)(a, b),
                                    BinaryOperator::Mul => ($mul)(a, b),
                                    _ => unreachable!(),
                                };
                                assert!(
                                    ($same)(output.value(i), expected),
                                    "{operator:?}, literal_left {left}, lane {i}"
                                );
                            }
                        }
                    }
                }
            }
            assert_eq!(source.to_data(), before);
        }};
    }
    check!(
        Int32Array,
        Int32,
        vec![
            Some(9),
            Some(i32::MAX),
            None,
            Some(i32::MIN),
            Some(-1),
            Some(0),
            Some(2),
            Some(9)
        ],
        1i32,
        3i32,
        i32::wrapping_add,
        i32::wrapping_sub,
        i32::wrapping_mul,
        |a, b| a == b
    );
    check!(
        Int64Array,
        Int64,
        vec![
            Some(9),
            Some(i64::MAX),
            None,
            Some(i64::MIN),
            Some(-1),
            Some(0),
            Some(2),
            Some(9)
        ],
        1i64,
        3i64,
        i64::wrapping_add,
        i64::wrapping_sub,
        i64::wrapping_mul,
        |a, b| a == b
    );
    check!(
        Float32Array,
        Float32,
        vec![
            Some(9.0),
            Some(0.0),
            Some(-0.0),
            None,
            Some(f32::INFINITY),
            Some(f32::NEG_INFINITY),
            Some(f32::from_bits(0x7fc0_1234)),
            Some(9.0)
        ],
        -0.0f32,
        -3.0f32,
        |a: f32, b: f32| a + b,
        |a: f32, b: f32| a - b,
        |a: f32, b: f32| a * b,
        |a: f32, b: f32| a.to_bits() == b.to_bits()
    );
    check!(
        Float64Array,
        Float64,
        vec![
            Some(9.0),
            Some(0.0),
            Some(-0.0),
            None,
            Some(f64::INFINITY),
            Some(f64::NEG_INFINITY),
            Some(f64::from_bits(0x7ff8_0000_0000_1234)),
            Some(9.0)
        ],
        -0.0f64,
        -3.0f64,
        |a: f64, b: f64| a + b,
        |a: f64, b: f64| a - b,
        |a: f64, b: f64| a * b,
        |a: f64, b: f64| a.to_bits() == b.to_bits()
    );
}

#[test]
fn temporary_child_replacement_and_scalar_results_keep_their_contract() {
    let batch = RecordBatch::try_from_iter([(
        "x",
        Arc::new(Float64Array::from(vec![2.0, 4.0])) as ArrayRef,
    )])
    .unwrap();
    let first: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
        Arc::new(Column::new("x", 0)),
        Operator::Plus,
        Arc::new(Literal::new(ScalarValue::Float64(Some(1.0)))),
    ));
    let outer: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
        first.clone(),
        Operator::Multiply,
        Arc::new(Literal::new(ScalarValue::Float64(Some(2.0)))),
    ));
    let program = rewrite_floats(outer, batch.schema_ref()).unwrap();
    for (source, expected) in [
        (first, vec![21.0, 35.0]),
        (
            Arc::new(Column::new("x", 0)) as Arc<dyn PhysicalExpr>,
            vec![14.0, 28.0],
        ),
    ] {
        let replaced = program
            .clone()
            .with_new_children(vec![
                source,
                Arc::new(Literal::new(ScalarValue::Float64(Some(7.0)))),
            ])
            .unwrap();
        assert_eq!(
            replaced
                .evaluate(&batch)
                .unwrap()
                .into_array(2)
                .unwrap()
                .as_ref(),
            &Float64Array::from(expected)
        );
    }
    for value in [Some(2.0), None] {
        let first: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
            Arc::new(Literal::new(ScalarValue::Float64(value))),
            Operator::Plus,
            Arc::new(Literal::new(ScalarValue::Float64(Some(1.0)))),
        ));
        let outer: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
            first,
            Operator::Multiply,
            Arc::new(Literal::new(ScalarValue::Float64(Some(3.0)))),
        ));
        let program = rewrite_floats(outer, batch.schema_ref()).unwrap();
        let ColumnarValue::Scalar(value_out) = program.evaluate(&batch).unwrap() else {
            panic!("scalar was expanded")
        };
        assert_eq!(
            value_out,
            ScalarValue::Float64(value.map(|v| (v + 1.0) * 3.0))
        );
    }
}

#[test]
fn native_integer_arithmetic_wraps_and_preserves_borrowed_slices() {
    macro_rules! check {
        ($array:ty, $variant:ident, $values:expr, $constant:expr) => {{
            let source: ArrayRef = Arc::new(<$array>::from($values));
            let original = source.to_data();
            let batch = RecordBatch::try_from_iter([("x", source.clone())])
                .unwrap()
                .slice(1, 4);
            for left in [false, true] {
                for operator in [
                    BinaryOperator::Add,
                    BinaryOperator::Sub,
                    BinaryOperator::Mul,
                ] {
                    let program = lower(
                        &expression(ScalarValue::$variant(Some($constant)), operator, left),
                        batch.schema_ref(),
                    )
                    .unwrap();
                    for (start, len) in [(0, 4), (1, 2), (0, 0)] {
                        let input = batch.slice(start, len);
                        let values = input.column(0).as_any().downcast_ref::<$array>().unwrap();
                        let expected = <$array>::from_iter(values.iter().map(|value| {
                            value.map(|value| {
                                let (a, b) = if left {
                                    ($constant, value)
                                } else {
                                    (value, $constant)
                                };
                                match operator {
                                    BinaryOperator::Add => a.wrapping_add(b),
                                    BinaryOperator::Sub => a.wrapping_sub(b),
                                    BinaryOperator::Mul => a.wrapping_mul(b),
                                    _ => unreachable!(),
                                }
                            })
                        }));
                        let actual = program.evaluate(&input).unwrap().into_array(len).unwrap();
                        assert_eq!(actual.as_ref(), &expected);
                    }
                }
            }
            assert_eq!(source.to_data(), original);
        }};
    }
    check!(
        Int32Array,
        Int32,
        vec![
            Some(7),
            Some(i32::MAX),
            None,
            Some(i32::MIN),
            Some(-1),
            Some(8)
        ],
        3i32
    );
    check!(
        Int64Array,
        Int64,
        vec![
            Some(7),
            Some(i64::MAX),
            None,
            Some(i64::MIN),
            Some(-1),
            Some(8)
        ],
        3i64
    );
}

#[test]
fn floating_arithmetic_preserves_operand_order_ieee_bits_and_nulls() {
    macro_rules! check {
        ($array:ty, $variant:ident, $native:ty, $nan:expr) => {{
            let source: ArrayRef = Arc::new(<$array>::from(vec![
                Some(99.0),
                Some(0.0),
                Some(-0.0),
                None,
                Some(<$native>::INFINITY),
                Some(<$native>::NEG_INFINITY),
                Some($nan),
                Some(3.5),
            ]));
            let original = source.to_data();
            let batch = RecordBatch::try_from_iter([("x", source.clone())])
                .unwrap()
                .slice(1, 7);
            for constant in [0.0, -0.0, -3.0, <$native>::INFINITY, $nan] {
                for left in [false, true] {
                    for operator in [
                        BinaryOperator::Add,
                        BinaryOperator::Sub,
                        BinaryOperator::Mul,
                    ] {
                        let native = lower(
                            &expression(ScalarValue::$variant(Some(constant)), operator, left),
                            batch.schema_ref(),
                        )
                        .unwrap();
                        let column: Arc<dyn PhysicalExpr> = Arc::new(Column::new("x", 0));
                        let literal: Arc<dyn PhysicalExpr> =
                            Arc::new(Literal::new(ScalarValue::$variant(Some(constant))));
                        let op = match operator {
                            BinaryOperator::Add => Operator::Plus,
                            BinaryOperator::Sub => Operator::Minus,
                            BinaryOperator::Mul => Operator::Multiply,
                            _ => unreachable!(),
                        };
                        let (a, b) = if left {
                            (literal, column)
                        } else {
                            (column, literal)
                        };
                        let ordinary: Arc<dyn PhysicalExpr> =
                            Arc::new(BinaryExpr::new(a, op, b).with_fail_on_overflow(true));
                        let rewritten =
                            rewrite_floats(ordinary.clone(), batch.schema_ref()).unwrap();
                        assert_eq!(
                            ordinary.return_field(batch.schema_ref()).unwrap(),
                            rewritten.return_field(batch.schema_ref()).unwrap()
                        );
                        for program in [native, rewritten] {
                            for (start, len) in [(0, 7), (1, 4), (0, 0)] {
                                let input = batch.slice(start, len);
                                let values =
                                    input.column(0).as_any().downcast_ref::<$array>().unwrap();
                                let actual =
                                    program.evaluate(&input).unwrap().into_array(len).unwrap();
                                let actual = actual.as_any().downcast_ref::<$array>().unwrap();
                                for (row, value) in values.iter().enumerate() {
                                    let expected = value.map(|value| {
                                        let (a, b) = if left {
                                            (constant, value)
                                        } else {
                                            (value, constant)
                                        };
                                        match operator {
                                            BinaryOperator::Add => a + b,
                                            BinaryOperator::Sub => a - b,
                                            BinaryOperator::Mul => a * b,
                                            _ => unreachable!(),
                                        }
                                    });
                                    assert_eq!(actual.is_null(row), expected.is_none());
                                    if let Some(expected) = expected {
                                        assert_eq!(
                                            actual.value(row).to_bits(),
                                            expected.to_bits(),
                                            "op {operator:?}, left {left}, row {row}"
                                        );
                                    }
                                }
                            }
                        }
                    }
                }
            }
            assert_eq!(source.to_data(), original);
        }};
    }
    check!(Float32Array, Float32, f32, f32::from_bits(0x7fc0_1234));
    check!(
        Float64Array,
        Float64,
        f64,
        f64::from_bits(0x7ff8_0000_0000_1234)
    );
}

#[test]
fn checked_df_integers_and_changed_children_keep_their_contract() {
    let batch =
        RecordBatch::try_from_iter([("x", Arc::new(Int32Array::from(vec![i32::MAX])) as ArrayRef)])
            .unwrap();
    let checked: Arc<dyn PhysicalExpr> = Arc::new(
        BinaryExpr::new(
            Arc::new(Column::new("x", 0)),
            Operator::Plus,
            Arc::new(Literal::new(ScalarValue::Int32(Some(1)))),
        )
        .with_fail_on_overflow(true),
    );
    let rewritten = rewrite_floats(checked.clone(), batch.schema_ref()).unwrap();
    assert!(checked.evaluate(&batch).is_err());
    assert!(rewritten.evaluate(&batch).is_err());
    let batch = RecordBatch::try_from_iter([(
        "x",
        Arc::new(Float64Array::from(vec![2.0, 4.0])) as ArrayRef,
    )])
    .unwrap();
    let original: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
        Arc::new(Column::new("x", 0)),
        Operator::Plus,
        Arc::new(Literal::new(ScalarValue::Float64(Some(1.0)))),
    ));
    let optimized = rewrite_floats(original, batch.schema_ref()).unwrap();
    let changed = optimized
        .with_new_children(vec![
            Arc::new(Column::new("x", 0)),
            Arc::new(Literal::new(ScalarValue::Float64(Some(7.0)))),
        ])
        .unwrap();
    assert_eq!(
        changed
            .evaluate(&batch)
            .unwrap()
            .into_array(2)
            .unwrap()
            .as_ref(),
        &Float64Array::from(vec![9.0, 11.0])
    );
}

#[test]
fn captured_scalar_arithmetic_stays_scalar() {
    let batch = RecordBatch::try_from_iter([(
        "unused",
        Arc::new(Int32Array::from(vec![1, 2, 3])) as ArrayRef,
    )])
    .unwrap();
    for value in [Some(2.0), None] {
        let source: Arc<dyn PhysicalExpr> = Arc::new(Literal::new(ScalarValue::Float64(value)));
        let expr: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
            source,
            Operator::Multiply,
            Arc::new(Literal::new(ScalarValue::Float64(Some(3.0)))),
        ));
        let program = rewrite_floats(expr, batch.schema_ref()).unwrap();
        let ColumnarValue::Scalar(actual) = program.evaluate(&batch).unwrap() else {
            panic!("scalar arithmetic was expanded");
        };
        assert_eq!(actual, ScalarValue::Float64(value.map(|v| v * 3.0)));
    }
}

#[test]
fn owned_slices_and_shared_value_owners_remain_unchanged() {
    use arrow_buffer::NullBuffer;
    use datafusion_expr::{Volatility, create_udf};
    use datafusion_physical_expr::ScalarFunctionExpr;
    let batch = RecordBatch::try_from_iter([(
        "dummy",
        Arc::new(Int32Array::from(vec![1, 2, 3])) as ArrayRef,
    )])
    .unwrap();
    let retained = Arc::new(Float64Array::from(vec![99.0, 1.0, 2.0, 3.0, 100.0]));
    for shared_values in [false, true] {
        let owner = retained.clone();
        let function = create_udf(
            "owned_slice_fixture",
            vec![DataType::Int32],
            DataType::Float64,
            Volatility::Immutable,
            Arc::new(move |args| {
                let rows = match &args[0] {
                    ColumnarValue::Array(value) => value.len(),
                    _ => unreachable!(),
                };
                let source = if shared_values {
                    Float64Array::new(
                        owner.values().clone(),
                        Some(NullBuffer::from(vec![true, true, false, true, true])),
                    )
                } else {
                    Float64Array::from(vec![Some(99.0), Some(1.0), None, Some(3.0), Some(100.0)])
                };
                Ok(ColumnarValue::Array(Arc::new(source.slice(1, rows))))
            }),
        );
        let source: Arc<dyn PhysicalExpr> = Arc::new(
            ScalarFunctionExpr::try_new(
                Arc::new(function),
                vec![Arc::new(Column::new("dummy", 0))],
                batch.schema_ref(),
                Default::default(),
            )
            .unwrap(),
        );
        let expression: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
            source,
            Operator::Multiply,
            Arc::new(Literal::new(ScalarValue::Float64(Some(2.0)))),
        ));
        let program = rewrite_floats(expression, batch.schema_ref()).unwrap();
        for rows in [0, 3] {
            let actual = program
                .evaluate(&batch.slice(0, rows))
                .unwrap()
                .into_array(rows)
                .unwrap();
            assert_eq!(
                actual.as_ref(),
                &Float64Array::from(vec![Some(2.0), None, Some(6.0)]).slice(0, rows)
            );
        }
        assert_eq!(
            retained.as_ref(),
            &Float64Array::from(vec![99.0, 1.0, 2.0, 3.0, 100.0])
        );
    }
}

#[test]
fn mapped_arithmetic_keeps_row_captures_in_their_original_domain() {
    use arrow_array::ListArray;
    use arrow_buffer::OffsetBuffer;
    use arrow_schema::Field;
    use serde_json::json;
    let lists: ArrayRef = Arc::new(ListArray::new(
        Arc::new(Field::new_list_field(DataType::Float64, true)),
        OffsetBuffer::new(vec![0, 2, 3].into()),
        Arc::new(Float64Array::from(vec![Some(5.0), None, Some(1.0)])),
        None,
    ));
    let batch = RecordBatch::try_from_iter([
        ("xs", lists),
        (
            "bias",
            Arc::new(Float64Array::from(vec![3.0, 10.0])) as ArrayRef,
        ),
    ])
    .unwrap();
    let expression:Expr=serde_json::from_value(json!({"op":"array_map","value":{"op":"column","name":"xs"},"parameter":"v","body":{"op":"binary","operator":"mul","left":{"op":"binary","operator":"add","left":{"op":"lambda_variable","name":"v"},"right":{"op":"literal","dtype":"float64","value":1.0}},"right":{"op":"column","name":"bias"}}})).unwrap();
    let expected = ListArray::new(
        Arc::new(Field::new_list_field(DataType::Float64, true)),
        OffsetBuffer::new(vec![0, 2, 3].into()),
        Arc::new(Float64Array::from(vec![Some(18.0), None, Some(20.0)])),
        None,
    );
    let program = lower(&expression, batch.schema_ref()).unwrap();
    assert_eq!(
        program
            .evaluate(&batch)
            .unwrap()
            .into_array(2)
            .unwrap()
            .as_ref(),
        &expected
    );
}

#[test]
fn rewrite_preparation_does_not_expand_shared_expression_diamonds() {
    let batch = RecordBatch::try_from_iter([(
        "x",
        Arc::new(Float64Array::from(vec![Some(1.0), None, Some(-2.0)])) as ArrayRef,
    )])
    .unwrap();
    let mut costs = vec![];
    for depth in [6, 12] {
        let mut expression: Arc<dyn PhysicalExpr> = Arc::new(Column::new("x", 0));
        for _ in 0..depth {
            let next: Arc<dyn PhysicalExpr> = Arc::new(BinaryExpr::new(
                expression,
                Operator::Plus,
                Arc::new(Literal::new(ScalarValue::Float64(Some(1.0)))),
            ));
            expression = Arc::new(BinaryExpr::new(next.clone(), Operator::Plus, next));
        }
        ALLOCATED.with(|bytes| bytes.set(Some(0)));
        let rewritten = rewrite_floats(expression, batch.schema_ref()).unwrap();
        costs.push(ALLOCATED.with(|bytes| bytes.replace(None).unwrap()));
        let expected = Float64Array::from(vec![
            Some((0..depth).fold(1.0, |v, _| (v + 1.0) * 2.0)),
            None,
            Some(-2.0),
        ]);
        assert_eq!(
            rewritten
                .evaluate(&batch)
                .unwrap()
                .into_array(3)
                .unwrap()
                .as_ref(),
            &expected
        );
    }
    eprintln!("shared DAG rewrite allocation: {costs:?}");
    assert!(
        costs[1] < costs[0] * 4 + 4096,
        "shared expression preparation expanded: {costs:?}"
    );
}
