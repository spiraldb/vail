//! Native public expression costs; fixtures and complete Arrow oracles untimed.
use arrow_array::{ArrayRef, Float64Array, ListArray, RecordBatch};
use arrow_buffer::{NullBuffer, OffsetBuffer};
use arrow_schema::{DataType, Field};
use datafusion_common::ScalarValue;
use serde_json::json;
use std::{
    sync::Arc,
    time::{Duration, Instant},
};
use vail_execution::expressions::{BinaryOperator, Expr, lower};
fn number(value: f64) -> Expr {
    Expr::RuntimeLiteral {
        value: ScalarValue::Float64(Some(value)),
    }
}
fn binary(operator: BinaryOperator, left: Expr, right: Expr) -> Expr {
    Expr::Binary {
        operator,
        left: Arc::new(left),
        right: Arc::new(right),
    }
}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    let case = args.get(1).map(String::as_str).unwrap_or("temporary");
    let count: usize = args.get(2).map(|s| s.parse().unwrap()).unwrap_or(131_072);
    let input = (0..count)
        .map(|i| (i % 11 != 0).then_some(i as f64 / 10.0 - 31.0))
        .collect::<Vec<_>>();
    let expected = Float64Array::from_iter(input.iter().map(|v| {
        v.map(|v| match case {
            "identity" => v,
            "borrowed" => v + 1.0,
            "shared" => v * 2.0 + v * 3.0,
            "temporary" | "map" => ((v + 1.0) * 2.0) - 3.0,
            _ => panic!("unknown case"),
        })
    }));
    let values: ArrayRef = Arc::new(Float64Array::from(input));
    let mapped = case == "map";
    let variable = if mapped {
        Expr::LambdaVariable {
            name: "v".into(),
            dtype: None,
        }
    } else {
        Expr::Column { name: "x".into() }
    };
    let mut expression = match case {
        "identity" => variable,
        "borrowed" => binary(BinaryOperator::Add, variable, number(1.0)),
        "shared" => binary(
            BinaryOperator::Add,
            binary(BinaryOperator::Mul, variable.clone(), number(2.0)),
            binary(BinaryOperator::Mul, variable, number(3.0)),
        ),
        _ => binary(
            BinaryOperator::Sub,
            binary(
                BinaryOperator::Mul,
                binary(BinaryOperator::Add, variable, number(1.0)),
                number(2.0),
            ),
            number(3.0),
        ),
    };
    let (batch, expected): (RecordBatch, ArrayRef) = if mapped {
        let rows = count.div_ceil(32);
        let offsets = OffsetBuffer::new(
            (0..=rows)
                .map(|i| (i * 32).min(count) as i32)
                .collect::<Vec<_>>()
                .into(),
        );
        let nulls = Some(NullBuffer::from_iter((0..rows).map(|i| i % 17 != 16)));
        let field = Arc::new(Field::new_list_field(DataType::Float64, true));
        let list: ArrayRef = Arc::new(ListArray::new(
            field.clone(),
            offsets.clone(),
            values,
            nulls.clone(),
        ));
        let expected: ArrayRef =
            Arc::new(ListArray::new(field, offsets, Arc::new(expected), nulls));
        expression = Expr::ArrayMap {
            value: Arc::new(Expr::Column { name: "xs".into() }),
            parameter: "v".into(),
            body: Arc::new(expression),
        };
        (
            RecordBatch::try_from_iter([("xs", list)]).unwrap(),
            expected,
        )
    } else {
        (
            RecordBatch::try_from_iter([("x", values)]).unwrap(),
            Arc::new(expected),
        )
    };
    let start = Instant::now();
    let program = lower(&expression, batch.schema_ref()).unwrap();
    let preparation = start.elapsed().as_secs_f64();
    let start = Instant::now();
    let output = program
        .evaluate(&batch)
        .unwrap()
        .into_array(batch.num_rows())
        .unwrap();
    let first = start.elapsed().as_secs_f64();
    assert_eq!(output.as_ref(), expected.as_ref());
    drop(output);
    let mut warmed = vec![];
    for _ in 0..5 {
        let start = Instant::now();
        let fresh = lower(&expression, batch.schema_ref()).unwrap();
        warmed.push(start.elapsed().as_secs_f64());
        assert_eq!(
            fresh
                .evaluate(&batch)
                .unwrap()
                .into_array(batch.num_rows())
                .unwrap()
                .as_ref(),
            expected.as_ref()
        );
    }
    let mut samples = vec![];
    for _ in 0..5 {
        let start = Instant::now();
        let mut n = 0;
        while start.elapsed() < Duration::from_millis(20) {
            std::hint::black_box(program.evaluate(&batch).unwrap());
            n += 1;
        }
        samples.push(start.elapsed().as_secs_f64() / n as f64);
    }
    println!(
        "{}",
        json!({"case":case,"values":count,"rows":batch.num_rows(),"validated":true,"prepare_seconds":preparation,"first_seconds":first,"prepare_plus_first_seconds":preparation+first,"warmed_preparation_seconds":warmed,"evaluation_wall_seconds":samples,"cpu_measured":false})
    );
}
