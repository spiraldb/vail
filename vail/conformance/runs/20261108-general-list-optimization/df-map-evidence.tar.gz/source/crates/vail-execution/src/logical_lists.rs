//! Keep ordinary list operations visible until relational projections combine.
use super::*;
use datafusion_common::datatype::FieldExt;
use datafusion_common::tree_node::TreeNodeRecursion;
use datafusion_common::tree_node::{Transformed, TreeNode};
use datafusion_expr::expr::{HigherOrderFunction, Lambda, LambdaVariable};
use std::collections::HashMap;

pub(super) type Analysis = Option<Arc<HashSet<String>>>;

fn analyze(body: &Expr, shared: &HashSet<usize>) -> Analysis {
    let mut names = HashSet::new();
    let mut seen = HashSet::new();
    let mut pending = vec![body];
    while let Some(node) = pending.pop() {
        if !seen.insert(node as *const Expr as usize) {
            continue;
        }
        let supported = match node {
            Expr::Literal {
                dtype:
                    Type::Primitive(
                        PrimitiveType::Bool
                        | PrimitiveType::Int32
                        | PrimitiveType::Int64
                        | PrimitiveType::Float32
                        | PrimitiveType::Float64
                        | PrimitiveType::Str,
                    ),
                ..
            }
            | Expr::RuntimeLiteral {
                value:
                    ScalarValue::Boolean(_)
                    | ScalarValue::Int32(_)
                    | ScalarValue::Int64(_)
                    | ScalarValue::Float32(_)
                    | ScalarValue::Float64(_)
                    | ScalarValue::Utf8(_),
            }
            | Expr::LambdaVariable { .. }
            | Expr::GetField { .. }
            | Expr::Unary { .. }
            | Expr::IsMissing { .. } => true,
            Expr::Binary { operator, .. } | Expr::IntegerBinary { operator, .. } => matches!(
                operator,
                BinaryOperator::Add
                    | BinaryOperator::Sub
                    | BinaryOperator::Mul
                    | BinaryOperator::Eq
                    | BinaryOperator::Ne
                    | BinaryOperator::Lt
                    | BinaryOperator::Le
                    | BinaryOperator::Gt
                    | BinaryOperator::Ge
                    | BinaryOperator::And
                    | BinaryOperator::Or
            ),
            Expr::Struct { fields } => {
                !fields.is_empty() && fields.iter().all(|(name, _)| !name.is_empty())
            }
            Expr::Tuple { elements } => !elements.is_empty(),
            _ => false,
        };
        if !supported
            || shared.contains(&(node as *const Expr as usize))
            || crate::expression_effects::own_effect(node)
                != crate::expression_effects::Effects::Pure
            || matches!(
                node,
                Expr::Column { .. } | Expr::Global { .. } | Expr::ExternalGlobal { .. }
            )
        {
            return None;
        }
        if let Expr::LambdaVariable { name, .. } = node {
            names.insert(name.clone());
            if names.len() > 1 {
                return None;
            }
        }
        let mut index = 0;
        let mut binder = false;
        node.for_each_child(&mut |child| {
            binder |= !node.child_binders(index).is_empty();
            index += 1;
            pending.push(child);
        });
        if binder {
            return None;
        }
    }
    Some(Arc::new(names))
}

// A virtual Call/Locus/Set/Dict accessor may validate or normalize its input.
// Only ordinary struct/tuple reads participate in this initial container rule.
fn ordinary_fields(body: &Expr, parameter: &str, element: &Type) -> bool {
    fn resolve<'a>(
        node: &Expr,
        parameter: &str,
        element: &'a Type,
        memo: &mut HashMap<usize, Option<&'a Type>>,
        fields: &mut HashMap<usize, HashMap<&'a str, &'a Type>>,
    ) -> Option<&'a Type> {
        let key = node as *const Expr as usize;
        if let Some(value) = memo.get(&key) {
            return *value;
        }
        let value = match node {
            Expr::LambdaVariable { name, .. } | Expr::Column { name } if name == parameter => {
                Some(element)
            }
            Expr::GetField { value, name } => {
                match resolve(value, parameter, element, memo, fields) {
                    Some(Type::Struct { r#struct }) => {
                        let index = fields.entry(r#struct.as_ptr() as usize).or_insert_with(|| {
                            let mut index = HashMap::new();
                            for (name, ty) in r#struct {
                                index.entry(name.as_str()).or_insert(ty);
                            }
                            index
                        });
                        index.get(name.as_str()).copied()
                    }
                    Some(Type::Tuple { tuple }) => name
                        .strip_prefix("__vail_tuple_")
                        .and_then(|s| s.parse::<usize>().ok())
                        .and_then(|i| tuple.get(i)),
                    _ => None,
                }
            }
            _ => None,
        };
        memo.insert(key, value);
        value
    }
    let mut memo = HashMap::new();
    let mut fields = HashMap::new();
    let mut allowed = true;
    body.visit_unique(&mut |node| match node {
        Expr::GetField { .. } => {
            allowed &= resolve(node, parameter, element, &mut memo, &mut fields).is_some()
        }
        Expr::LambdaVariable {
            dtype: Some(declared),
            ..
        } => allowed &= declared == element,
        _ => {}
    });
    allowed
}

pub(super) fn lower_list(
    expression: &Expr,
    schema: &DFSchema,
    globals: &Schema,
    bindings: &BTreeMap<String, usize>,
    scope: &[String],
    context: &LoweringContext,
) -> Result<Option<LogicalExpr>, ExprError> {
    if !context.visible_lists || !scope.is_empty() {
        return Ok(None);
    }
    let (value, parameter, body, filter) = match expression {
        Expr::ArrayMap {
            value,
            parameter,
            body,
        } => (value, parameter, body, false),
        Expr::ArrayFilter {
            value,
            parameter,
            predicate,
        } => (value, parameter, predicate, true),
        _ => return Ok(None),
    };
    let analysis = context
        .list_analysis
        .borrow_mut()
        .entry(body.as_ref() as *const Expr as usize)
        .or_insert_with(|| analyze(body, &context.shared))
        .clone();
    let Some(reserved) = analysis else {
        return Ok(None);
    };
    if reserved.len() != 1 || !reserved.contains(parameter) {
        return Ok(None);
    }
    // Existing direct-output flatmaps retain their current preparation path.
    let mut source = value.as_ref();
    let mut visited = Vec::new();
    let allowed = loop {
        let key = source as *const Expr as usize;
        if let Some(allowed) = context.list_spines.borrow().get(&key) {
            break *allowed;
        }
        visited.push(key);
        match source {
            Expr::ArrayMap { value, .. } | Expr::ArrayFilter { value, .. } => source = value,
            Expr::ArrayFlatten { .. } | Expr::ArrayFold { .. } => break false,
            _ => break true,
        }
    };
    context
        .list_spines
        .borrow_mut()
        .extend(visited.into_iter().map(|key| (key, allowed)));
    if !allowed {
        return Ok(None);
    }
    let input = lower(value, schema, globals, bindings, scope, context)?;
    let input_type = if let Some(dtype) = context
        .arrow_types
        .borrow()
        .get(&(value.as_ref() as *const Expr as usize))
    {
        dtype.clone()
    } else {
        input.get_type(schema)?
    };
    let Ok(logical_type) = Type::from_arrow(&input_type) else {
        return Ok(None);
    };
    if logical_type.to_arrow()? != input_type {
        return Ok(None);
    }
    let Type::Array {
        array: element_type,
    } = logical_type
    else {
        return Ok(None);
    };
    if !ordinary_fields(body, parameter, &element_type) {
        return Ok(None);
    }
    let DataType::List(element) = &input_type else {
        return Ok(None);
    };
    let mut name = "__vail_lambda".to_owned();
    while reserved.contains(&name) {
        name.push('_');
    }
    // Admission above excludes nested binders: every occurrence of this name
    // belongs to this callback. Column/Global/ExternalGlobal remain separate.
    fn rename(
        node: &Expr,
        shared: bool,
        old: &str,
        name: &str,
        memo: &mut HashMap<usize, Arc<Expr>>,
    ) -> Result<RebuiltExpr, ExprError> {
        let key = node as *const Expr as usize;
        if shared {
            if let Some(cached) = memo.get(&key) {
                return Ok(RebuiltExpr::Shared(cached.clone()));
            }
        }
        let value = if let Expr::LambdaVariable { name: variable, .. } = node {
            if variable == old {
                Expr::Column {
                    name: name.to_owned(),
                }
            } else {
                node.clone()
            }
        } else {
            node.try_map_children_rebuilt(|child, shared| rename(child, shared, old, name, memo))?
        };
        if shared {
            let value = Arc::new(value);
            memo.insert(key, value.clone());
            Ok(RebuiltExpr::Shared(value))
        } else {
            Ok(RebuiltExpr::Owned(value))
        }
    }
    let native_body = rename(body, false, parameter, &name, &mut HashMap::new())?.into_owned();
    let parameter_field = element.clone().renamed(&name);
    let frame = DFSchema::try_from(Schema::new(vec![parameter_field]))?;
    let expected_type = native_body.dtype(frame.as_arrow())?.to_arrow()?;
    let callback_context = LoweringContext::new(&native_body, true, context.options.clone());
    let body = lower(
        &native_body,
        &frame,
        &Schema::empty(),
        &BTreeMap::new(),
        &[],
        &callback_context,
    )?;
    let body = coerce_type(body, expected_type.clone(), &frame)?;
    let mut opaque = false;
    body.apply(|node| {
        opaque |= matches!(node, LogicalExpr::ScalarFunction(call) if semantic_kernel(&call.func).is_some());
        Ok(datafusion_common::tree_node::TreeNodeRecursion::Continue)
    })?;
    if opaque {
        return Ok(None);
    }
    let body = body.transform_up(|node| {
        Ok(if matches!(&node,LogicalExpr::Column(column) if column.name == name && column.relation.is_none()) {
            Transformed::yes(LogicalExpr::LambdaVariable(LambdaVariable::new(name.clone(),Some(element.clone()))))
        } else { Transformed::no(node) })
    })?.data;
    let function = if filter {
        datafusion_functions_nested::array_filter::array_filter_higher_order_function()
    } else {
        datafusion_functions_nested::array_transform::array_transform_higher_order_function()
    };
    let invocation = LogicalExpr::HigherOrderFunction(HigherOrderFunction::new(
        function,
        vec![input, LogicalExpr::Lambda(Lambda::new(vec![name], body))],
    ));
    let output_type = if filter {
        input_type
    } else {
        DataType::List(Arc::new(arrow_schema::Field::new_list_field(
            expected_type,
            true,
        )))
    };
    let invocation = coerce_type(invocation, output_type.clone(), schema)?;
    context
        .arrow_types
        .borrow_mut()
        .insert(expression as *const Expr as usize, output_type);
    Ok(Some(invocation))
}

pub(super) type FieldCache = HashMap<usize, Arc<StructDescriptor>>;
pub(super) struct StructDescriptor {
    dtype: DataType,
    identity: usize,
    fingerprint: u64,
    indices: HashMap<String, usize>,
}
impl StructDescriptor {
    fn matches(&self, dtype: &DataType) -> bool {
        matches!(dtype, DataType::Struct(fields) if fields.as_ptr() as usize == self.identity)
            || dtype == &self.dtype
    }
}
struct StructField {
    parent: Arc<StructDescriptor>,
    index: usize,
    output: arrow_schema::FieldRef,
    signature: Signature,
    name: String,
}
impl std::fmt::Debug for StructField {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.name)
    }
}
impl PartialEq for StructField {
    fn eq(&self, other: &Self) -> bool {
        self.index == other.index
            && self.parent.fingerprint == other.parent.fingerprint
            && self.parent.matches(&other.parent.dtype)
    }
}
impl Eq for StructField {}
impl std::hash::Hash for StructField {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        std::hash::Hash::hash(&self.parent.fingerprint, state);
        std::hash::Hash::hash(&self.index, state);
    }
}
impl datafusion_expr::ScalarUDFImpl for StructField {
    fn name(&self) -> &str {
        &self.name
    }
    fn signature(&self) -> &Signature {
        &self.signature
    }
    fn return_type(&self, args: &[DataType]) -> DfResult<DataType> {
        if args.len() != 1 || !self.parent.matches(&args[0]) {
            return Err(DataFusionError::Plan(
                "ordinary field input type changed".into(),
            ));
        }
        Ok(self.output.data_type().clone())
    }
    fn return_field_from_args(
        &self,
        args: datafusion_expr::ReturnFieldArgs,
    ) -> DfResult<arrow_schema::FieldRef> {
        if args.arg_fields.len() != 1 || !self.parent.matches(args.arg_fields[0].data_type()) {
            return Err(DataFusionError::Plan(
                "ordinary field input descriptor changed".into(),
            ));
        }
        Ok(self.output.clone())
    }
    fn invoke_with_args(
        &self,
        args: datafusion_expr::ScalarFunctionArgs,
    ) -> DfResult<ColumnarValue> {
        let scalar = matches!(&args.args[0], ColumnarValue::Scalar(_));
        let value = args.args[0]
            .clone()
            .into_array(if scalar { 1 } else { args.number_rows })?;
        let parent = value
            .as_any()
            .downcast_ref::<StructArray>()
            .ok_or_else(|| {
                DataFusionError::Execution("ordinary field requires struct input".into())
            })?;
        let child = parent.column(self.index);
        let output = if parent.null_count() == 0 || child.data_type() == &DataType::Null {
            child.clone()
        } else {
            if matches!(
                child.data_type(),
                DataType::Union(..) | DataType::RunEndEncoded(..)
            ) {
                return Err(DataFusionError::Execution(
                    "field layout cannot carry a validity mask".into(),
                ));
            }
            let nulls = NullBuffer::union(parent.nulls(), child.nulls());
            // SAFETY: a valid StructArray gives parent and child equal logical
            // lengths, including slices. The union only clears validity bits;
            // the valid child's type, values, offsets and children stay intact.
            // Admitted canonical layouts support validity; maskless layouts are
            // also rejected above if an unexpected physical input reaches here.
            let data = unsafe {
                child
                    .to_data()
                    .into_builder()
                    .nulls(nulls)
                    .build_unchecked()
            };
            make_array(data)
        };
        if scalar {
            crate::expressions::scalar_at(&output, 0)
                .map(ColumnarValue::Scalar)
                .map_err(|e| DataFusionError::Execution(e.to_string()))
        } else {
            Ok(ColumnarValue::Array(output))
        }
    }
}

// Unlike DF's ordinary get_field, a Hail read includes its ancestors' validity.
// Indices, descriptor identity and result Field are prepared once per callback.
pub(super) fn field(
    expression: &Expr,
    source: &Expr,
    input: LogicalExpr,
    name: &str,
    schema: &DFSchema,
    context: &LoweringContext,
) -> Result<LogicalExpr, ExprError> {
    use std::hash::{Hash, Hasher};
    let input_type = if let Some(dtype) = context
        .arrow_types
        .borrow()
        .get(&(source as *const Expr as usize))
    {
        dtype.clone()
    } else {
        input.get_type(schema)?
    };
    let DataType::Struct(fields) = &input_type else {
        return Err(ExprError::Invalid(
            "ordinary field requires struct input".into(),
        ));
    };
    let identity = fields.as_ptr() as usize;
    let descriptor = context
        .field_descriptors
        .borrow_mut()
        .entry(identity)
        .or_insert_with(|| {
            let mut indices = HashMap::new();
            for (index, field) in fields.iter().enumerate() {
                indices.entry(field.name().clone()).or_insert(index);
            }
            let mut hash = std::collections::hash_map::DefaultHasher::new();
            input_type.hash(&mut hash);
            Arc::new(StructDescriptor {
                dtype: input_type.clone(),
                identity,
                fingerprint: hash.finish(),
                indices,
            })
        })
        .clone();
    let index = *descriptor
        .indices
        .get(name)
        .ok_or_else(|| ExprError::Invalid(format!("struct field {name:?} absent")))?;
    let output_type = fields[index].data_type().clone();
    context
        .arrow_types
        .borrow_mut()
        .insert(source as *const Expr as usize, input_type);
    context
        .arrow_types
        .borrow_mut()
        .insert(expression as *const Expr as usize, output_type.clone());
    let function = datafusion_expr::ScalarUDF::from(StructField {
        parent: descriptor,
        index,
        output: Arc::new(arrow_schema::Field::new("", output_type, true)),
        signature: Signature::any(1, Volatility::Immutable),
        name: format!("vail_struct_field_{index}"),
    });
    Ok(function.call(vec![input]))
}

fn map_parts(expression: &LogicalExpr) -> Option<(&LogicalExpr, &Lambda)> {
    use datafusion_functions_nested::array_transform::ArrayTransform;
    let LogicalExpr::HigherOrderFunction(call) = expression else {
        return None;
    };
    let implementation: &dyn std::any::Any = call.func.inner().as_ref();
    if !implementation.is::<ArrayTransform>() {
        return None;
    }
    let [source, LogicalExpr::Lambda(lambda)] = call.args.as_slice() else {
        return None;
    };
    (lambda.params.len() == 1).then_some((source, lambda))
}

// These scalar operations are total in Vail's ordinary DF lowering. Unknown
// functions, captures and binders retain their existing evaluation boundary.
fn parameter_uses(
    body: &LogicalExpr,
    parameter: &str,
    field: &arrow_schema::FieldRef,
) -> Option<usize> {
    use datafusion_functions::core::named_struct::NamedStructFunc;
    let mut count = 0usize;
    let mut allowed = true;
    body.apply(|node| {
        allowed &= match node {
            LogicalExpr::LambdaVariable(variable)
                if variable.name == parameter && variable.field.as_ref() == Some(field) =>
            {
                count = count.saturating_add(1);
                true
            }
            LogicalExpr::Literal(..)
            | LogicalExpr::Negative(_)
            | LogicalExpr::Not(_)
            | LogicalExpr::IsNull(_)
            | LogicalExpr::IsNotNull(_) => true,
            LogicalExpr::BinaryExpr(binary) => matches!(
                binary.op,
                Operator::Plus
                    | Operator::Minus
                    | Operator::Multiply
                    | Operator::Eq
                    | Operator::NotEq
                    | Operator::Lt
                    | Operator::LtEq
                    | Operator::Gt
                    | Operator::GtEq
                    | Operator::And
                    | Operator::Or
            ),
            LogicalExpr::ScalarFunction(call) => {
                call.func.inner().is::<StructField>() || call.func.inner().is::<NamedStructFunc>()
            }
            _ => false,
        };
        Ok(if allowed {
            TreeNodeRecursion::Continue
        } else {
            TreeNodeRecursion::Stop
        })
    })
    .ok()?;
    allowed.then_some(count)
}

fn cheap(body: &LogicalExpr, parameter: &str) -> bool {
    matches!(body, LogicalExpr::LambdaVariable(variable) if variable.name == parameter)
        || matches!(
            body,
            LogicalExpr::Literal(
                ScalarValue::Boolean(_)
                    | ScalarValue::Int32(_)
                    | ScalarValue::Int64(_)
                    | ScalarValue::Float32(_)
                    | ScalarValue::Float64(_),
                _
            )
        )
}

fn compose(expression: &LogicalExpr, schema: &DFSchema) -> Option<LogicalExpr> {
    let (source, _) = map_parts(expression)?;
    map_parts(source)?;
    // One clone and one pass over this map spine. Moving the producer into a
    // single use avoids repeatedly copying growing callback suffixes.
    let (_, expected) = expression.to_field(schema).ok()?;
    let mut source = expression.clone();
    let mut stages = Vec::new();
    while map_parts(&source).is_some() {
        let LogicalExpr::HigherOrderFunction(mut call) = source else {
            unreachable!()
        };
        let LogicalExpr::Lambda(lambda) = call.args.pop()? else {
            unreachable!()
        };
        source = call.args.pop()?;
        stages.push(lambda);
    }
    let DataType::List(mut element) = source.get_type(schema).ok()? else {
        return None;
    };
    let mut uses = Vec::with_capacity(stages.len());
    for stage in stages.iter().rev() {
        uses.push(parameter_uses(&stage.body, &stage.params[0], &element)?);
        let (_, output) = stage.body.to_field(&DFSchema::empty()).ok()?;
        element = Arc::new(arrow_schema::Field::new_list_field(
            output.data_type().clone(),
            output.is_nullable(),
        ));
    }
    uses.reverse();
    let mut producer = stages.pop()?;
    uses.pop()?;
    let mut changed = false;
    while let Some(consumer) = stages.pop() {
        let consumer_uses = uses.pop()?;
        let fuse =
            consumer_uses == 1 || (consumer_uses > 1 && cheap(&producer.body, &producer.params[0]));
        if !fuse {
            source = LogicalExpr::HigherOrderFunction(HigherOrderFunction::new(
                datafusion_functions_nested::array_transform::array_transform_higher_order_function(
                ),
                vec![source, LogicalExpr::Lambda(producer)],
            ));
            producer = consumer;
            continue;
        }
        let single_use = consumer_uses == 1;
        let mut body = Some(*producer.body);
        let body = (*consumer.body).transform_up(|node| {
            Ok(if matches!(&node, LogicalExpr::LambdaVariable(variable) if variable.name == consumer.params[0]) {
                Transformed::yes(if single_use { body.take().unwrap() } else { body.as_ref().unwrap().clone() })
            } else { Transformed::no(node) })
        }).ok()?.data;
        producer.body = Box::new(body);
        changed = true;
    }
    if !changed {
        return None;
    }
    let fused = LogicalExpr::HigherOrderFunction(HigherOrderFunction::new(
        datafusion_functions_nested::array_transform::array_transform_higher_order_function(),
        vec![source, LogicalExpr::Lambda(producer)],
    ));
    let (_, actual) = fused.to_field(schema).ok()?;
    // The enclosing projection retains its output name; every other Field
    // property, including nested metadata/nullability, must match exactly.
    (actual.clone().renamed("") == expected.clone().renamed("")).then_some(fused)
}
pub(super) fn prepare(expression: LogicalExpr, schema: &DFSchema) -> DfResult<LogicalExpr> {
    let name = expression.name_for_alias()?;
    let rewritten = expression.transform_down(|expression| {
        Ok(
            if map_parts(&expression).is_some_and(|(source, _)| map_parts(source).is_some()) {
                if let Some(fused) = compose(&expression, schema) {
                    Transformed::new(fused, true, TreeNodeRecursion::Jump)
                } else {
                    Transformed::new(expression, false, TreeNodeRecursion::Jump)
                }
            } else {
                Transformed::no(expression)
            },
        )
    })?;
    if rewritten.transformed {
        rewritten.data.alias_if_changed(name)
    } else {
        Ok(rewritten.data)
    }
}
