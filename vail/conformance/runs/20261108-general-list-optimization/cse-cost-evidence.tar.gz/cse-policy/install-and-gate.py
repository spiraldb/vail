import pathlib,subprocess,os,sys,json,hashlib,time
root=pathlib.Path('/private/tmp/vail-general-list-20261108/cse-policy')
repo=pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail')
wheel=next((root/'wheels').glob('*.whl'))
venv=root/'env';python=venv/'bin/python'
subprocess.run(['uv','venv','--clear','--python','/Users/danielking/projects/vail/vail/.venv/bin/python',str(venv)],check=True)
subprocess.run(['uv','pip','install','--python',str(python),'--no-deps',str(wheel)],check=True)
site=next((venv/'lib').glob('python*/site-packages'))
(site/'vail-test-dependencies.pth').write_text('/Users/danielking/projects/vail/vail/.venv/lib/python3.12/site-packages\n')
env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_') and k!='PYTHONPATH'}
env.update(RAYON_NUM_THREADS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
identity=json.loads(subprocess.check_output([str(python),'-c',"import vail,vail._native,pathlib,hashlib,json; print(json.dumps({'package':vail.__file__,'native':vail._native.__file__,'native_sha256':hashlib.sha256(pathlib.Path(vail._native.__file__).read_bytes()).hexdigest(),'frontend':{str(p.relative_to(pathlib.Path(vail.__file__).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(vail.__file__).parent.rglob('*.py')}}))"],env=env,text=True))
identity.update(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest())
assert identity['source'].startswith('28aa1bd79')
(root/'masking-package.json').write_text(json.dumps(identity,indent=2))
pins=json.loads((root/'pins.json').read_text());pins['native']['after']=identity['native_sha256'];pins['frontend']['after']=identity['frontend'];(root/'pins.json').write_text(json.dumps(pins,indent=2))
files=pathlib.Path('/private/tmp/vail-flatmap-evidence-20261106/python-test-files.txt').read_text().splitlines()
cmd=[str(python),'-m','pytest','-q',*files,'--deselect','python/tests/test_collection_functions.py::test_corr_long_arrays_use_shared_constant_size_reducer_state']
start=time.monotonic()
with (root/'masking-python.log').open('w') as out:
 result=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
receipt={'command':cmd,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-start,'identity':identity,'excluded_preexisting':'test_corr_long_arrays_use_shared_constant_size_reducer_state'}
(root/'masking-python-receipt.json').write_text(json.dumps(receipt,indent=2));print('Python gate',result.returncode,round(receipt['elapsed_seconds'],2),flush=True);sys.exit(result.returncode)
