import subprocess,pathlib,json,os,hashlib,psutil,signal,time,statistics
root=pathlib.Path('/private/tmp/vail-general-list-20261108/cse-policy/micro');root.mkdir()
exe=pathlib.Path('/private/tmp/vail-split-sort-target/release/examples/cse_cost')
source=pathlib.Path('/private/tmp/vail-list-flatmap-20261106/vail/crates/vail-execution/examples/cse_cost.rs')
env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_')}
env.update(RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
records=[]
for case in ['cheap','arithmetic','lower']:
 for rows in [1,16,65536]:
  for i,mode in enumerate(['direct','bound','bound','direct','direct','bound','bound','direct']):
   out=root/f'{case}-{rows}-{i}-{mode}';out.mkdir();p=None
   try:
    with (out/'stdout').open('w') as so,(out/'stderr').open('w') as se:
     p=subprocess.Popen([str(exe),case,mode,str(rows)],env=env,stdout=so,stderr=se,start_new_session=True)
     identity=psutil.Process(p.pid).create_time();code=p.wait(timeout=15)
   finally:
    if p is not None:
     if p.poll() is None:
      assert psutil.Process(p.pid).create_time()==identity and os.getpgid(p.pid)==p.pid
      os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
     try:os.killpg(p.pid,0);raise AssertionError('group remains')
     except ProcessLookupError:pass
     (out/'exit.json').write_text(json.dumps({'returncode':p.returncode,'group_absent':True}))
   assert code==0,(case,rows,mode,(out/'stderr').read_text()[-1000:])
   rec=json.loads((out/'stdout').read_text());assert rec['validated'] and len(rec['evaluation_wall_seconds'])==5
   rec.update(process=i,mode=mode);records.append(rec)
  print(case,rows,{mode:statistics.median(statistics.median(x['evaluation_wall_seconds']) for x in records if x['case']==case and x['rows']==rows and x['mode']==mode) for mode in ['direct','bound']},flush=True)
(root/'records.json').write_text(json.dumps(records,indent=2));(root/'pins.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'production':'28aa1bd799a666c9361dbbdc3f3f2d629766d199','scope':'generated public prepared-expression experiment, not Hail benchmark; evalwall and preparation separate, no evalCPU claim'},indent=2))
