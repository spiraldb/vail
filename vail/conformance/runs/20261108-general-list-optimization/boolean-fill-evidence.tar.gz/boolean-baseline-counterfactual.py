import pathlib, subprocess, os, json, hashlib, signal, psutil
root = pathlib.Path('/private/tmp/vail-general-list-20261108/boolean-fill')
root.mkdir(exist_ok=True)
repo = pathlib.Path('/private/tmp/vail-list-flatmap-20261106')
files = ['vail/crates/vail-execution/src/expressions.rs', 'vail/crates/vail-execution/src/logical_expr.rs', 'vail/crates/vail-execution/src/lib.rs']
saved = {name: (repo / name).read_bytes() for name in files}
hashes = {name: hashlib.sha256(data).hexdigest() for name, data in saved.items()}
env = dict(os.environ, RUSTC_WRAPPER='/Users/danielking/.cargo/bin/kache', CARGO_BUILD_JOBS='2', CARGO_TARGET_DIR='/private/tmp/vail-split-sort-target')
receipts = []
try:
    for name in files:
        (repo / name).write_bytes(subprocess.check_output(['git', 'show', '562f8e38eb36fcc07629d0a836fa14a7a264c728:' + name], cwd=repo))
    baseline_hashes = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in files}
    for name, args in [
        ('allocation-counterfactual', ['--test', 'masked_read', 'boolean_null_filling_does_not_gather_unused_record_payload']),
        ('baseline-csv-assertion', ['--test', 'csv_line', 'csv_projection_rejects_malformed_quotes_extra_records_and_wrong_counts']),
    ]:
        command = ['cargo', 'test', '--release', '--offline', '-p', 'vail-execution', *args, '--', '--nocapture']
        process = None
        try:
            with (root / (name + '.log')).open('w') as log:
                process = subprocess.Popen(command, cwd=repo / 'vail', env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                birth = psutil.Process(process.pid).create_time()
                code = process.wait(timeout=900)
        finally:
            if process is not None:
                if process.poll() is None:
                    assert psutil.Process(process.pid).create_time() == birth and os.getpgid(process.pid) == process.pid
                    os.killpg(process.pid, signal.SIGTERM)
                    process.wait(timeout=5)
                try:
                    os.killpg(process.pid, 0)
                    raise RuntimeError('owned group remains')
                except ProcessLookupError:
                    pass
        receipts.append({'name': name, 'command': command, 'returncode': code, 'group_absent': True})
        (root / 'baseline-receipts.json').write_text(json.dumps(receipts, indent=2))
        assert code == 101, (name, code)
finally:
    for name, data in saved.items():
        (repo / name).write_bytes(data)
    restored = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in files}
    assert restored == hashes
    (root / 'baseline-source-restore.json').write_text(json.dumps({'before': hashes, 'baseline': baseline_hashes, 'restored': restored, 'exact_match': True}, indent=2))
