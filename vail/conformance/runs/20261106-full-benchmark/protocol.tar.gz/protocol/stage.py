"""One bounded fresh cloud stage, followed by metadata-only evidence packing."""
import argparse,hashlib,json,os,signal,subprocess,sys,tarfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
p=argparse.ArgumentParser();p.add_argument('name',choices=['prepare','preflight','rep1','rep2','rep3','final']);a=p.parse_args()
for name,digest in json.loads((HERE/'ASSETS.json').read_text()).items():
 if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Protocol asset changed:'+name)
cap=7200 if a.name.startswith('rep') else (5400 if a.name=='prepare' else 3600)
out=ROOT/'results';out.mkdir(exist_ok=True)
if a.name!='prepare' and (out/a.name).exists():raise RuntimeError('Fresh stage required')
if a.name=='prepare':command=[sys.executable,str(HERE/'prepare.py')]
else:
 lock=json.loads((ROOT/'artifact-lock.json').read_text());py=lock['current']['python']
 command=([py,str(HERE/'enroll.py'),'--out',str(out/'final-enrollment.json'),'--check',str(out/'enrollment.json'),'--full'] if a.name=='final' else [py,str(HERE/'phase.py'),'--phase',a.name,'--out',str(out/a.name),'--enrollment',str(out/'enrollment.json')])
signal.alarm(cap+60);started=time.monotonic();proc=subprocess.Popen(command,start_new_session=True);success=False;status=None
try:
 while proc.poll() is None:
  if time.monotonic()-started>=cap:raise TimeoutError('Stage cap')
  if os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize<10*1024**3:raise RuntimeError('10GiB disk floor')
  time.sleep(.5)
 status=proc.returncode
 if status:raise RuntimeError('Stage failed; provider STOP before collection')
 try:os.killpg(proc.pid,0)
 except ProcessLookupError:pass
 else:raise RuntimeError('Stage group survives; STOP first')
 archive=ROOT/(a.name+'.tar.gz');total=0
 paths=([ROOT/'artifact-lock.json',out/'enrollment.json',*sorted((out/'prepare').rglob('*'))] if a.name=='prepare' else ([out/'final-enrollment.json'] if a.name=='final' else sorted((out/a.name).rglob('*'))))
 with tarfile.open(archive,'w:gz') as target:
  for f in paths:
   if f.is_file():
    total+=f.stat().st_size
    if total>1024**3:raise RuntimeError('1GiB evidence cap')
    target.add(f,arcname=str(f.relative_to(ROOT)),recursive=False)
 with archive.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 success=True;print(json.dumps(dict(archive=str(archive),sha256=digest,bytes=archive.stat().st_size,stage=a.name,seconds=time.monotonic()-started)),flush=True)
finally:(out/(a.name+'-supervisor.json')).write_text(json.dumps(dict(returncode=status,seconds=time.monotonic()-started,success=success))+'\n')
