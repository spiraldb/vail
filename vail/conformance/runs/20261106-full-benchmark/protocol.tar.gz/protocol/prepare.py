"""Normal source build, isolated wheel install and correctness before any timings."""
import hashlib,json,os,shutil,subprocess,sys,tarfile,time
from pathlib import Path
from owned import execute
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=ROOT/'results/prepare';OUT.mkdir(parents=True,exist_ok=False)
END=time.monotonic()+5100
seed=json.loads((HERE/'baseline-lock.json').read_text());source=json.loads((HERE/'source-lock.json').read_text());manifest=json.loads((HERE/'source-manifest.json').read_text());record={'success':False,'source':source,'commands':{}}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def command(label,args,seconds):
 if time.monotonic()+seconds+15>END:raise TimeoutError('Remaining prepare budget')
 if shutil.disk_usage(ROOT).free<15*1024**3:raise RuntimeError('15GiB build free floor')
 result,text=execute(args,OUT/label,seconds,deadline=min(END,time.monotonic()+seconds+12));record['commands'][label]=result
 if result['error'] or not result['owned_group_clean'] or result['returncode']!=0:raise RuntimeError(label+':'+json.dumps(result))
 return text
try:
 for name,expected in seed['old']['frontend_sha256'].items():
  if sha(Path(seed['old']['frontend'])/name)!=expected:raise RuntimeError('Old frontend drift:'+name)
 if sha(Path(seed['old']['frontend'])/'_native.abi3.so')!=seed['old']['native_sha256']:raise RuntimeError('Old native drift')
 if sha(seed['hail']['jar'])!=seed['hail']['jar_sha256']:raise RuntimeError('Hail jar drift')
 os.environ.update(PATH='/home/danielking/.cargo/bin:/home/danielking/.local/bin:'+os.environ.get('PATH','/usr/bin:/bin'),RUSTUP_TOOLCHAIN='1.98.0',RUSTFLAGS='-C target-cpu=native',RUSTC_WRAPPER='kache',CARGO_BUILD_JOBS='8',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/home/danielking/vail-presence-20261026/target',CARGO_TERM_COLOR='never')
 for k in list(os.environ):
  if k=='PYTHONPATH' or k=='CARGO_ENCODED_RUSTFLAGS' or k.startswith(('VAIL_EXPERIMENT_','VAIL_DISABLE_','VAIL_TRACE_')):os.environ.pop(k)
 toolchains=command('toolchains',['rustup','toolchain','list'],20)
 if not any(line.startswith('1.98.0-') for line in toolchains.splitlines()):command('toolchain-install',['rustup','toolchain','install','1.98.0','--profile','minimal'],240)
 record['compiler']=command('compiler',['rustc','-Vv'],20);record['kache']=command('kache',['kache','--version'],20)
 record['hardware']=command('hardware',['sh','-c','uname -a; lscpu; df -h /home/danielking'],20)
 if sha(HERE/'source.tar.gz')!=source['archive_sha256']:raise RuntimeError('Source archive SHA')
 dest=ROOT/'source';dest.mkdir(exist_ok=False)
 with tarfile.open(HERE/'source.tar.gz') as archive:
  members=archive.getmembers()
  if len(members)!=len(manifest) or {m.name for m in members}!=set(manifest) or any(not m.isfile() for m in members):raise RuntimeError('Source member SET differs')
  for m in members:
   if m.size>64*1024**2:raise RuntimeError('Source member cap')
   data=archive.extractfile(m).read();target=dest/m.name
   if not target.resolve().is_relative_to(dest.resolve()) or hashlib.sha256(data).hexdigest()!=manifest[m.name]:raise RuntimeError('Source hash/path mismatch')
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 os.chdir(dest/'vail');py=seed['old']['python'];wheels=ROOT/'wheels'
 command('wheel-build',[py,'-m','maturin','build','--release','--locked','--offline','--interpreter',py,'--out',str(wheels)],3600)
 wheel,=wheels.glob('*.whl');venv=ROOT/'current-env'
 command('venv',['uv','venv','--offline','--system-site-packages','--python',py,str(venv)],30)
 command('install',['uv','pip','install','--offline','--no-deps','--python',str(venv/'bin/python'),str(wheel)],60)
 site,=venv.glob('lib/python*/site-packages');(site/'benchmark-dependencies.pth').write_text(str(Path(seed['old']['frontend']).parent)+'\n')
 frontend=site/'vail';native=frontend/'_native.abi3.so'
 current=dict(python=str(venv/'bin/python'),frontend=str(frontend),native=str(native),native_sha256=sha(native),wheel_sha256=sha(wheel),compiled_source=source['commit'],frontend_sha256={str(p.relative_to(frontend)):sha(p) for p in frontend.rglob('*.py')})
 for rel,digest in current['frontend_sha256'].items():
  if digest!=manifest.get('vail/python/vail/'+rel):raise RuntimeError('Installed frontend not frozen source:'+rel)
 lock={**seed,'current':current};(ROOT/'artifact-lock.json').write_text(json.dumps(lock,indent=2)+'\n');record['artifact_lock']=lock
 origin=command('import-origins',[current['python'],'-c',"import json,vail,vail._native as n,numpy,pyarrow,psutil;print(json.dumps(dict(vail=vail.__file__,native=n.__file__,numpy=numpy.__file__,arrow=pyarrow.__file__,psutil=psutil.__file__)))"],30)
 origins=json.loads(origin.strip().splitlines()[-1]);assert Path(origins['vail']).parent==frontend and Path(origins['native'])==native
 record['import_origins']=origins
 command('rust-flatmap',['cargo','test','--release','--locked','--offline','-p','vail-execution','--lib','--test','list_flatmap'],720)
 fixture=dest/'hail/hail/python/test/hail/expr/test_expr.py';fixture.parent.mkdir(parents=True);shutil.copy2(HERE/'hail-test-expr.py',fixture)
 test_files=['python/tests/'+name for name in json.loads((HERE/'python-test-files.json').read_text())]
 command('python-public',[current['python'],'-m','pytest','-q',*test_files,'--deselect','python/tests/test_collection_functions.py::test_corr_long_arrays_use_shared_constant_size_reducer_state'],180)
 # No build/test process may remain when later stages begin.
 competing=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:name=(p/'comm').read_text().strip()
   except FileNotFoundError:continue
   if name in {'cargo','rustc','maturin','perf'}:competing.append((p.name,name))
 if competing:raise RuntimeError('Competing build/profile processes:'+str(competing))
 # Initial complete content enrollment, outside all timings.
 from enroll import artifacts,roster
 enrollment={'artifacts':artifacts(),'inputs':roster(),'python':sys.version};(ROOT/'results/enrollment.json').write_text(json.dumps(enrollment,indent=2)+'\n')
 record['enrollment_summary']={k:v for k,v in enrollment['inputs'].items() if k!='files'}
 record['success']=True
finally:
 (OUT/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
