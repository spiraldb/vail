from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,math,sys
import vail as hl,vail._native as native
r=Path(__file__).parent;rev=Path(sys.argv[1]);mode,fixture,out=sys.argv[2:];pins=json.loads((r/'pins.json').read_text());ready=json.loads((rev/'ready.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();expected=pins['baseline_native_sha256']if mode=='baseline'else ready['identity']['sha256'];assert sha(native.__file__)==expected
source=r/'benchmark_matrix_table.py';assert sha(source)==pins['source_sha256'][source.name];tree=ast.parse(source.read_text());fns=[]
for name in ['many_aggs','test_matrix_table_many_aggs_row_wise']:
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name);fn.decorator_list=[]
 if name!='many_aggs':
  terminal=fn.body[-1];assert isinstance(terminal,ast.Expr)and terminal.value.func.attr=='_force_count';fn.body[-1]=ast.Return(value=terminal.value.func.value)
 fns.append(fn)
module=ast.Module(body=fns,type_ignores=[]);ast.fix_missing_locations(module);api=SimpleNamespace(**vars(hl))
if fixture=='profile':api.read_matrix_table=hl.MatrixTable.read_legacy
ns={'hl':api};exec(compile(module,str(source),'exec'),ns);table=ns['test_matrix_table_many_aggs_row_wise'](pins['fixtures'][fixture]['root']).select(*[f'x{i}'for i in range(33)])
rows=table.collect();digest=hashlib.sha256()
def value(v):
 if isinstance(v,float):return ['float','NaN'if math.isnan(v)else v.hex()]
 return v
for row in rows:
 record=[row.locus.contig,row.locus.position,list(row.alleles),*[value(row[f'x{i}'])for i in range(33)]]
 digest.update(json.dumps(record,separators=(',',':'),ensure_ascii=False).encode());digest.update(b'\n')
assert len(rows)==24885
Path(out).write_text(json.dumps({'mode':mode,'fixture':fixture,'native_sha256':expected,'rows':len(rows),'aggregate_fields':33,'ordered_output_sha256':digest.hexdigest(),'scope':'Untimed baseline-consistency probe of all33 aggregate outputs and keys, finite floats hex and NaN-class normalized; collect terminal differs from timed force-count; independent public arithmetic oracles are separate'},indent=2)+'\n')
