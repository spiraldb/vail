from pathlib import Path
import json,os,sys
from owned import run
r=Path(__file__).parent;rev=Path(sys.argv[1]);pins=json.loads((r/'pins.json').read_text());ready=json.loads((rev/'ready.json').read_text());env={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};env.update(RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',VAIL_TRACE_SEMANTIC_PREP='1');results=[]
for fixture in ['profile','native_profile']:
 pair=[]
 for mode,python in [('baseline',pins['baseline_python']),('candidate',ready['python'])]:
  out=rev/'actual-correctness'/f'{fixture}-{mode}';result=out/'result.json';receipt=run(['nice','-n','10',python,str(r/'check-actual-worker.py'),str(rev),mode,fixture,str(result)],out,env,120);v=json.loads(result.read_text());pair.append(v);results.append({'result':v,'receipt':receipt})
 assert pair[0]['ordered_output_sha256']==pair[1]['ordered_output_sha256'],pair
 assert 'MULTI_REDUCE_PREP'in (rev/'actual-correctness'/f'{fixture}-candidate'/'stderr').read_text()
(rev/'actual-correctness.json').write_text(json.dumps({'results':results,'both_formats_all33_outputs_match_baseline':True},indent=2)+'\n');print('FULL OUTPUT MATCH: 24885 rows ×33 aggregates, both formats',flush=True)
