from pathlib import Path
import json,subprocess,os,sys,time
r=Path(sys.argv[1]);e=os.environ.copy()
for k,v in json.loads(Path('/private/tmp/vail-allocators-20261109/pinned-sdk/build-environment.json').read_text()).items():
 if v is None:e.pop(k,None)
 else:e[k]=v
cmd=['nice','-n','10','cargo','test','--release','--locked','--offline','-p','vail-execution','--test','list_flatmap','--test','float_fold','--test','local_lambda_cse','--test','collection_aggregates','--test','array_methods','--test','list_indexing','--','--test-threads=1'];start=time.monotonic()
with (r/'rust-gates.log').open('w')as f:p=subprocess.run(cmd,cwd='/private/tmp/vail-multi-sink-20261111/vail',env=e,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
(r/'rust-gates.json').write_text(json.dumps({'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');print('RUST',p.returncode,flush=True);sys.exit(p.returncode)
