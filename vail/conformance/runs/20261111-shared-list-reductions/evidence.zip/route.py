from pathlib import Path
import json,os,sys
from owned import run
r=Path(__file__).parent;revision=Path(sys.argv[1]);ready=json.loads((revision/'ready.json').read_text());e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',VAIL_TRACE_SEMANTIC_PREP='1',VAIL_TRACE_FORCE_COUNT_PLAN='1')
receipt=run(['nice','-n','10',ready['python'],str(r/'route-worker.py'),str(revision)],revision/'route',e,120);text=(revision/'route/stderr').read_text();lines=[x for x in text.splitlines()if 'MULTI_REDUCE_PREP'in x];(revision/'route-proof.json').write_text(json.dumps({'receipt':receipt,'admitted':bool(lines),'preparation_lines':lines},indent=2)+'\n');print('ROUTE',lines,flush=True);assert lines,'Original full benchmark did not use the new shared region'
