from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,sys
import vail as hl,vail._native as native
r=Path(__file__).parent;revision=Path(sys.argv[1]);ready=json.loads((revision/'ready.json').read_text());p=json.loads((r/'pins.json').read_text());assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()==ready['identity']['sha256'];source=r/'benchmark_matrix_table.py';assert hashlib.sha256(source.read_bytes()).hexdigest()==p['source_sha256'][source.name];tree=ast.parse(source.read_text());fns=[]
for name in ['many_aggs','test_matrix_table_many_aggs_row_wise']:
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name);fn.decorator_list=[];fns.append(fn)
module=ast.Module(body=fns,type_ignores=[]);ast.fix_missing_locations(module);api=SimpleNamespace(**vars(hl));api.read_matrix_table=hl.MatrixTable.read_legacy;ns={'hl':api};exec(compile(module,str(source),'exec'),ns);assert ns['test_matrix_table_many_aggs_row_wise'](p['fixtures']['profile']['root'])is None
(revision/'route-result.json').write_text(json.dumps({'native_sha256':ready['identity']['sha256'],'source':ready['source'],'original_full_many_row_completed':True},indent=2)+'\n')
