from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,sys,time,psutil
r=Path(__file__).parent;cfg=json.loads((r/'config.json').read_text());pins=cfg['pins'];mode,case,outpath=sys.argv[1:];out=Path(outpath);spec=cfg['cases'][case]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
meta={'mode':mode,'case':case,'spec':spec,'python':sys.version}
if mode=='hail':
 import hail as hl
 assert hl.__version__==pins['hail_version']and sha(pins['hail_jar'])==pins['hail_jar_sha256'];hl.init(master='local[4]',quiet=True,log=str(out/'hail.log'),tmp_dir=str(out/'hail-tmp'),spark_conf={'spark.driver.memory':'2g','spark.executor.memory':'2g','spark.default.parallelism':'4','spark.sql.shuffle.partitions':'4','spark.ui.enabled':'false','spark.driver.bindAddress':'127.0.0.1','spark.driver.host':'127.0.0.1'});meta.update(hail_version=hl.__version__,jar_sha256=sha(pins['hail_jar']))
else:
 import vail as hl,vail._native as native
 assert sha(native.__file__)==cfg[mode]['native_sha256'];meta.update(native_sha256=sha(native.__file__),allocator=native._benchmark_allocator)
if 'synthetic'in spec:
 m=hl.range_matrix_table(*spec['dimensions'],n_partitions=spec['partitions']);m=m.annotate_entries(value=hl.or_missing(m.col_idx%7!=0,hl.int32(m.col_idx-251)),other=hl.int64(m.col_idx*3-7));m=m.filter_entries((m.row_idx%11!=0)&(m.col_idx%5!=0))
 def query():
  q=hl.float64(m.value)/7;z=m.other%3;limit=m.row_idx%13 if spec['synthetic']=='captured'else 2
  m.annotate_rows(a=hl.agg.fraction(q<limit),b=hl.agg.fraction(q>=limit),c=hl.agg.count_where(q<=limit),d=hl.agg.count_where(q>limit),e=hl.agg.count_where(z==0),f=hl.agg.count_where(z!=0),g=hl.agg.fraction(m.other%11==0),h=hl.agg.fraction(m.other%11!=0)).rows()._force_count()
 meta['fixture']='generated range-matrix; source evaluation remains inside timed action, initial expression construction outside'
else:
 source=r/spec['source'];assert sha(source)==pins['source_sha256'][spec['source']];tree=ast.parse(source.read_text());fns=[]
 for name in spec.get('helpers',[])+[spec['function']]:
  fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name);fn.decorator_list=[];fns.append(fn)
 module=ast.Module(body=fns,type_ignores=[]);ast.fix_missing_locations(module);api=SimpleNamespace(**vars(hl))
 if mode!='hail'and spec['reader']=='legacy':api.read_matrix_table=hl.MatrixTable.read_legacy
 ns={'hl':api};exec(compile(module,str(source),'exec'),ns);fixture=pins['fixtures'][spec['fixture']]['root']
 def query():ns[spec['function']](fixture)
 meta.update(fixture=fixture,source_sha256=sha(source),original_function=ast.unparse(fns[-1]))
def snap():
 d={}
 for q in psutil.Process().children(recursive=True):
  try:c=q.cpu_times();d[f'{q.pid}:{q.create_time()}']=c.user+c.system
  except psutil.NoSuchProcess:pass
 return d
try:
 assert query()is None;samples=[]
 for i in range(3):
  before=snap();cpu=time.process_time();start=time.perf_counter();assert query()is None;wall=time.perf_counter()-start;cpu=time.process_time()-cpu;after=snap();assert set(before)==set(after);child=sum(after[k]-before[k]for k in after);assert child>=0;samples.append({'wall_seconds':wall,'cpu_seconds':cpu+child,'python_cpu_seconds':cpu,'observed_child_cpu_seconds':child,'before':before,'after':after,'threads_after':psutil.Process().num_threads()});print('SAMPLE',i,wall,cpu+child,flush=True)
 meta.update(samples=samples,passed=True)
finally:
 if mode=='hail':hl.stop()
(out/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
