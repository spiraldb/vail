from pathlib import Path
import json,os,sys
from owned import run
r=Path(__file__).parent;revision=Path(sys.argv[1]);ready=json.loads((revision/'ready.json').read_text());e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc',RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
args=['nice','-n','10','/opt/homebrew/bin/samply','record','--save-only','--duration','12','--rate','1000','--unstable-presymbolicate','--profile-name','Vail shared row-wise aggregate producers','--output',str(revision/'rowwise-profile.json.gz'),ready['python'],str(r/'profile-worker.py'),str(revision)]
receipt=run(args,revision/'profile',e,120);(revision/'profile-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PROFILE COMPLETE',flush=True)
