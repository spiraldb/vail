from pathlib import Path
import json,hashlib,os,statistics,time,sys,shutil
from owned import run
r=Path(__file__).parent;revision=Path(sys.argv[1]);ready=json.loads((revision/'ready.json').read_text());pins=json.loads((r/'pins.json').read_text());cases=json.loads((r/'cases.json').read_text());cfg={'pins':pins,'cases':cases,'baseline':{'python':pins['baseline_python'],'native_sha256':pins['baseline_native_sha256']},'candidate':{'python':ready['python'],'native_sha256':ready['identity']['sha256'],'source':ready['source']},'hail':{'python':pins['hail_python']}}
assert json.loads((revision/'python-gates.json').read_text())['returncode']==0
(r/'config.json').write_text(json.dumps(cfg,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inputs():
 n=0
 for d in pins['fixtures'].values():
  root=Path(d['root']);assert {str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}==set(d['files'])
  for name,w in d['files'].items():
   p=root/name;assert p.stat().st_size==w['bytes']and sha(p)==w['sha256'],p;n+=1
 return n
e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(JAVA_HOME='/Library/Java/JavaVirtualMachines/temurin-11.jre/Contents/Home',SPARK_LOCAL_IP='127.0.0.1',PYSPARK_PYTHON=pins['hail_python'],PYSPARK_DRIVER_PYTHON=pins['hail_python'],PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc',RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
inputs();receipts=[];results=[];summary={};start=time.monotonic()
for case,spec in cases.items():
 schedule=['hail','baseline','candidate','candidate','baseline','hail']if case=='many_row_hail'else ['baseline','candidate','candidate','baseline']
 for i,mode in enumerate(schedule):
  assert time.monotonic()-start+380<3600 and shutil.disk_usage(r).free>5*1024**3
  out=revision/'timings'/f'{case}-{i}-{mode}';print('RUN',case,i,mode,flush=True);rec=run(['nice','-n','10',cfg[mode]['python'],str(r/'worker.py'),mode,case,str(out)],out,e,360);receipts.append(rec);result=json.loads((out/'result.json').read_text());assert result['passed'];results.append(result);(revision/'progress.json').write_text(json.dumps({'completed':len(results),'receipts':receipts},indent=2)+'\n')
 row={}
 for mode in ['baseline','candidate']+(['hail']if case=='many_row_hail'else []):
  selected=[x for x in results if x['case']==case and x['mode']==mode];med=[{k:statistics.median(s[k]for s in x['samples'])for k in ['wall_seconds','cpu_seconds']}for x in selected];row[mode]={k:statistics.median(x[k]for x in med)for k in ['wall_seconds','cpu_seconds']};row[mode]['process_medians']=med
 row['wall_change_percent']=100*(row['candidate']['wall_seconds']/row['baseline']['wall_seconds']-1);row['cpu_change_percent']=100*(row['candidate']['cpu_seconds']/row['baseline']['cpu_seconds']-1);summary[case]=row;print('SUMMARY',case,json.dumps(row),flush=True);(revision/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
n=inputs();(revision/'results.json').write_text(json.dumps({'summary':summary,'results':results,'receipts':receipts,'post_input_files_hashed':n,'seconds':time.monotonic()-start,'scope':'38freshworkers/114calls, primaryH/B/C/C/B/H, othersB/C/C/B,1warmup3samples; fixednormalbaselineandcandidate, alladversesretained; observedstableJVMendpointCPUlowerbound; nativeHailfixturesnotglobalcoreparity; no cache/statisticalclaim'},indent=2)+'\n');print('BENCH COMPLETE',flush=True)
