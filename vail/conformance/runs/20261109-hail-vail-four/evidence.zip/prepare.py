from pathlib import Path
import json,hashlib,platform,subprocess
import pyarrow as pa,pyarrow.compute as pc
r=Path(__file__).parent;old=Path('/private/tmp/vail-hail-comparison-72');v=Path('/private/tmp/vail-general-list-20261108/map-index-revision')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enrollment(root,expected):
 root=Path(root);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()};assert actual==set(expected)
 out={}
 for name,e in expected.items():
  p=root/name;rec={'bytes':p.stat().st_size,'sha256':sha(p)};assert rec['bytes']==e.get('bytes',e.get('size')) and rec['sha256']==e['sha256'],name;out[name]=rec
 return {'root':str(root),'files':out}
oldpins=json.loads((old/'enrollment.json').read_text());vp=json.loads((v/'pins.json').read_text());package=json.loads((v/'masking-package.json').read_text())
pins={'vail_production':'30783876b24484cc80549d175faf15bab765f676','main':'17ae75d9839198a7a5b25190bb6f84a8895727b8','python':platform.python_version(),'vail_python':str(v/'env/bin/python'),'hail_python':'/private/tmp/vail-hail-comparison-59/env/bin/python','native':package['native'],'native_sha256':vp['native']['after'],'vail_frontend':vp['frontend']['after'],'hail_jar':oldpins['hail_jar'],'hail_jar_sha256':oldpins['hail_jar_sha256'],'hail_version':oldpins['hail_version'],'sources':vp['sources'],'references':{}}
assert sha(pins['native'])==pins['native_sha256'];assert sha(pins['hail_jar'])==pins['hail_jar_sha256']
hm=json.loads((old/'fixture-manifest.json').read_text());pins['hail_fixture']=enrollment(hm['root'],hm['files']);native=r/'inputs/native.mt';native_expected={str(p.relative_to(native)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in native.rglob('*') if p.is_file()};pins['vail_fixture']=enrollment(native,native_expected)
pins['historical_shared_vcf_sha256']=oldpins['vcf_sha256'];pins['fixture_note']='Old native data/VCF absent; new native is a public Vail legacy-read/native-write conversion of exact hash-verified Hail input; new layout, no oldnative ratio transfer';pins['generation']=json.loads((r/'native-generation.json').read_text())
def s(a):return pc.sum(pc.cast(a,pa.int64())).as_py() or 0
for name,refsha in vp['references'].items():
 ref=v/'references'/name;assert sha(ref)==refsha
 with pa.memory_map(str(ref),'r') as f:t=pa.ipc.open_file(f).read_all()
 entries=pc.list_flatten(t['entries'].combine_chunks());entries=pc.filter(entries,pc.is_valid(entries));n=len(entries)
 summary={'rows':t.num_rows,'columns':2535,'entry_defined':n,'entry_missing':t.num_rows*2535-n,'fields':{}}
 for field in entries.type:
  namefield=field.name;a=entries.field(namefield)
  if namefield=='GT':
   g=pc.filter(a,pc.is_valid(a));p=g.field('__vail_call_ploidy');stats={'defined':len(g),'missing':n-len(g),'ploidy_sum':s(p),'ploidy0':s(pc.equal(p,0)),'ploidy1':s(pc.equal(p,1)),'ploidy2':s(pc.equal(p,2)),'phased':s(g.field('__vail_call_phased')),'allele0_sum':s(pc.filter(g.field('__vail_call_allele0'),pc.greater(p,0))),'allele1_sum':s(pc.filter(g.field('__vail_call_allele1'),pc.greater(p,1)))}
  elif pa.types.is_list(a.type):
   vals=pc.list_flatten(a);stats={'defined':len(a)-a.null_count,'missing':a.null_count,'total_len':s(pc.list_value_length(a)),'defined_values':len(vals)-vals.null_count,'missing_values':vals.null_count,'sum':s(vals),'min':pc.min(vals).as_py(),'max':pc.max(vals).as_py()}
  else:stats={'defined':len(a)-a.null_count,'missing':a.null_count,'sum':pc.sum(a).as_py() or 0,'min':pc.min(a).as_py(),'max':pc.max(a).as_py()}
  summary['fields'][namefield]=stats
 case=name.removesuffix('.arrow');(r/(case+'-reference-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');pins['references'][case]={'path':str(ref),'sha256':refsha,'summary_sha256':sha(r/(case+'-reference-summary.json'))}
for source,expected in pins['sources'].items():assert sha(source)==expected
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('ENROLLED',len(pins['hail_fixture']['files']),len(pins['vail_fixture']['files']),len(pins['references']))
