from pathlib import Path
import json,hashlib,statistics as st
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=json.loads((r/'pins.json').read_text());protocol=json.loads((r/'protocol.json').read_text());assert protocol['pins_sha256']==sha(r/'pins.json')
for name,h in protocol['scripts'].items():assert sha(r/name)==h
complete=json.loads((r/'complete.json').read_text());assert complete['workers']==32 and complete['timed_samples']==160 and complete['protocol_sha256']==sha(r/'protocol.json') and complete['post_full_file_hashes']==83
validation=json.loads((r/'validation-complete.json').read_text());assert validation['all8passed'] and validation['protocol_sha256']==sha(r/'protocol.json') and len(validation['workers'])==8
for row in validation['workers']:
 for name,h in row['hashes'].items():assert sha(Path(row['out'])/name)==h
rows=[]
for case in protocol['cases']:
 row={'case':case}
 for mode in ['hail','vail']:
  workers=[]
  for i,m in enumerate(protocol['schedule']):
   if m!=mode:continue
   out=r/'time'/f'{case}-{i}-{mode}';d=json.loads((out/'result.json').read_text());e=json.loads((out/'exit.json').read_text());assert d['passed'] and d['identity_verified'] and d['mode']==mode and d['case']==case and len(d['samples'])==5 and e['returncode']==0 and e['group_absent'] and e['live_owned']==0 and e['failure'] is None and e['cleanup_error'] is None
   assert all(s['stable_descendant_identities'] for s in d['samples'])
   w={k:st.median(s[k] for s in d['samples']) for k in ['wall_seconds','cpu_seconds','python_minor_faults','python_major_faults']}
   w['process_index']=i;w['combined_process_peak_rss_bytes']=e['peak_observed_combined_rss_bytes'];w['hashes']={name:sha(out/name) for name in ['result.json','exit.json','identity.json']};workers.append(w)
  assert len(workers)==4
  row[mode]={'median':{k:st.median(w[k] for w in workers) for k in ['wall_seconds','cpu_seconds','python_minor_faults','python_major_faults']},'process_medians':workers,'range':{k:[min(w[k] for w in workers),max(w[k] for w in workers)] for k in ['wall_seconds','cpu_seconds']}}
 row['hail_divided_by_vail']={k:row['hail']['median'][k]/row['vail']['median'][k] for k in ['wall_seconds','cpu_seconds']}
 rows.append(row)
post=json.loads((r/'post-input-hashes.json').read_text())
for mode in ['hail','vail']:assert post[mode]==pins[mode+'_fixture']['files']
result={'protocol_sha256':sha(r/'protocol.json'),'source_production':pins['vail_production'],'main':pins['main'],'input':{'rows':1000,'samples':2535,'partitions':4,'fresh_native_conversion':True,'not_full_profile25':True},'cases':rows,'all160_samples_passed':True,'all40_final_validation_timing_groups_absent':True,'post_full_hashes':83,'limitations':['Hail summary+dosage fullmultiset equivalence is not full per-cell association proof','originalforcecountbodies do not independently prove every payload field forced','CPU includes Python+observedstablechild endpoints; unobservedexiteddescendantsmaybemissed','4partitions/HailSpark4/VailTokio32Rayon4 not global4threadparity','native regenerated fromfrozenHail; no oldlayouttimingratio','RSS wholeprocessincludingimport/JIT/warmup nottimedliveoperatorRSS','no allocation time/pagefault CPU attribution; major/minor counters not cost profile']}
(r/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({x['case']:{'hail':x['hail']['median'],'vail':x['vail']['median'],'ratio':x['hail_divided_by_vail']} for x in rows},indent=2))
