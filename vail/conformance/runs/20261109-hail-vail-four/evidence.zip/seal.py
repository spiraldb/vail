from pathlib import Path
import os,json,hashlib,zipfile
r=Path(__file__).parent;payload={}
for directory,dirs,files in os.walk(r,followlinks=False):
 dirs[:]=[d for d in dirs if d not in {'inputs','hail-tmp','__pycache__','env','wheels','executables'} and not (Path(directory)/d).is_symlink()]
 for name in files:
  p=Path(directory)/name
  if p.is_symlink() or p.suffix in {'.npy','.zip','.whl','.so','.pyc'} or name in {'REPORT.md','evidence.json'}:continue
  assert p.stat().st_size<32*1024**2,p
  payload[str(p.relative_to(r))]=p.read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(payload.items())};archive=r/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(payload.items()):z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'manifest.json'}
 for name,expected in manifest.items():
  data=z.read(name);assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
seal={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'payloads':len(manifest),'all_member_hashes_verified':True,'excluded':['native/Hail fixtures','reference Arrow/Numpy payloads','installed packages/JAR/native binaries','Hail temporary spill/classfiles'],'vail_source':'30783876b24484cc80549d175faf15bab765f676','main':'17ae75d9839198a7a5b25190bb6f84a8895727b8','scope':'fresh matched4cases32workers160samples+separatePLdiagnostic8workers40samples;1krowlaptopsubset','no_production_change':True}
(r/'evidence.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
