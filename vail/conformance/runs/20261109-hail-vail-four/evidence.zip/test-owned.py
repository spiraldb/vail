from pathlib import Path
import os,sys,json,subprocess,time,signal
from owned import run
r=Path(__file__).parent/'guard-tests-v3';r.mkdir(exist_ok=False);env=dict(os.environ)
a=run([sys.executable,'-c','import time,signal;assert not set(signal.pthread_sigmask(signal.SIG_BLOCK,[]))&{signal.SIGTERM,signal.SIGHUP,signal.SIGINT};print("child termination signals unblocked");time.sleep(.05)'],r/'normal',env,2);assert a['group_absent']
try:run([sys.executable,'-c','import time;time.sleep(4)'],r/'deadline',env,.15)
except RuntimeError:pass
else:raise AssertionError('deadline did not fail')
a=json.loads((r/'deadline/exit.json').read_text());assert a['failure']=='worker deadline' and a['group_absent']
controller="from owned import run;import os,sys;run([sys.executable,'-c','import signal,time,sys;signal.signal(signal.SIGTERM,lambda s,f:(time.sleep(.3),sys.exit(0)));time.sleep(30)'],sys.argv[1],dict(os.environ),40)"
p=subprocess.Popen([sys.executable,'-c',controller,str(r/'signal')],cwd=str(Path(__file__).parent),stdout=subprocess.DEVNULL,stderr=(r/'signal-stderr').open('w'));time.sleep(.6);assert p.poll() is None;p.send_signal(signal.SIGTERM);time.sleep(.05)
if p.poll() is None:p.send_signal(signal.SIGHUP)
p.wait(timeout=5);a=json.loads((r/'signal/exit.json').read_text());assert a['group_absent'] and a['cleanup_error'] is None
(r/'complete.json').write_text(json.dumps({'normal':True,'child_termination_signals_unblocked':True,'deadline':True,'SIGTERM_and_repeated_SIGHUP_cleanup':True,'all_groups_absent':True},indent=2)+'\n');print('3 owned process checks passed')
