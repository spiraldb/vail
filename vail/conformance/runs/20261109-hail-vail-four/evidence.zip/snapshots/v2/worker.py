from pathlib import Path
import os,sys,json,time,resource,hashlib,ast,copy,math
import psutil
r=Path(__file__).parent;mode,purpose,case,outpath=sys.argv[1:];out=Path(outpath);pins=json.loads((r/'pins.json').read_text());assert mode in ['hail','vail'] and purpose in ['validate','time']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
fixture=pins[mode+'_fixture']['root'];meta={'mode':mode,'purpose':purpose,'case':case,'fixture':fixture,'flags':{k:v for k,v in os.environ.items() if k.startswith('VAIL_')},'python':sys.version,'cpu_scope':'PythonprocessCPU plus observed stable live child endpointCPU; short-lived/unobserved descendants may be missed; child endpoints not atomic with wall','threads':'HailSpark local4 and VailRayon4/Tokio32;4inputpartitions,notglobal4threadparity'}
assert not meta['flags']
for rel,e in pins[mode+'_fixture']['files'].items():assert (Path(fixture)/rel).stat().st_size==e['bytes']
assert {str(p.relative_to(fixture)) for p in Path(fixture).rglob('*') if p.is_file()}==set(pins[mode+'_fixture']['files'])
if mode=='vail':
 import vail as hl,vail._native as native
 assert sha(native.__file__)==pins['native_sha256'];package=Path(hl.__file__).parent
 assert {str(p.relative_to(package)):sha(p) for p in package.rglob('*.py')}==pins['vail_frontend']
 meta.update(native=str(native.__file__),native_sha256=sha(native.__file__))
else:
 import hail as hl,pyspark
 assert hl.__version__==pins['hail_version'] and sha(Path(hl.__file__).parent/'backend/hail-all-spark.jar')==pins['hail_jar_sha256']
 meta.update(hail_version=hl.__version__,jar_sha256=pins['hail_jar_sha256'],pyspark=pyspark.__version__)
 hl.init(master='local[4]',quiet=True,log=str(out/'hail.log'),tmp_dir=str(r/'hail-tmp'),spark_conf={'spark.driver.memory':'2g','spark.executor.memory':'2g','spark.default.parallelism':'4','spark.sql.shuffle.partitions':'4','spark.ui.enabled':'false','spark.driver.bindAddress':'127.0.0.1','spark.driver.host':'127.0.0.1'})
 meta['spark_conf']=dict(pyspark.SparkContext._active_spark_context.getConf().getAll())
source=Path('/private/tmp/vail-full-benchmark-20261106/protocol/upstream')/('benchmark_methods.py' if case=='test_split_multi_hts' else 'benchmark_matrix_table.py');assert sha(source)==pins['sources'][str(source)]
fn=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==case);fn.decorator_list=[]
v=copy.deepcopy(fn);v.name='validation_query';last=v.body[-1];assert isinstance(last,ast.Expr) and isinstance(last.value,ast.Call) and last.value.func.attr=='_force_count_rows';v.body[-1]=ast.Return(value=last.value.func.value)
m=ast.Module(body=[fn,v],type_ignores=[]);ast.fix_missing_locations(m);ns={'hl':hl};exec(compile(m,str(source),'exec'),ns);meta.update(source_sha256=sha(source),original_function=ast.unparse(fn),identity_verified=True)
(out/'identity.json').write_text(json.dumps(meta,indent=2)+'\n')
def plain(x):
 if isinstance(x,hl.Struct):return {k:plain(v) for k,v in x.items()}
 return x
def compare(a,b,path='',root_a=None,root_b=None):
 root_a=a if root_a is None else root_a;root_b=b if root_b is None else root_b
 if isinstance(b,dict):
  assert set(a)==set(b),(path,a,b)
  for k in b:compare(a[k],b[k],path+'/'+k,root_a,root_b)
 elif isinstance(b,float):
  if path=='/fields/dosage/sum':
   bound=meta['dosage_sum_comparison']['acceptance_bound']
   assert all(math.isfinite(x) and x>=0 for x in [a,b,root_a['fields']['dosage']['min'],root_b['fields']['dosage']['min']]) and abs(a-b)<=bound,(path,a,b,bound)
  else:assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-8),(path,a,b)
 else:assert a==b,(path,a,b)
def validate():
 q=ns['validation_query'](fixture);ref=pins['references'][case];assert sha(ref['path'])==ref['sha256'];expected=json.loads((r/(case+'-reference-summary.json')).read_text());assert sha(r/(case+'-reference-summary.json'))==ref['summary_sha256']
 if mode=='vail':
  import pyarrow as pa
  actual=q.localize_entries('entries','columns').to_arrow()
  with pa.memory_map(ref['path'],'r') as f:oracle=pa.ipc.open_file(f).read_all()
  assert actual.equals(oracle,check_metadata=True),'Full Arrow mismatch after native regeneration'
  return {'full_arrow_values_and_metadata_equal':True,'rows':actual.num_rows,'reference_sha256':ref['sha256']}
 def simple(x):return hl.struct(defined=hl.agg.count_where(hl.is_defined(x)),sum=hl.agg.sum(x),min=hl.agg.min(x),max=hl.agg.max(x))
 def arr(x):return hl.struct(defined=hl.agg.count_where(hl.is_defined(x)),total_len=hl.agg.sum(hl.int64(hl.len(x))),defined_values=hl.agg.explode(lambda v:hl.agg.count_where(hl.is_defined(v)),x),missing_values=hl.agg.explode(lambda v:hl.agg.count_where(hl.is_missing(v)),x),sum=hl.agg.explode(lambda v:hl.agg.sum(hl.int64(v)),x),min=hl.agg.explode(lambda v:hl.agg.min(v),x),max=hl.agg.explode(lambda v:hl.agg.max(v),x))
 fields={}
 for name in expected['fields']:
  x=q[name]
  if name=='GT':fields[name]=hl.struct(defined=hl.agg.count_where(hl.is_defined(x)),ploidy_sum=hl.agg.sum(hl.int64(x.ploidy)),ploidy0=hl.agg.count_where(x.ploidy==0),ploidy1=hl.agg.count_where(x.ploidy==1),ploidy2=hl.agg.count_where(x.ploidy==2),phased=hl.agg.count_where(x.phased),allele0_sum=hl.agg.sum(hl.int64(hl.or_missing(x.ploidy>0,x[0]))),allele1_sum=hl.agg.sum(hl.int64(hl.or_missing(x.ploidy>1,x[1]))))
  elif name in ['AD','PL']:fields[name]=arr(x)
  else:fields[name]=simple(x)
 actual=plain(q.aggregate_entries(hl.struct(entry_defined=hl.agg.count(),fields=hl.struct(**fields))));actual.update(rows=q.count_rows(),columns=q.count_cols());n=actual['entry_defined'];actual['entry_missing']=actual['rows']*actual['columns']-n
 for field in actual['fields'].values():field['missing']=n-field['defined']
 if 'dosage' in expected['fields']:
  import numpy as np
  ref=pins['dosage_sorted_reference'];assert sha(ref['path'])==ref['sha256'];values=np.asarray(q.aggregate_entries(hl.agg.filter(hl.is_defined(q.dosage),hl.agg.collect(q.dosage))),dtype=np.float64);values.sort();reference=np.load(ref['path']);assert values.shape==reference.shape and np.isfinite(values).all();assert np.allclose(values,reference,rtol=1e-12,atol=1e-12),'Fullsorted dosage values differ'
  delta=math.fsum(np.abs(values-reference));meta['dosage_multiset_comparison']={'values':len(values),'maximum_absolute_difference':float(np.max(np.abs(values-reference))),'total_absolute_difference':delta,'tolerance':'rel1e-12abs1e-12pervalue','limitation':'fullscalarvaluemultiset,notrow/columnassociation'}
  n=expected['fields']['dosage']['defined'];assert n==len(values);u=2**-53;gamma=n*u/(1-n*u);a=actual['fields']['dosage'];b=expected['fields']['dosage'];bound=math.nextafter(delta,math.inf)+gamma/(1-gamma)*(abs(a['sum'])+abs(b['sum']))
  meta['dosage_sum_comparison']={'actual':a['sum'],'reference':b['sum'],'difference':a['sum']-b['sum'],'acceptance_bound':bound,'n':n,'u':u,'gamma_n':gamma,'formula':'measuredfullmultisetabsoluteDifference + gamma_n/(1-gamma_n)*(abs(sumA)+abs(sumB))','scope':'numericalsummaryacceptanceusingnonnegativefinite-sumreductionmodel,notendtoenderrorproof orpowbound; fullvaluecomparisonseparate'}
 compare(actual,expected)
 return {'entry_field_summaries_equal':True,'summary':actual,'comparison_limit':'counts/sums/min/max/nulls/lengths/Callalleles;notfullrowwiseequality;floatextrema rel1e-12 abs1e-8;positivefinite dosage sum uses recorded gamma_n reduction allowance+measured fullvalue multiset difference'}
def snapshot():
 records={}
 for x in psutil.Process().children(recursive=True):
  try:
   c=x.cpu_times();mem=x.memory_info()._asdict();records[f'{x.pid}:{x.create_time()}']={'cpu':c.user+c.system,'faults':{k:v for k,v in mem.items() if k in ['pfaults','pageins']}}
  except psutil.NoSuchProcess:pass
 return records
try:
 if purpose=='validate':meta['validation']=validate()
 else:
  for i in range(3):assert ns[case](fixture) is None
  known=set(snapshot());samples=[]
  for i in range(5):
   b=snapshot();ru=resource.getrusage(resource.RUSAGE_SELF);cpu=time.process_time();start=time.perf_counter();result=ns[case](fixture);wall=time.perf_counter()-start;cpu=time.process_time()-cpu;afterru=resource.getrusage(resource.RUSAGE_SELF);a=snapshot();assert result is None
   stable=known==set(b)==set(a);assert stable,'Descendantendpointsetchanged;CPUincomplete'
   child=sum(a[k]['cpu']-b[k]['cpu'] for k in a);assert child>=0
   samples.append({'wall_seconds':wall,'cpu_seconds':cpu+child,'python_cpu_seconds':cpu,'observed_child_cpu_seconds':child,'stable_descendant_identities':stable,'descendants_before':b,'descendants_after':a,'python_minor_faults':afterru.ru_minflt-ru.ru_minflt,'python_major_faults':afterru.ru_majflt-ru.ru_majflt})
  meta['samples']=samples
finally:
 if mode=='hail':hl.stop()
meta['passed']=True;(out/'result.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({'mode':mode,'case':case,'purpose':purpose,'passed':True}),flush=True)
