from pathlib import Path
import os,json
from owned import run
r=Path(__file__).parent;env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_') and k!='PYTHONPATH'};env.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
print(json.dumps(run(['/private/tmp/vail-general-list-20261108/map-index-revision/env/bin/python',str(r/'create-native.py')],r/'native-generation-run-2',env,180)),flush=True)
