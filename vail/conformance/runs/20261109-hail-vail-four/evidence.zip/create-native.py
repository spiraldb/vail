from pathlib import Path
import json,hashlib,time
r=Path(__file__).parent
import vail as hl,vail._native as native
expected='16a064a0650ba8482b95aa4e493237d6f26bc0dd6d85fae534237bd8fccab73a';assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()==expected
source='/private/tmp/vail-hail-comparison-59/first-1000.hail.mt';out=r/'inputs/native.mt';assert not out.exists()
mt=hl.MatrixTable.read_legacy(source);print('read partitions',mt.n_partitions(),flush=True);assert mt.count()==(1000,2535)
mt=mt.repartition(4,shuffle=False);out.parent.mkdir(exist_ok=True);mt.write(str(out));fresh=hl.read_matrix_table(str(out));assert fresh.count()==(1000,2535)
receipt={'source':source,'output':str(out),'dimensions':[1000,2535],'partitions':fresh.n_partitions(),'native_sha256':expected,'method':'public Vail legacy read→repartition4 without shuffle→native write; fresh source data/layout, not oldnative timing baseline'}
assert receipt['partitions']==4
(r/'native-generation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt,flush=True)
