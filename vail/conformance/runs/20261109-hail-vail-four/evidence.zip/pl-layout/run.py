from pathlib import Path
import json,os,sys,hashlib,statistics as s
sys.path.insert(0,str(Path(__file__).parent.parent))
from owned import run
r=Path(__file__).parent;pins=json.loads((r.parent/'pins.json').read_text());records=[]
lock=json.loads((r/'protocol.json').read_text());assert hashlib.sha256((r/'worker.py').read_bytes()).hexdigest()==lock['worker_sha256'];assert hashlib.sha256((r.parent/'owned.py').read_bytes()).hexdigest()==lock['owned_sha256']
for i,mode in enumerate(['mapped','indexed','indexed','mapped','mapped','indexed','indexed','mapped']):
 env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_') and k!='PYTHONPATH'};env.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',TOKIO_WORKER_THREADS='4');out=r/'runs'/f'{i}-{mode}';receipt=run([pins['vail_python'],str(r/'worker.py'),mode,str(out)],out,env,120);d=json.loads((out/'result.json').read_text());assert d['fullArrowvalues_metadata_equal'] and d['frontend_verified'];d['process']=i;d['cleanup']=receipt;records.append(d);(r/'records.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS',i,mode,flush=True)
summary={}
for mode in ['mapped','indexed']:
 a=[x for x in records if x['mode']==mode];assert len(a)==4;summary[mode]={k:s.median(s.median(t[k] for t in x['samples']) for x in a) for k in ['wall_seconds','cpu_seconds']}
summary['indexed_change_percent']={k:100*(summary['indexed'][k]/summary['mapped'][k]-1) for k in summary['mapped']};(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
