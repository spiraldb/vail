from pathlib import Path
import os,sys,time,json,hashlib,ast,copy,resource
import vail as hl,vail._native as native
import pyarrow as pa,pyarrow.compute as pc
r=Path(__file__).parent;parent=r.parent;mode,outpath=sys.argv[1:];out=Path(outpath);assert mode in ['mapped','indexed'];pins=json.loads((parent/'pins.json').read_text());assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()==pins['native_sha256'];fixture=pins['vail_fixture']['root'];case='test_matrix_table_array_arithmetic'
package=Path(hl.__file__).parent;assert {str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*.py')}==pins['vail_frontend']
# Diagnostic scope: existing simple PL field, all defined lists have width3.
# It is not an admitted rewrite for general/fallible shared producers.
def probability(v):
 index=hl.case().when(v>=-2048,hl.if_else(v<0,v+2048,v)).or_error('PL probability cache index out of bounds')
 return 10.0**(-hl.float64(index)/10.0)
def indexed(pl):
 return hl.bind(lambda values:hl.bind(lambda p0,p1,p2:(p1+2.0*p2)/(p0+p1+p2),probability(values[0]),probability(values[1]),probability(values[2])),pl)
source=Path('/private/tmp/vail-full-benchmark-20261106/protocol/upstream/benchmark_matrix_table.py');assert hashlib.sha256(source.read_bytes()).hexdigest()==pins['sources'][str(source)]
fn=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==case);fn.decorator_list=[]
class Dosage(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='hl' and node.func.attr=='pl_dosage':node.func=ast.Name(id='dosage',ctx=ast.Load())
  return node
fn=Dosage().visit(fn);v=copy.deepcopy(fn);v.name='validation_query';last=v.body[-1];assert last.value.func.attr=='_force_count_rows';v.body[-1]=ast.Return(value=last.value.func.value);module=ast.Module(body=[fn,v],type_ignores=[]);ast.fix_missing_locations(module);ns={'hl':hl,'dosage':hl.pl_dosage if mode=='mapped' else indexed};exec(compile(module,str(source),'exec'),ns)
# Validate the supported input domain outside all timing.
mt=hl.read_matrix_table(fixture);mt=mt.filter_rows(mt.alleles.length()==2);input_table=mt.select_entries('PL').select_rows().localize_entries('entries','columns').to_arrow();entries=pc.list_flatten(input_table['entries'].combine_chunks());entries=pc.filter(entries,pc.is_valid(entries));pl=entries.field('PL');lengths=pc.drop_null(pc.list_value_length(pl));assert pc.all(pc.equal(lengths,3)).as_py();vals=pc.drop_null(pc.list_flatten(pl));assert pc.min(vals).as_py()>=-2048
ref=pins['references'][case];assert hashlib.sha256(Path(ref['path']).read_bytes()).hexdigest()==ref['sha256']
with pa.memory_map(ref['path'],'r') as f:expected=pa.ipc.open_file(f).read_all()
q=ns['validation_query'](fixture);actual=q.localize_entries('entries','columns').to_arrow();assert actual.equals(expected,check_metadata=True),'Diagnostic fullArrowvalues/metadata differ'
(out/'logical-plan.txt').write_text(q._mir.core._native.logical_plan());(out/'physical-plan.txt').write_text(q._mir.core._native.physical_plan());del input_table,entries,pl,lengths,vals,mt,q,actual,expected
for _ in range(3):assert ns[case](fixture) is None
samples=[]
for _ in range(5):
 c=time.process_time();t=time.perf_counter();result=ns[case](fixture);wall=time.perf_counter()-t;cpu=time.process_time()-c;assert result is None;samples.append({'wall_seconds':wall,'cpu_seconds':cpu})
record={'mode':mode,'native_sha256':pins['native_sha256'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'frontend_verified':True,'fullArrowvalues_metadata_equal':True,'input_domain':'all defined PL width3/values>=-2048;simple fieldproducer;missing lists allowed','samples':samples,'diagnostic_only':'indexed lacks generalwidth/errorproducerorderingadmission;no productionchange','scope':'sameoriginalread/filterrows/selectentries/selectrows/forcecount body,onlydosagecallee differs;preparationincluded'}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
