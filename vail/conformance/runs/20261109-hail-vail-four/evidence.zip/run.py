from pathlib import Path
import os,json,sys,hashlib,time,statistics
from owned import run
r=Path(__file__).parent;pins=json.loads((r/'pins.json').read_text());phase=sys.argv[1];assert phase in ['validate','time'];start=time.monotonic();receipts=[]
cases=['test_matrix_table_filter_entries','test_matrix_table_filter_entries_unfilter','test_matrix_table_array_arithmetic','test_split_multi_hts']
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads((r/'protocol.json').read_text());assert digest(r/'pins.json')==lock['pins_sha256']
for p,expected in lock['scripts'].items():assert digest(r/p)==expected
if phase=='time':
 validation=json.loads((r/'validation-complete.json').read_text());assert validation['all8passed'] and validation['protocol_sha256']==digest(r/'protocol.json') and validation['pins_sha256']==digest(r/'pins.json') and len(validation['workers'])==8
 assert {(x['case'],x['mode']) for x in validation['workers']}=={(c,m) for c in cases for m in ['hail','vail']}
 for x in validation['workers']:
  for name,expected in x['hashes'].items():assert digest(Path(x['out'])/name)==expected
  assert json.loads((Path(x['out'])/'result.json').read_text())['passed'] and json.loads((Path(x['out'])/'exit.json').read_text())['group_absent']
for case in cases:
 schedule=['vail','hail'] if phase=='validate' else ['hail','vail','vail','hail','hail','vail','vail','hail']
 for i,mode in enumerate(schedule):
  assert time.monotonic()-start+180+20<1800,'Reserve full worker+cleanup within phase deadline'
  env={k:v for k,v in os.environ.items() if not k.startswith('VAIL_') and k!='PYTHONPATH'}
  env.update(JAVA_HOME='/Library/Java/JavaVirtualMachines/temurin-11.jre/Contents/Home',SPARK_LOCAL_IP='127.0.0.1',PYSPARK_PYTHON=pins['hail_python'],PYSPARK_DRIVER_PYTHON=pins['hail_python'],RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',TOKIO_WORKER_THREADS='4')
  out=r/('validate-v3' if phase=='validate' else 'time')/f'{case}-{i}-{mode}'
  rec=run([pins[mode+'_python'],str(r/'worker.py'),mode,phase,case,str(out)],out,env,180);result=json.loads((out/'result.json').read_text());assert result['passed'] and result['identity_verified'];receipts.append({'mode':mode,'case':case,'index':i,'out':str(out),'exit':rec});(r/(phase+'-receipts.json')).write_text(json.dumps(receipts,indent=2)+'\n');print('PASS',phase,case,i,mode,round(rec['seconds'],2),flush=True)
if phase=='validate':
 workers=[{'case':x['case'],'mode':x['mode'],'out':x['out'],'hashes':{name:digest(Path(x['out'])/name) for name in ['result.json','exit.json','identity.json']}} for x in receipts]
 (r/'validation-complete.json').write_text(json.dumps({'all8passed':len(receipts)==8,'protocol_sha256':digest(r/'protocol.json'),'pins_sha256':digest(r/'pins.json'),'workers':workers},indent=2)+'\n')
else:
 summary=[]
 for case in cases:
  s={'case':case}
  for mode in ['hail','vail']:
   a=[json.loads((Path(x['out'])/'result.json').read_text()) for x in receipts if x['mode']==mode and x['case']==case];assert len(a)==4
   s[mode]={k:statistics.median(statistics.median(t[k] for t in x['samples']) for x in a) for k in ['wall_seconds','cpu_seconds']}
  s['hail_divided_by_vail']={k:s['hail'][k]/s['vail'][k] for k in s['hail']};summary.append(s)
 (r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
if phase=='time':
 post={};post_deadline=time.monotonic()+60
 for mode in ['hail','vail']:
  root=Path(pins[mode+'_fixture']['root']);assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}==set(pins[mode+'_fixture']['files']);post[mode]={}
  for name,e in pins[mode+'_fixture']['files'].items():
   assert time.monotonic()<post_deadline,'Posthash60s deadline'
   p=root/name;record={'bytes':p.stat().st_size,'sha256':digest(p)};assert record==e;post[mode][name]=record
 assert time.monotonic()<post_deadline,'Posthash60s deadline'
 assert digest(pins['native'])==pins['native_sha256'] and digest(pins['hail_jar'])==pins['hail_jar_sha256']
 (r/'post-input-hashes.json').write_text(json.dumps(post,indent=2)+'\n')
 (r/'complete.json').write_text(json.dumps({'workers':32,'timed_samples':160,'post_full_file_hashes':sum(map(len,post.values())),'protocol_sha256':digest(r/'protocol.json'),'allgroupsclean':True},indent=2)+'\n')
print('PHASE COMPLETE',phase,flush=True)
