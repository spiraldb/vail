import os,sys,json,subprocess,re,collections,importlib.util
from pathlib import Path
r=Path('/private/tmp/vail-split-fundamental-20261030')
if len(sys.argv)>1:
 import vail as hl
 spec=importlib.util.spec_from_file_location('vail.mixed_variant',r/sys.argv[1]);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 mt=hl.range_matrix_table(1,4).annotate_rows(locus=hl.locus('1',100),alleles=['CA','GA','CT']).key_rows_by('locus','alleles')
 mt=mt.annotate_entries(GT=hl.call(1,2),AD=[5,7,11],PL=[40,30,20,10,0,50],GQ=99)
 rows=v.split_multi_hts(mt).localize_entries('entries','columns').collect()
 print(json.dumps([{'position':x.locus.position,'alleles':x.alleles,'a_index':x.a_index,'entries':[{'gt':e.GT.alleles,'ad':e.AD,'pl':e.PL,'gq':e.GQ} for e in x.entries]} for x in rows]))
else:
 env=os.environ.copy();env.update(PYTHONPATH=str(r/'diagnostic-v4-package'),RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',VAIL_DIAGNOSTIC_KERNEL_ROWS='1');results={}
 for mode,source in [('baseline','baseline-variant.py'),('early','early-filter.py')]:
  p=subprocess.run(['nice','-n','10','/Users/danielking/projects/vail/vail/.venv/bin/python',__file__,source],env=env,capture_output=True,text=True,timeout=60);(r/f'mixed-kernel-{mode}.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
  totals=collections.Counter()
  for name,n in re.findall(r'vail_kernel (\w+) rows=(\d+)',p.stderr):totals[name]+=int(n)
  results[mode]={'totals':dict(totals),'rows':json.loads(p.stdout)}
 assert results['baseline']['rows']==results['early']['rows']
 (r/'mixed-kernel-counts.json').write_text(json.dumps(results,indent=2));print({k:v['totals'] for k,v in results.items()})
