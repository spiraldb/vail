import json,time,importlib.util,subprocess
from pathlib import Path
import vail as hl
source=subprocess.check_output(['git','-C','/private/tmp/vail-targeted-benchmark-20261028','show','HEAD:vail/python/vail/variant.py'],text=True)
functions={}
for name,cut,result in [('normalize',"    fields = dataset.entry.dtype",'dataset'),('prepare',"    split = split.key_rows_by().explode_rows(name)",'split'),('explode',"    updates = {}",'split'),('update',"    if permit_shuffle:\n        return split.drop",'split')]:
 text=source[:source.index(cut,source.index('def split_multi_hts'))]+'    return '+result+'\n'
 path=Path('/private/tmp/vail-split-fundamental-20261030/'+name+'.py');path.write_text(text)
 spec=importlib.util.spec_from_file_location('vail.stage_'+name,str(path));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);functions[name]=m.split_multi_hts
functions['full']=hl.split_multi_hts
mt=hl.read_matrix_table('/private/tmp/vail-split-fundamental-20261030/generated.mt')
for rep in range(3):
 for name,fn in [('decode',lambda x:x),*functions.items()]:
  start=time.perf_counter();cpu=time.process_time();rows=fn(mt)._force_count_rows()
  print(json.dumps(dict(rep=rep,stage=name,rows=rows,wall=time.perf_counter()-start,cpu=time.process_time()-cpu)),flush=True)
