import subprocess,os,json,time
from pathlib import Path
r=Path('/private/tmp/vail-split-fundamental-20261030');py='/Users/danielking/projects/vail/vail/.venv/bin/python';env=os.environ.copy();env.update(PYTHONPATH=str(r/'package'),RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('VAIL_EXPERIMENT_SHARED_UNION',None)
# Full-output correctness is independent of the timed action.
for flag in [0,1]:
 e=env.copy()
 if flag:e['VAIL_EXPERIMENT_SHARED_UNION']='1'
 with (r/f'oracle-native-{flag}.json').open('w') as o,(r/f'oracle-native-{flag}.stderr').open('w') as err:
  subprocess.run(['nice','-n','10',py,str(r/'oracles.py')],env=e,stdout=o,stderr=err,check=True,timeout=45)
a=json.load(open(r/'oracle-native-0.json'));b=json.load(open(r/'oracle-native-1.json'));assert a['results']==b['results'];print('Full output oracles agree',a['sha256'],flush=True)
# Same normal binary; no concurrent build; two process pairs in opposite order.
for fixture in ['generated','profile']:
 for run,flag in enumerate([0,1,1,0]):
  e=env.copy();folder=r/f'tmp-{fixture}-{run}';folder.mkdir(exist_ok=False);e['TMPDIR']=str(folder)
  if flag:e['VAIL_EXPERIMENT_SHARED_UNION']='1'
  label=f'{fixture}-{run}-share{flag}'
  with (r/f'{label}.jsonl').open('w') as o,(r/f'{label}.stderr').open('w') as err:
   subprocess.run(['nice','-n','10',py,str(r/'native-probe.py'),fixture],env=e,stdout=o,stderr=err,check=True,timeout=60)
  print(label,'PASS',flush=True)
