import json
import vail as hl
from vail.variant import _downcode
calls=[None,*[hl.Call(a,phased=p) for a in [(),(0,),(1,),(2,),(0,0),(0,1),(1,0),(1,2),(2,1),(2,2),(65535,1)] for p in [False,True]]]
results=[]
for target in [None,0,1,2,-1,65535,65536]:
 try:
  out=hl.eval(hl.literal(calls,hl.tarray(hl.tcall)).map(lambda c:_downcode(c,hl.literal(target,hl.tint32))))
  results.append({'target':target,'values':[None if x is None else [list(x.alleles),x.phased] for x in out]})
 except Exception as e: results.append({'target':target,'error':str(e)})
print(json.dumps(results))
