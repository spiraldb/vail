import json,time,os,sys,threading,tempfile,resource
from pathlib import Path
import psutil
import vail as hl
root=Path('/private/tmp/vail-split-fundamental-20261030')
fixture=root/('profile-first-200.mt' if sys.argv[1]=='profile' else 'generated.mt')
mt=hl.read_matrix_table(str(fixture));process=psutil.Process()
for rep in range(3):
 for mode,kwargs in [('default',{}),('aligned',{'left_aligned':True}),('shuffle',{'permit_shuffle':True})]:
  if mode=='aligned' and sys.argv[1]=='profile':continue
  end=threading.Event();observed={'rss':process.memory_info().rss,'temp_bytes':0,'temp_files':0}
  folder=Path(tempfile.gettempdir())
  def monitor():
   while not end.wait(.02):
    observed['rss']=max(observed['rss'],process.memory_info().rss)
    try:
     files=[x for x in folder.iterdir() if x.is_file()];size=sum(x.stat().st_size for x in files)
     observed['temp_bytes']=max(observed['temp_bytes'],size);observed['temp_files']=max(observed['temp_files'],len(files))
    except FileNotFoundError:pass
  t=threading.Thread(target=monitor);t.start();before=resource.getrusage(resource.RUSAGE_SELF)
  start=time.perf_counter();cpu=time.process_time()
  query=hl.split_multi_hts(mt,**kwargs)
  build_wall=time.perf_counter()-start;build_cpu=time.process_time()-cpu
  action_start=time.perf_counter();action_cpu=time.process_time()
  result=query._force_count_rows()
  action_wall=time.perf_counter()-action_start;action_cpu=time.process_time()-action_cpu
  elapsed=time.perf_counter()-start;used=time.process_time()-cpu;after=resource.getrusage(resource.RUSAGE_SELF);end.set();t.join()
  print(json.dumps(dict(rep=rep,mode=mode,fixture=sys.argv[1],shared=bool(os.environ.get('VAIL_EXPERIMENT_SHARED_UNION')),rows=result,wall=elapsed,cpu=used,build_wall=build_wall,build_cpu=build_cpu,action_wall=action_wall,action_cpu=action_cpu,rss_peak_observed=observed['rss'],temp_peak_bytes_observed=observed['temp_bytes'],temp_peak_files_observed=observed['temp_files'],oublock_delta=after.ru_oublock-before.ru_oublock)),flush=True)
assert not list(folder.iterdir()),'Temporary files remain after actions'
