import os,subprocess,json
from pathlib import Path
r=Path('/private/tmp/vail-split-fundamental-20261030');py='/Users/danielking/projects/vail/vail/.venv/bin/python';env=os.environ.copy();env.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',DOWNCODE_BASELINE='1')
# Keep the exact old public split expression in both versions: isolate entry span/workspace change.
for mode,pkg in [('baseline','downcode-package'),('candidate','entry-v3-package')]:
 e=env.copy();e['PYTHONPATH']=str(r/pkg)
 with (r/f'entry-full-{mode}.json').open('w') as o,(r/f'entry-full-{mode}.stderr').open('w') as err:
  subprocess.run(['nice','-n','10',py,str(r/'downcode-full-oracles.py')],env=e,stdout=o,stderr=err,timeout=60,check=True)
a=json.loads((r/'entry-full-baseline.json').read_text());b=json.loads((r/'entry-full-candidate.json').read_text());assert a['results']==b['results'];print('Full split outputs match',a['sha256'],flush=True)
for fixture in ['generated','profile']:
 for run,mode in enumerate(['baseline','candidate','candidate','baseline']):
  e=env.copy();e['PYTHONPATH']=str(r/('downcode-package' if mode=='baseline' else 'entry-v3-package'));d=r/f'entry-tmp-{fixture}-{run}';d.mkdir(exist_ok=False);e['TMPDIR']=str(d)
  with (r/f'entry-{fixture}-{run}-{mode}.jsonl').open('w') as o,(r/f'entry-{fixture}-{run}-{mode}.stderr').open('w') as err:
   subprocess.run(['nice','-n','10',py,str(r/'downcode-probe.py'),fixture],env=e,stdout=o,stderr=err,timeout=60,check=True)
  print(fixture,run,mode,'PASS',flush=True)
