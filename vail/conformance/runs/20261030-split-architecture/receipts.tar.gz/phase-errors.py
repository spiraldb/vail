import os,json,importlib.util
from pathlib import Path
import vail as hl
r=Path('/private/tmp/vail-split-fundamental-20261030');spec=importlib.util.spec_from_file_location('vail.phase_variant',r/os.environ['PHASE_SOURCE']);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
result={}
for alleles in [['A'],['A','*'],['A','*','*'],['A','C','G']]:
 for kind,entry in [('gt',{'GT':hl.call(4)}),('pgt',{'PGT':hl.call(4)}),('ad',{'AD':[1]}),('pl',{'PL':[1,2]}),('overflow',{'AD':[2147483647]*len(alleles)})]:
  for action in ['entries','force']:
   mt=hl.range_matrix_table(1,1).annotate_rows(locus=hl.locus('1',100),alleles=alleles).key_rows_by('locus','alleles').annotate_entries(**entry)
   key=json.dumps([alleles,kind,action]);split=v.split_multi_hts(mt)
   try:
    value=split.entries().collect() if action=='entries' else split._force_count_rows()
    result[key]={'passed':True,'length':len(value) if action=='entries' else value}
   except Exception as e:result[key]={'passed':False,'error':str(e)}
print(json.dumps(result))
