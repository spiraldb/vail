import os,subprocess,json,hashlib
from pathlib import Path
r=Path('/private/tmp/vail-split-fundamental-20261030');py='/Users/danielking/projects/vail/vail/.venv/bin/python'
env=os.environ.copy();env.update(PYTHONPATH=str(r/'entry-v3-package'),RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('VAIL_EXPERIMENT_SHARED_UNION',None)
for mode in ['baseline','candidate']:
 e=env.copy()
 e['PHASE_SOURCE']='baseline-variant.py' if mode=='baseline' else 'early-filter.py'
 with (r/f'phase-full-{mode}.json').open('w') as o,(r/f'phase-full-{mode}.stderr').open('w') as err:
  subprocess.run(['nice','-n','10',py,str(r/'phase-full-oracles.py')],env=e,stdout=o,stderr=err,timeout=60,check=True)
a=json.loads((r/'phase-full-baseline.json').read_text());b=json.loads((r/'phase-full-candidate.json').read_text());assert a['results']==b['results'];print('Full split outputs match',a['sha256'],flush=True)
for fixture in ['generated','profile']:
 for run,mode in enumerate(['baseline','candidate','candidate','baseline']):
  e=env.copy();d=r/f'phase-tmp-{fixture}-{run}';d.mkdir(exist_ok=False);e['TMPDIR']=str(d)
  e['PHASE_SOURCE']='baseline-variant.py' if mode=='baseline' else 'early-filter.py'
  with (r/f'phase-{fixture}-{run}-{mode}.jsonl').open('w') as o,(r/f'phase-{fixture}-{run}-{mode}.stderr').open('w') as err:
   subprocess.run(['nice','-n','10',py,str(r/'phase-native-probe.py'),fixture],env=e,stdout=o,stderr=err,timeout=60,check=True)
  print(fixture,run,mode,'PASS',flush=True)
