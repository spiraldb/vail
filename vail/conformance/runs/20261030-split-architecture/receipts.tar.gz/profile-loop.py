import os,time,json,sys,importlib.util
from pathlib import Path
import vail as hl
import vail.variant
r=Path('/private/tmp/vail-split-fundamental-20261030')
spec=importlib.util.spec_from_file_location('vail.baseline_variant',r/'baseline-variant.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);vail.variant._downcode=old._downcode
mt=hl.read_matrix_table(str(r/'profile-first-200.mt'));mode=sys.argv[1];kwargs={} if mode=='default' else {'permit_shuffle':True}
assert hl.split_multi_hts(mt,**kwargs)._force_count_rows()==204
print('READY',flush=True);start=time.monotonic();n=0
while time.monotonic()-start<7:
 assert hl.split_multi_hts(mt,**kwargs)._force_count_rows()==204;n+=1
print(json.dumps({'mode':mode,'actions':n,'wall':time.monotonic()-start}),flush=True)
