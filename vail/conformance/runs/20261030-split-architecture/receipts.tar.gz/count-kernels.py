import os,subprocess,sys,json,re,collections
from pathlib import Path
r=Path('/private/tmp/vail-split-fundamental-20261030')
if len(sys.argv)>1:
 import vail as hl
 import importlib.util
 fixture,front,mode=sys.argv[1:]
 source='early-filter.py' if front=='early' else 'baseline-variant.py'
 spec=importlib.util.spec_from_file_location('vail.count_variant',r/source);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 mt=hl.read_matrix_table(str(r/('generated.mt' if fixture=='generated' else 'profile-first-200.mt')))
 kwargs={} if mode=='default' else {'permit_shuffle':True}
 print(v.split_multi_hts(mt,**kwargs)._force_count_rows(),flush=True)
else:
 env=os.environ.copy();env.update(PYTHONPATH=str(r/'diagnostic-v4-package'),RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VAIL_DIAGNOSTIC_KERNEL_ROWS='1')
 results={}
 for fixture in ['generated','profile']:
  for front,mode in [('baseline','default'),('baseline','shuffle'),('early','default')]:
   label=f'{fixture}-{front}-{mode}'
   p=subprocess.run(['nice','-n','10','/Users/danielking/projects/vail/vail/.venv/bin/python',__file__,fixture,front,mode],env=env,capture_output=True,text=True,timeout=60);(r/f'kernel-count-{label}.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
   totals=collections.Counter();batches=collections.Counter()
   for name,rows in re.findall(r'vail_kernel (\w+) rows=(\d+)',p.stderr):totals[name]+=int(rows);batches[name]+=1
   results[label]={'totals':dict(totals),'batches':dict(batches),'output':p.stdout.strip()};print(label,results[label],flush=True)
 (r/'kernel-counts.json').write_text(json.dumps(results,indent=2))
