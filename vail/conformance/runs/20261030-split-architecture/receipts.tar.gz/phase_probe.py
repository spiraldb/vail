import time,json,os
import vail as hl
import importlib.util
spec=importlib.util.spec_from_file_location('vail.variant_phase','/private/tmp/vail-targeted-benchmark-20261028/vail/python/vail/variant.py')
phase=importlib.util.module_from_spec(spec);spec.loader.exec_module(phase)
mt=hl.range_matrix_table(1000,64,n_partitions=4)
mt=mt.annotate_rows(locus=hl.locus('1',mt.row_idx+100),alleles=['A','C','G'])
mt=mt._copy(row_key=('locus','alleles'))
x=hl.int32((mt.row_idx+mt.col_idx)%10)
mt=mt.annotate_entries(GT=hl.call(0,hl.int32(mt.col_idx%3)),AD=hl.array([x+2,x+3,x+4]),PL=hl.array([x+40,x+30,x+20,x+10,x,x+50]),GQ=99,DP=23)
for rep in range(3):
 for mode,kwargs in [('default',{}),('aligned',{'left_aligned':True}),('shuffle',{'permit_shuffle':True})]:
  start=time.perf_counter();cpu=time.process_time();result=phase.split_multi_hts(mt,**kwargs)._force_count_rows()
  print(json.dumps(dict(rep=rep,mode=mode,rows=result,wall=time.perf_counter()-start,cpu=time.process_time()-cpu)),flush=True)
