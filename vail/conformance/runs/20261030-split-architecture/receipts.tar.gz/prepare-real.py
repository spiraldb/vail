from pathlib import Path
import vail as hl
r=Path('/private/tmp/vail-split-fundamental-20261030');out=r/'profile-first-200.mt'
if not out.exists():hl.import_vcf(str(r/'profile-first-200.vcf'),min_partitions=4).write(str(out))
print(hl.read_matrix_table(str(out)).count())
