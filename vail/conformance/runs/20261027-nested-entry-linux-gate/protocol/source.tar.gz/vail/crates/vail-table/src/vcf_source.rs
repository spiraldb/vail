//! Bounded native VCF scan. Header planning is eager; record decoding is lazy.
//! A blocking decoder worker feeds at most two Arrow batches to the async scan.
use arrow_array::{RecordBatch, RecordBatchOptions};
use arrow_schema::SchemaRef;
use datafusion_common::{DataFusionError, Result};
use datafusion_datasource::{
    PartitionedFile, TableSchema,
    file::FileSource,
    file_scan_config::FileScanConfig,
    file_stream::{FileOpenFuture, FileOpener},
};
use datafusion_physical_plan::metrics::ExecutionPlanMetricsSet;
use object_store::ObjectStore;
use std::{
    fmt,
    io::{BufRead, BufReader, Read},
    process::{Child, Command, Stdio},
    sync::Arc,
    thread::JoinHandle,
};

/// htslib tabix regions use one-based inclusive coordinates. The decoder's
/// subsequent locus predicate narrows overlap queries to records whose POS is
/// in the interval, matching Hail's GVCFPartitionReader.
#[derive(Clone, Debug, serde::Deserialize)]
struct IndexedRegion {
    executable: String,
    contigs: Vec<String>,
    start: i32,
    end: i32,
}

struct VcfInput {
    reader: Box<dyn BufRead + Send>,
    child: Option<Child>,
    stderr: Option<JoinHandle<Vec<u8>>>,
}
impl VcfInput {
    fn open(path: &str, region: Option<&IndexedRegion>) -> vail_vcf::Result<Self> {
        let Some(region) = region else {
            return Ok(Self { reader: vail_vcf::open(path)?, child: None, stderr: None });
        };
        if region.end < region.start || region.end < 1 || region.contigs.is_empty() {
            return Ok(Self::empty());
        }
        let mut contigs = region.contigs.clone();
        if contigs.len() > 1 {
            // Several raw contigs can map to one canonical contig. Query all
            // of them in the TBI/CSI sequence order, which follows the source
            // contig blocks, rather than recoding-map insertion order.
            let mut names = Self::command(&region.executable, &["-l".into(), "--".into(), path.into()])?;
            let mut line = String::new();
            let mut ordered = Vec::new();
            while names.reader.read_line(&mut line).map_err(|e| e.to_string())? != 0 {
                let name = line.trim_end_matches(['\r', '\n']);
                if contigs.iter().any(|candidate| candidate == name) {
                    ordered.push(name.to_owned());
                }
                line.clear();
            }
            names.finish()?;
            contigs = ordered;
        }
        if contigs.is_empty() {
            return Ok(Self::empty());
        }
        let mut arguments = vec!["--".into(), path.into()];
        arguments.extend(contigs.iter().map(|contig| {
            format!("{contig}:{}-{}", region.start.max(1), region.end)
        }));
        Self::command(&region.executable, &arguments)
    }
    fn empty() -> Self {
        Self {
            reader: Box::new(std::io::Cursor::new(Vec::<u8>::new())),
            child: None,
            stderr: None,
        }
    }
    fn command(executable: &str, arguments: &[String]) -> vail_vcf::Result<Self> {
        let mut child = Command::new(executable)
            .args(arguments)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| format!("could not execute tabix: {e}"))?;
        let stdout = child.stdout.take().expect("piped tabix stdout");
        let mut stderr = child.stderr.take().expect("piped tabix stderr");
        // Drain stderr concurrently to avoid pipe deadlocks, retaining bounded
        // diagnostics even if htslib reports many warnings.
        let stderr = std::thread::spawn(move || {
            let mut diagnostic = Vec::new();
            let _ = stderr.by_ref().take(8192).read_to_end(&mut diagnostic);
            let _ = std::io::copy(&mut stderr, &mut std::io::sink());
            diagnostic
        });
        Ok(Self {
            reader: Box::new(BufReader::new(stdout)),
            child: Some(child),
            stderr: Some(stderr),
        })
    }
    fn finish(&mut self) -> vail_vcf::Result<()> {
        if let Some(mut child) = self.child.take() {
            let status = child.wait().map_err(|e| format!("waiting for tabix: {e}"))?;
            let diagnostic = self.stderr.take().and_then(|worker| worker.join().ok()).unwrap_or_default();
            if !status.success() {
                return Err(format!("tabix query failed ({status}): {}", String::from_utf8_lossy(&diagnostic)));
            }
        }
        Ok(())
    }
}
impl Drop for VcfInput {
    fn drop(&mut self) {
        // A downstream limit or cancellation must stop and reap the decoder's
        // child even if its stdout pipe has not been drained.
        if let Some(mut child) = self.child.take() {
            let _ = child.kill();
            let _ = child.wait();
        }
        if let Some(worker) = self.stderr.take() {
            let _ = worker.join();
        }
    }
}

#[derive(Clone, Debug)]
pub struct VcfSource {
    schema: TableSchema,
    header: vail_vcf::Header,
    options: vail_vcf::Options,
    batch_size: usize,
    indexed_region: Option<IndexedRegion>,
    metrics: ExecutionPlanMetricsSet,
    projection: Option<datafusion_physical_expr::projection::ProjectionExprs>,
    decode_paths: Option<Vec<vail_vcf::DecodePath>>,
}
impl VcfSource {
    pub fn new(schema: SchemaRef, value: &serde_json::Value) -> Result<Self> {
        let header: vail_vcf::Header = serde_json::from_value(value["header"].clone())
            .map_err(|e| DataFusionError::Execution(e.to_string()))?;
        let options: vail_vcf::Options = serde_json::from_value(value["options"].clone())
            .map_err(|e| DataFusionError::Execution(e.to_string()))?;
        Ok(Self {
            schema: TableSchema::from(schema),
            header,
            options,
            batch_size: 8192,
            indexed_region: value.get("indexed_region")
                .filter(|v| !v.is_null())
                .map(|v| serde_json::from_value(v.clone()))
                .transpose()
                .map_err(|e| DataFusionError::Execution(e.to_string()))?,
            metrics: ExecutionPlanMetricsSet::new(),
            projection: None,
            decode_paths: value
                .get("decode_paths")
                .map(|v| serde_json::from_value(v.clone()))
                .transpose()
                .map_err(|e| DataFusionError::Execution(e.to_string()))?,
        })
    }
}
impl FileSource for VcfSource {
    fn create_file_opener(
        &self,
        _store: Arc<dyn ObjectStore>,
        _config: &FileScanConfig,
        _partition: usize,
    ) -> Result<Arc<dyn FileOpener>> {
        Ok(Arc::new(VcfOpener {
            source: self.clone(),
        }))
    }
    fn table_schema(&self) -> &TableSchema {
        &self.schema
    }
    fn projection(&self) -> Option<&datafusion_physical_expr::projection::ProjectionExprs> {
        self.projection.as_ref()
    }
    fn try_pushdown_projection(
        &self,
        projection: &datafusion_physical_expr::projection::ProjectionExprs,
    ) -> Result<Option<Arc<dyn FileSource>>> {
        if !projection.expr_iter().all(|expr| {
            expr.downcast_ref::<datafusion_physical_expr::expressions::Column>()
                .is_some()
        }) {
            return Ok(None);
        }
        let mut source = self.clone();
        source.projection = Some(projection.clone());
        Ok(Some(Arc::new(source)))
    }
    fn with_batch_size(&self, size: usize) -> Arc<dyn FileSource> {
        let mut source = self.clone();
        source.batch_size = size.max(1);
        Arc::new(source)
    }
    fn metrics(&self) -> &ExecutionPlanMetricsSet {
        &self.metrics
    }
    fn file_type(&self) -> &str {
        "vcf"
    }
    fn supports_repartitioning(&self) -> bool {
        false
    }
    fn apply_expressions(
        &self,
        f: &mut dyn FnMut(
            &Arc<dyn datafusion_physical_plan::PhysicalExpr>,
        ) -> Result<datafusion_common::tree_node::TreeNodeRecursion>,
    ) -> Result<datafusion_common::tree_node::TreeNodeRecursion> {
        datafusion_physical_plan::apply_expression_roots(
            std::iter::empty::<Arc<dyn datafusion_physical_plan::PhysicalExpr>>(),
            f,
        )
    }
    fn fmt_extra(
        &self,
        _t: datafusion_physical_plan::display::DisplayFormatType,
        _f: &mut fmt::Formatter,
    ) -> fmt::Result {
        Ok(())
    }
}
struct VcfOpener {
    source: VcfSource,
}
impl FileOpener for VcfOpener {
    fn open(&self, file: PartitionedFile) -> Result<FileOpenFuture> {
        if file.range.is_some() {
            return Err(DataFusionError::NotImplemented(
                "VCF byte-range partitions are not implemented".into(),
            ));
        }
        let source = self.source.clone();
        let path = format!("/{}", file.object_meta.location);
        Ok(Box::pin(async move {
            let (sender, receiver) = tokio::sync::mpsc::channel::<Result<RecordBatch>>(2);
            tokio::task::spawn_blocking(move || {
                let run = || -> vail_vcf::Result<()> {
                    let mut input = VcfInput::open(&path, source.indexed_region.as_ref())?;
                    let indices = source.projection.as_ref().map(|p| {
                        p.expr_iter()
                            .map(|expr| {
                                expr.downcast_ref::<datafusion_physical_expr::expressions::Column>()
                                    .unwrap()
                                    .index()
                            })
                            .collect::<Vec<_>>()
                    });
                    let count_only = indices.as_ref().is_some_and(Vec::is_empty);
                    let mut parser = vail_vcf::Parser::new(source.header, source.options)?;
                    let paths = source.decode_paths.unwrap_or_else(|| {
                        vec![
                            vail_vcf::DecodePath {
                                fields: vec!["__vail_matrix_row".into()],
                                shape: false,
                                validity: false,
                            },
                            vail_vcf::DecodePath {
                                fields: vec!["__vail_matrix_cells".into()],
                                shape: false,
                                validity: false,
                            },
                        ]
                    });
                    let paths = paths
                        .into_iter()
                        .filter(|path| {
                            indices.as_ref().is_none_or(|indices| {
                                path.fields.first().is_some_and(|root| {
                                    indices.contains(&if root == "__vail_matrix_row" {
                                        0
                                    } else {
                                        1
                                    })
                                })
                            })
                        })
                        .collect();
                    parser = parser.with_projection(paths);
                    let samples = if parser.reads_samples() {
                        parser.header().samples.len()
                    } else {
                        0
                    };
                    let width = 6
                        + parser.header().info.len()
                        + samples.saturating_mul(parser.header().format.len().max(1));
                    let batch_rows = source.batch_size.min((65536 / width.max(1)).max(1));
                    let mut batch = parser.batch()?;
                    let finish = |batch: &mut vail_vcf::Batch| -> vail_vcf::Result<RecordBatch> {
                        if count_only {
                            let rows = batch.rows;
                            batch.rows = 0;
                            RecordBatch::try_new_with_options(
                                Arc::new(arrow_schema::Schema::empty()),
                                vec![],
                                &RecordBatchOptions::new().with_row_count(Some(rows)),
                            )
                            .map_err(|e| e.to_string())
                        } else {
                            let batch = batch.finish()?;
                            if let Some(indices) = &indices {
                                batch.project(indices).map_err(|e| e.to_string())
                            } else {
                                Ok(batch)
                            }
                        }
                    };
                    let mut line = String::new();
                    let mut line_number = 0usize;
                    loop {
                        if sender.is_closed() {
                            return Ok(());
                        }
                        line.clear();
                        if input.reader
                            .read_line(&mut line)
                            .map_err(|e| format!("{path}: {e}"))?
                            == 0
                        {
                            break;
                        }
                        line_number += 1;
                        let record = line.trim_end_matches(['\r', '\n']);
                        if let Some(region) = &source.indexed_region {
                            // tabix returns overlapping deletions/reference
                            // blocks; Hail imports by POS, not span overlap.
                            let position = record.split('\t').nth(1)
                                .ok_or_else(|| format!("{path}: tabix record missing POS"))?
                                .parse::<i32>()
                                .map_err(|e| format!("{path}: invalid tabix POS: {e}"))?;
                            if position < region.start || position > region.end {
                                continue;
                            }
                        }
                        if count_only {
                            if parser.count_record(record)? {
                                batch.rows += 1;
                            }
                        } else {
                            parser
                                .append(&mut batch, record)
                                .map_err(|e| format!("{path}:{line_number}: {e}"))?;
                        }
                        if batch.rows == batch_rows {
                            if sender.blocking_send(Ok(finish(&mut batch)?)).is_err() {
                                return Ok(());
                            }
                        }
                    }
                    input.finish()?;
                    if batch.rows > 0 {
                        let _ = sender.blocking_send(Ok(finish(&mut batch)?));
                    }
                    Ok(())
                };
                if let Err(error) = run() {
                    let _ = sender.blocking_send(Err(DataFusionError::Execution(error)));
                }
            });
            let stream = futures::stream::unfold(receiver, |mut receiver| async move {
                receiver.recv().await.map(|batch| (batch, receiver))
            });
            Ok(Box::pin(stream) as futures::stream::BoxStream<'static, Result<RecordBatch>>)
        }))
    }
}
