//! Structural identity over native expression DAGs. Each hash visits a shared
//! node once; equality memoizes node pairs and compares every actual field.
//! Digests accelerate lookup only. No text encoding or global memo is involved.
use crate::{
    expressions::{ArrayReduction, BinaryOperator, Expr, Type, UnaryOperator},
    reference::ReferenceDefinition,
};
use datafusion_common::ScalarValue;
use std::{
    collections::{HashMap, HashSet},
    hash::{Hash, Hasher},
    mem::Discriminant,
    sync::Arc,
};

#[derive(PartialEq, Eq, Hash)]
enum Properties<'a> {
    None,
    Text(&'a str),
    Texts(Vec<&'a str>),
    Type(&'a Type),
    TextType(&'a str, &'a Type),
    OptionalTextType(&'a str, &'a Option<Type>),
    MatrixField(&'a str, &'a str, &'a Option<Type>),
    Lookup(&'a str, bool, bool, &'a Option<Type>),
    Scalar(&'a ScalarValue),
    Literal(&'a Type, &'a serde_json::Value),
    Aggregate(
        &'a str,
        bool,
        &'a serde_json::Value,
        &'a Option<Type>,
        Vec<&'a str>,
    ),
    ThreeTexts(&'a str, &'a str, &'a str),
    Fold(&'a str, &'a str, bool),
    Scan(&'a str, &'a serde_json::Value, &'a Type),
    Predicate(&'a str, bool),
    AlignedMap(&'a Type, bool),
    AlignedInput(&'a str, &'a Option<String>, &'a Type),
    Switch(&'a str, bool),
    Binary(BinaryOperator),
    Unary(UnaryOperator),
    Slice(bool, bool, bool),
    Reduce(ArrayReduction, bool),
    Reference(&'a ReferenceDefinition),
    Csv(&'a str, &'a Option<String>, &'a [String], usize),
}
fn properties(expr: &Expr) -> (Discriminant<Expr>, Properties<'_>) {
    let properties = match expr {
        Expr::MatrixField { axis, name, dtype } => Properties::MatrixField(axis, name, dtype),
        Expr::MatrixScope { axis, .. } => Properties::Text(axis),
        Expr::MatrixNumCols { .. } | Expr::MatrixColumnPosition { .. } => Properties::None,
        Expr::TableLookup {
            reference,
            all_matches,
            query_interval,
            dtype,
            ..
        } => Properties::Lookup(reference, *all_matches, *query_interval, dtype),
        Expr::RuntimeLiteral { value } => Properties::Scalar(value),
        Expr::Literal { dtype, value } => Properties::Literal(dtype, value),
        Expr::Aggregate {
            function,
            value,
            options,
            result_type,
            init,
        } => Properties::Aggregate(
            function,
            value.is_some(),
            options,
            result_type,
            init.iter().map(|(name, _)| name.as_str()).collect(),
        ),
        Expr::AggregateFold {
            state_parameter,
            left_parameter,
            right_parameter,
            ..
        } => Properties::ThreeTexts(state_parameter, left_parameter, right_parameter),
        Expr::AggGroupBy { .. } | Expr::AggFilter { .. } => Properties::None,
        Expr::AggArray { parameter, .. } | Expr::AggExplode { parameter, .. } => {
            Properties::Text(parameter)
        }
        Expr::LambdaVariable { name, dtype } => Properties::OptionalTextType(name, dtype),
        Expr::NestedFunction {
            function, dtype, ..
        } => Properties::TextType(function, dtype),
        Expr::StringFunction { function, .. } => Properties::Text(function),
        Expr::CollectionCast { dtype, .. } | Expr::Cast { dtype, .. } | Expr::Die { dtype, .. } => {
            Properties::Type(dtype)
        }
        Expr::IntegerBinary { operator, .. } | Expr::Binary { operator, .. } => {
            Properties::Binary(*operator)
        }
        Expr::Tuple { .. } => Properties::None,
        Expr::AlignedMatrixMap {
            dtype,
            preserve_cell,
            ..
        } => Properties::AlignedMap(dtype, *preserve_cell),
        Expr::AlignedMapInput { axis, name, dtype } => Properties::AlignedInput(axis, name, dtype),
        Expr::ArrayMap { parameter, .. } | Expr::ArrayFilter { parameter, .. } => {
            Properties::Text(parameter)
        }
        Expr::ArrayAggregateScan {
            function,
            options,
            dtype,
            ..
        } => Properties::Scan(function, options, dtype),
        Expr::ArrayFold {
            accumulator,
            parameter,
            scan,
            ..
        } => Properties::Fold(accumulator, parameter, *scan),
        Expr::ArrayPredicate {
            parameter, first, ..
        } => Properties::Predicate(parameter, *first),
        Expr::StreamRange { .. } | Expr::ArrayGrouped { .. } => Properties::None,
        Expr::ExternalGlobal { reference, dtype } => Properties::TextType(reference, dtype),
        Expr::Global { name } | Expr::Column { name } => Properties::Text(name),
        Expr::Switch {
            parameter, missing, ..
        } => Properties::Switch(parameter, missing.is_some()),
        Expr::Unary { operator, .. } => Properties::Unary(*operator),
        Expr::ToString { .. } | Expr::IsMissing { .. } | Expr::IfElse { .. } => Properties::None,
        Expr::GetField { name, .. } => Properties::Text(name),
        Expr::Interval { .. } | Expr::IntervalContains { .. } | Expr::IntervalOverlaps { .. } => {
            Properties::None
        }
        Expr::Struct { fields } => {
            Properties::Texts(fields.iter().map(|(name, _)| name.as_str()).collect())
        }
        Expr::Array { element_type, .. } => Properties::Type(element_type),
        Expr::ArrayFlatten { .. } | Expr::ArrayLength { .. } | Expr::ArrayIndex { .. } => {
            Properties::None
        }
        Expr::ArraySlice {
            start, stop, step, ..
        } => Properties::Slice(start.is_some(), stop.is_some(), step.is_some()),
        Expr::ArrayReduce {
            operation,
            filter_missing,
            ..
        } => Properties::Reduce(*operation, *filter_missing),
        Expr::Locus { reference, .. }
        | Expr::LocusValid { reference, .. }
        | Expr::LocusFromGlobalPosition { reference, .. }
        | Expr::ParseLocus { reference, .. } => Properties::Reference(reference),
        Expr::LocusOp { operation, .. } => Properties::Text(operation),
        Expr::ParseCsvLine {
            delimiter,
            quote,
            missing,
            expected_fields,
            ..
        } => Properties::Csv(delimiter, quote, missing, *expected_fields),
    };
    (std::mem::discriminant(expr), properties)
}

fn fingerprint(expr: &Expr, memo: &mut HashMap<usize, u64>) -> u64 {
    let address = expr as *const Expr as usize;
    if let Some(value) = memo.get(&address) {
        return *value;
    }
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    properties(expr).hash(&mut hasher);
    let mut children = 0_usize;
    expr.for_each_child(&mut |child| {
        fingerprint(child, memo).hash(&mut hasher);
        children += 1;
    });
    children.hash(&mut hasher);
    let value = hasher.finish();
    memo.insert(address, value);
    value
}

/// Collision-safe structural classes within one strict region. Opaque
/// non-leaf nodes retain distinct identities without examining their bodies.
/// Intern shallow properties plus child classes, never whole descendant trees.
pub(crate) fn canonical_nodes(root: &Expr, descend: impl Fn(&Expr) -> bool) -> HashMap<usize, usize> {
    fn visit<'a>(
        node: &'a Expr,
        seen: &mut HashMap<usize, usize>,
        classes: &mut HashMap<(Discriminant<Expr>, Properties<'a>, Vec<usize>), usize>,
        descend: &impl Fn(&Expr) -> bool,
    ) -> usize {
        let address = node as *const Expr as usize;
        if let Some(&id) = seen.get(&address) {
            return id;
        }
        let mut has_children = false;
        node.for_each_child(&mut |_| has_children = true);
        if has_children && !descend(node) {
            let id = seen.len();
            seen.insert(address, id);
            return id;
        }
        let mut children = Vec::new();
        node.for_each_child(&mut |child| children.push(visit(child, seen, classes, descend)));
        let (kind, properties) = properties(node);
        let next = seen.len();
        let id = *classes.entry((kind, properties, children)).or_insert(next);
        seen.insert(address, id);
        id
    }
    let mut seen = HashMap::new();
    visit(root, &mut seen, &mut HashMap::new(), &descend);
    seen
}
fn equal(left: &Expr, right: &Expr, memo: &mut HashSet<(usize, usize)>) -> bool {
    if std::ptr::eq(left, right) {
        return true;
    }
    let addresses = (left as *const Expr as usize, right as *const Expr as usize);
    if !memo.insert(addresses) {
        return true;
    }
    if properties(left) != properties(right) {
        return false;
    }
    let mut left_children = Vec::new();
    let mut right_children = Vec::new();
    left.for_each_child(&mut |child| left_children.push(child));
    right.for_each_child(&mut |child| right_children.push(child));
    left_children.len() == right_children.len()
        && left_children
            .into_iter()
            .zip(right_children)
            .all(|(a, b)| equal(a, b, memo))
}
impl PartialEq for Expr {
    fn eq(&self, other: &Self) -> bool {
        equal(self, other, &mut HashSet::new())
    }
}
impl Eq for Expr {}
impl Hash for Expr {
    fn hash<H: Hasher>(&self, state: &mut H) {
        fingerprint(self, &mut HashMap::new()).hash(state);
    }
}

/// Cache a root fingerprint for repeated optimizer hash-table probes. Retain its
/// native DAG for exact, collision-safe equality; ownership stays query-local.
#[derive(Clone)]
pub(crate) struct Identity {
    expression: Arc<Expr>,
    canonical: Arc<Expr>,
    fingerprint: u64,
    nodes: usize,
}
impl Identity {
    pub(crate) fn new(expression: Expr) -> Self {
        Self::from_canonical(expression, None)
    }

    /// Scalar semantic kernels separately expose their free input arguments
    /// and effects. Only that contract opts into lexical-name equivalence.
    pub(crate) fn with_bound_names(expression: Expr) -> Self {
        // This optional optimization must not amplify planning for large
        // generated programs. Exact original identity is always a safe fallback.
        const MAX_NODES: usize = 1024;
        let mut seen = HashSet::new();
        let mut pending = vec![&expression];
        let mut has_binder = false;
        while let Some(node) = pending.pop() {
            if !seen.insert(node as *const Expr as usize) {
                continue;
            }
            if seen.len() > MAX_NODES {
                return Self::new(expression);
            }
            has_binder |= matches!(node, Expr::ArrayMap { .. } | Expr::ArrayFilter { .. }
                | Expr::ArrayPredicate { .. } | Expr::ArrayFold { .. } | Expr::Switch { .. }
                | Expr::AggArray { .. } | Expr::AggExplode { .. } | Expr::AggregateFold { .. });
            let mut too_wide = false;
            node.for_each_child(&mut |child| {
                if pending.len() <= MAX_NODES {
                    pending.push(child);
                } else {
                    too_wide = true;
                }
            });
            if too_wide {
                return Self::new(expression);
            }
        }
        if !has_binder {
            return Self::new(expression);
        }
        let canonical = alpha_identity(&expression);
        Self::from_canonical(expression, canonical)
    }

    fn from_canonical(expression: Expr, canonical: Option<Expr>) -> Self {
        let expression = Arc::new(expression);
        let canonical = canonical.map(Arc::new).unwrap_or_else(|| expression.clone());
        let mut memo = HashMap::new();
        let fingerprint = fingerprint(&canonical, &mut memo);
        Self {
            expression,
            canonical,
            fingerprint,
            nodes: memo.len(),
        }
    }

    pub(crate) fn expression(&self) -> &Expr {
        &self.expression
    }
}

/// Callback names are lexical implementation details, not semantic inputs.
/// Canonicalize only the owned identity: execution retains the original names.
/// Free names remain distinct, and the chosen namespace cannot capture them.
fn alpha_identity(expression: &Expr) -> Option<Expr> {
    fn summarize(node: &Expr, summaries: &mut HashMap<usize, HashSet<String>>) -> HashSet<String> {
        let address = node as *const Expr as usize;
        if let Some(names) = summaries.get(&address) {
            return names.clone();
        }
        let mut names = HashSet::new();
        if let Expr::LambdaVariable { name, .. } = node {
            names.insert(name.clone());
        }
        let mut position = 0;
        node.for_each_child(&mut |child| {
            let mut child_names = summarize(child, summaries);
            for binder in node.child_binders(position) {
                child_names.remove(binder);
            }
            position += 1;
            names.extend(child_names);
        });
        summaries.insert(address, names.clone());
        names
    }
    let mut free_names = HashMap::new();
    let free = summarize(expression, &mut free_names);
    let mut prefix = "\0vail_bound_".to_owned();
    while free.iter().any(|name| name.starts_with(&prefix)) {
        prefix.push('_');
    }
    struct Normalizer {
        prefix: String,
        // Scope IDs are interned by lexical edge, not traversal occurrence.
        // A shared expression reached repeatedly in one scope is rewritten once.
        scopes: Vec<Vec<(String, String)>>,
        edges: HashMap<(usize, Vec<String>), usize>,
        free_names: HashMap<usize, HashSet<String>>,
        memo: HashMap<(usize, usize, Vec<(String, Option<String>)>), Expr>,
        remaining: usize,
    }
    impl Normalizer {
        fn child_scope(&mut self, parent: usize, binders: Vec<&str>) -> usize {
            if binders.is_empty() {
                return parent;
            }
            let key = (
                parent,
                binders.iter().map(|name| (*name).to_owned()).collect(),
            );
            if let Some(id) = self.edges.get(&key) {
                return *id;
            }
            let mut names = self.scopes[parent].clone();
            for name in binders {
                names.push((name.to_owned(), format!("{}{}", self.prefix, names.len())));
            }
            let id = self.scopes.len();
            self.scopes.push(names);
            self.edges.insert(key, id);
            id
        }
        fn visit(&mut self, node: &Expr, scope: usize) -> Result<Expr, ()> {
            let address = node as *const Expr as usize;
            let depth = self.scopes[scope].len();
            // Irrelevant enclosing binders must not multiply visits to a
            // shared DAG. Only free names of this node can affect its result.
            let mut captures = self.free_names[&address]
                .iter()
                .map(|name| {
                    (
                        name.clone(),
                        self.scopes[scope]
                            .iter()
                            .rev()
                            .find(|(original, _)| original == name)
                            .map(|(_, bound)| bound.clone()),
                    )
                })
                .collect::<Vec<_>>();
            captures.sort_unstable();
            let key = (address, depth, captures);
            if let Some(result) = self.memo.get(&key) {
                return Ok(result.clone());
            }
            if self.remaining == 0 {
                return Err(());
            }
            self.remaining -= 1;
            let mut position = 0;
            let mut result = node
                .try_map_original_children::<()>(|child| {
                    let child_scope = self.child_scope(scope, node.child_binders(position));
                    position += 1;
                    self.visit(child, child_scope)
                })?;
            let canonical = |index| format!("{}{}", self.prefix, depth + index);
            match &mut result {
                Expr::LambdaVariable { name, .. } => {
                    if let Some((_, bound)) = self.scopes[scope]
                        .iter()
                        .rev()
                        .find(|(original, _)| original == name)
                    {
                        *name = bound.clone();
                    }
                }
                Expr::ArrayMap { parameter, .. }
                | Expr::ArrayFilter { parameter, .. }
                | Expr::ArrayPredicate { parameter, .. }
                | Expr::AggArray { parameter, .. }
                | Expr::AggExplode { parameter, .. }
                | Expr::Switch { parameter, .. } => *parameter = canonical(0),
                Expr::ArrayFold {
                    accumulator,
                    parameter,
                    ..
                } => {
                    *accumulator = canonical(0);
                    *parameter = canonical(1);
                }
                Expr::AggregateFold {
                    state_parameter,
                    left_parameter,
                    right_parameter,
                    ..
                } => {
                    *state_parameter = canonical(0);
                    *left_parameter = canonical(0);
                    *right_parameter = canonical(1);
                }
                _ => {}
            }
            self.memo.insert(key, result.clone());
            Ok(result)
        }
    }
    Normalizer {
        prefix,
        scopes: vec![vec![]],
        edges: HashMap::new(),
        free_names,
        memo: HashMap::new(),
        remaining: 4096,
    }
    .visit(expression, 0)
    .ok()
}

impl std::fmt::Debug for Identity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ExpressionIdentity")
            .field("fingerprint", &format_args!("{:016x}", self.fingerprint))
            .field("nodes", &self.nodes)
            .finish()
    }
}
impl PartialEq for Identity {
    fn eq(&self, other: &Self) -> bool {
        self.fingerprint == other.fingerprint && self.canonical == other.canonical
    }
}
impl Eq for Identity {}
impl Hash for Identity {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.fingerprint.hash(state);
    }
}
