from pathlib import Path
import json,os,sys
r=Path(__file__).parent;sys.path.insert(0,str(r));from owned import run
cfg=json.loads((r/'config.json').read_text());rev=r/'revision2';e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',VAIL_TRACE_SEMANTIC_PREP='1',VAIL_TRACE_FORCE_COUNT_PLAN='1')
for case in ['short_ascii','unicode']:
 out=rev/('route-'+case);receipt=run(['nice','-n','10',cfg['candidate']['python'],str(r/'worker.py'),'candidate',case,str(out)],out,e,120);lines=[x for x in(out/'stderr').read_text().splitlines()if'MULTI_REDUCE_PREP'in x];(out/'route.json').write_text(json.dumps({'receipt':receipt,'lines':lines},indent=2));print(case,lines,flush=True)
