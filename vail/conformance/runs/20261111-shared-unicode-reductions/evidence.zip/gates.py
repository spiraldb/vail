from pathlib import Path
import json,subprocess,os,sys,time
r=Path(sys.argv[1]);ready=json.loads((r/'ready.json').read_text());e=os.environ.copy();e.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1');e.pop('PYTHONPATH',None)
tests=['test_shared_unicode_reductions.py','test_shared_list_reductions.py','test_shared_list_reducers.py','test_shared_matrix_annotations.py','test_list_invariants.py','test_demanded_list_bindings.py','test_array_flatmap.py','test_aggregate_execution.py','test_aggregate_nested_projection.py','test_collection_aggregate_kernels.py','test_indexed_maps.py']
cmd=['nice','-n','10',ready['python'],'-m','pytest','-q',*[f'python/tests/{x}'for x in tests]];start=time.monotonic()
with (r/'python-gates.log').open('w')as f:p=subprocess.run(cmd,cwd='/private/tmp/vail-multi-sink-20261111/vail',env=e,stdout=f,stderr=subprocess.STDOUT,timeout=600)
(r/'python-gates.json').write_text(json.dumps({'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'source':ready['source'],'native':ready['identity']},indent=2)+'\n');print('GATES',p.returncode,flush=True);sys.exit(p.returncode)
