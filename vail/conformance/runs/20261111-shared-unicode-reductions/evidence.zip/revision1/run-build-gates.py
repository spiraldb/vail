import subprocess,sys
from pathlib import Path
r=Path(__file__).parent;py='/private/tmp/vail-collect-state-20261110/final/env/bin/python'
for command in [[py,str(r/'rust.py'),str(r)],[py,str(r/'build.py')],[py,str(r.parent/'gates.py'),str(r)]]:
 subprocess.run(command,check=True)
