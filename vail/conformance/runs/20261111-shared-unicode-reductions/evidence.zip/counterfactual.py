from pathlib import Path
import json,os,sys
r=Path(__file__).parent;sys.path.insert(0,str(r));from owned import run
rev=r/'revision2';e=os.environ.copy()
for k,v in json.loads(Path('/private/tmp/vail-allocators-20261109/pinned-sdk/build-environment.json').read_text()).items():
 if v is None:e.pop(k,None)
 else:e[k]=v
out=rev/'baseline-allocation';cmd=['nice','-n','10','cargo','test','--release','--locked','--offline','-p','vail-execution','--test','shared_unicode_reductions','--','--nocapture','--test-threads=1']
try:run(cmd,out,e,600,cwd='/private/tmp/vail-unicode-baseline-20261111/vail')
except RuntimeError:pass
rec=json.loads((out/'exit.json').read_text());text=(out/'stdout').read_text()+(out/'stderr').read_text();assert rec['returncode']==101 and rec['group_absent'] and not rec['cleanup_error'] and not rec['failure'];assert 'payload-sized allocation grew'in text and '1 failed'in text;print('BASELINE RESOURCE COUNTERFACTUAL FAILS AS EXPECTED',flush=True)
# New public Python semantics must also work on the unchanged normal baseline.
cfg=json.loads((r/'config.json').read_text());e={k:v for k,v in os.environ.items()if k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
run(['nice','-n','10',cfg['baseline']['python'],'-m','pytest','-q','python/tests/test_shared_unicode_reductions.py'],rev/'baseline-python',e,120,cwd='/private/tmp/vail-multi-sink-20261111/vail');print('BASELINE PYTHON PASS',flush=True)
