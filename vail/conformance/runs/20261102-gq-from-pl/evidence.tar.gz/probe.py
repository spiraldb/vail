import json, sys, time
from pathlib import Path
import vail as hl
case = sys.argv[1]
if case.startswith('split'):
    path = Path('/private/tmp/vail-split-fundamental-20261030') / ('profile-first-200.mt' if case == 'split-real' else 'generated.mt')
    mt = hl.read_matrix_table(str(path))
    expected = 204 if case == 'split-real' else 2000
    def query(): return hl.split_multi_hts(mt)._force_count_rows()
else:
    n = 30000
    t = hl.range_table(n, n_partitions=4)
    if case == 'control':
        def query():
            q = t.annotate(y=(hl.int32(t.idx) + 1) * 2)
            return q.aggregate(hl.agg.sum(q.y))
        expected = n * (n + 1)
    else:
        width = 3 if case == 'gq-short' else 128
        t = t.annotate(pl=hl.range(width).map(lambda j: hl.or_missing(j % 4 != 3, (j * 17 + hl.int32(t.idx)) % 110)))
        def query():
            q = t.annotate(gq=hl.gq_from_pl(t.pl))
            return q.aggregate(hl.agg.sum(q.gq))
        def reference(i):
            ordered = sorted([99, 99] + [(j * 17 + i) % 110 for j in range(width) if j % 4 != 3])
            return ordered[1] - ordered[0]
        expected = sum(reference(i) for i in range(n))
start = time.perf_counter(); warm_count = 0
while time.perf_counter() - start < 1:
    assert query() == expected
    warm_count += 1
print(json.dumps({'warmup_queries': warm_count, 'warmup_wall': time.perf_counter() - start}), flush=True)
for rep in range(7):
    start = time.perf_counter(); cpu = time.process_time()
    operations = 1 if case.startswith('split') else 10
    values = [query() for _ in range(operations)]
    wall = time.perf_counter() - start; cpu = time.process_time() - cpu
    assert all(value == expected for value in values), (case, values, expected)
    print(json.dumps({'case': case, 'rep': rep, 'value': values[-1], 'operations': operations,
                      'wall': wall / operations, 'cpu': cpu / operations,
                      'batch_wall': wall, 'batch_cpu': cpu}), flush=True)
