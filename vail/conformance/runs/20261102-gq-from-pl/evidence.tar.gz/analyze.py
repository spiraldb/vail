from pathlib import Path
import json, statistics
r = Path(__file__).parent
summary = {}
for case in ['gq-short','gq-long','split-real','split-many','control']:
    processes=[]
    for run, version in enumerate([0,1,1,0]):
        lines=[json.loads(line) for line in (r/f'{case}-{run}-{version}.jsonl').read_text().splitlines()]
        samples=[line for line in lines if 'rep' in line]
        assert len(samples)==7
        processes.append({'run':run,'version':version,'wall':statistics.median(s['wall'] for s in samples),'cpu':statistics.median(s['cpu'] for s in samples)})
    medians={version:{metric:statistics.median(p[metric] for p in processes if p['version']==version) for metric in ['wall','cpu']} for version in [0,1]}
    ratios={metric:medians[1][metric]/medians[0][metric] for metric in ['wall','cpu']}
    pairs=[{metric:processes[c][metric]/processes[b][metric] for metric in ['wall','cpu']} for b,c in [(0,1),(3,2)]]
    summary[case]={'processes':processes,'medians':medians,'candidate_over_baseline':ratios,'paired_ratios':pairs}
    print(case, json.dumps(summary[case]))
(r/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
