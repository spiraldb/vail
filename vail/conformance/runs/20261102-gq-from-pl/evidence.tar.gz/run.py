from pathlib import Path
import os, subprocess
root = Path(__file__).parent
python = '/Users/danielking/projects/vail/vail/.venv/bin/python'
packages = [root / 'baseline-package', root / 'package']
for case in ['gq-short', 'gq-long', 'split-real', 'split-many', 'control']:
    for run, version in enumerate([0, 1, 1, 0]):
        env = {key: value for key, value in os.environ.items() if not key.startswith('VAIL_EXPERIMENT_')}
        env.update(PYTHONPATH=str(packages[version]), RAYON_NUM_THREADS='4', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
        with (root / f'{case}-{run}-{version}.jsonl').open('w') as output, (root / f'{case}-{run}-{version}.stderr').open('w') as errors:
            subprocess.run(['nice', '-n', '10', python, str(root / 'probe.py'), case], env=env, stdout=output, stderr=errors, check=True, timeout=90)
        print(case, run, version, 'PASS', flush=True)
