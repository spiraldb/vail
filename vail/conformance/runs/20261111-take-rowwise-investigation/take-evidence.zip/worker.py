from pathlib import Path
import hashlib,json,time,sys
import vail as hl,vail._native as native
r=Path(__file__).parent;p=json.loads((r/'pins.json').read_text());assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()==p['native_sha256'];source=p['fixtures']['gnomad']['root'];mode=sys.argv[1];calls=[]
def query():
 parts=[]
 def phase(name,fn):
  c=time.process_time();s=time.perf_counter();v=fn();parts.append({'phase':name,'wall':time.perf_counter()-s,'cpu':time.process_time()-c});return v
 mt=phase('read_legacy_construct',lambda:hl.MatrixTable.read_legacy(source));ht=phase('localize_construct',lambda:mt.localize_entries('e','c'));key=phase('key_expr_construct',lambda:hl.int(ht.row_idx/50));group=phase('group_by_construct',lambda:ht.group_by(k=key));value=phase('take_expr_construct',lambda:hl.agg.take(ht.row_value,1));result=phase('aggregate_construct',lambda:group.aggregate(value=value));n=phase('force_count',lambda:result._force_count());assert n==5000,n;calls.append(parts)
query();warm=time.time();start=time.monotonic();cpu=time.process_time()
if mode=='profile':
 while time.monotonic()-start<6:query()
elif mode=='trace':pass
else:
 for _ in range(3):query()
(r/(mode+'-result.json')).write_text(json.dumps({'mode':mode,'native_sha256':p['native_sha256'],'warm_epoch':warm,'end_epoch':time.time(),'loop_wall':time.monotonic()-start,'loop_cpu':time.process_time()-cpu,'calls':calls},indent=2)+'\n');print(json.dumps(calls,indent=2),flush=True)
