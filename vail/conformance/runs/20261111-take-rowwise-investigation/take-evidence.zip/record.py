from pathlib import Path
import json,os,sys
from owned import run
r=Path(__file__).parent;p=json.loads((r/'pins.json').read_text());e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc')
for mode in ['decompose','trace','profile']:
 env=dict(e)
 if mode=='trace':env['VAIL_TRACE_FORCE_COUNT_PLAN']='1'
 cmd=[p['vail_python'],str(r/'worker.py'),mode]
 if mode=='profile':cmd=['/opt/homebrew/bin/samply','record','--save-only','--duration','12','--rate','1000','--unstable-presymbolicate','--profile-name','Vail take rekey full Hail input','--output',str(r/'take-profile.json.gz')]+cmd
 receipt=run(['nice','-n','10']+cmd,r/mode,env,120);(r/(mode+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print('DONE',mode,flush=True)
