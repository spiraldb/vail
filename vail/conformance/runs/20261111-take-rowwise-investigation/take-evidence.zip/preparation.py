from pathlib import Path
import json,os
from owned import run
r=Path(__file__).parent;p=json.loads((r/'pins.json').read_text());e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(VAIL_TRACE_ACTION_PREPARATION='1',RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc');rec=run(['nice','-n','10',p['vail_python'],str(r/'worker.py'),'trace'],r/'preparation-trace',e,60);(r/'preparation-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print('DONE PREPARATION TRACE',flush=True)
