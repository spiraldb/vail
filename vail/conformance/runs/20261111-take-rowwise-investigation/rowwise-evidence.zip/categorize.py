from pathlib import Path
from collections import Counter,defaultdict
import runpy,contextlib,io,json
r=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):a=runpy.run_path(str(r/'analyze.py'))
d=a['d'];cut=a['cut'];end=a['end'];symbol=a['symbol'];categories=Counter();sub=Counter();examples={};inclusive=Counter();leaves=Counter();samples=Counter()
for t in d['threads']:
 s=t['samples'];st=t['stackTable'];cache={}
 for i,ts in enumerate(s['time']):
  if i==0 or s['time'][i-1]<cut or ts>end or ts<cut:continue
  w=s['threadCPUDelta'][i];idx=s['stack'][i]
  if w is None or w<=0 or idx is None:continue
  if idx not in cache:
   names=[];n=idx
   while n is not None:names.append(symbol(t,st['frame'][n]));n=st['prefix'][n]
   cache[idx]=names
  names=cache[idx];stack='\n'.join(names);leaf=names[0];secs=w/1e6;leaves[leaf]+=secs
  if any(x in leaf for x in ['__psynch_cvwait','__psynch_mutexwait','kevent','mach_msg','semaphore_wait','swtch_pri']):key='wait_or_scheduler_endpoint'
  elif 'NativeFile>::decode_range'in stack or 'PartReader>::read_columns'in stack or 'vail_storage::legacy::decode::'in stack:key='legacy_reader_decode_stack'
  elif 'Projector>::project_batch'in stack:key='projection_expression_stack'
  elif any(x in stack for x in ['vail_table::logical::','lower_physical','::Compiler>::','::prepare::']):key='planning_preparation_stack'
  else:key='other_engine_runtime'
  categories[key]+=secs;samples[key]+=1;examples.setdefault(key,names)
  if key=='projection_expression_stack':
   if 'columnar_numeric'in stack:child='fallible_integer_numeric_kernel'
   elif 'array_index_rows'in stack:child='list_index_gather'
   elif 'list_aggregate::direct::'in stack:child='segmented_boolean_reductions'
   elif 'packed_call::'in stack or 'vail_execution::calls::'in stack:child='call_expansion_and_access'
   elif 'try_numeric_cast'in stack:child='numeric_cast'
   elif 'arrow_ord::cmp::'in stack:child='comparison_kernels'
   elif 'arrow_arith::'in stack:child='other_arithmetic'
   elif any(x in leaf for x in ['mi_malloc','mi_free','madvise','_platform_memmove','NullBufferBuilder','OffsetBuffer']):child='other_allocation_copy_or_bitmap_leaf'
   else:child='other_expression'
   sub[child]+=secs;examples.setdefault(child,names)
  for pattern in ['array_index_rows','columnar_numeric','try_numeric_cast','LazyArrowCall','vail_execution::calls::access','list_aggregate::direct::','arrow_select::take::','arrow_ord::cmp::','arrow_arith::','ListAggregate','ArrayTransform','CallRows','normalize_float_zero','logical::']:
   if pattern in stack:inclusive[pattern]+=secs
fmt=lambda c:{k:{'cpu_seconds':v,'percent':100*v/a['total'],'per_call_seconds':v/a['worker']['repeated_calls']}for k,v in c.most_common()}
result={'total_cpu':a['total'],'calls':a['worker']['repeated_calls'],'categories_nonoverlapping':fmt(categories),'projection_subcategories_nonoverlapping':fmt(sub),'inclusive_overlapping':fmt(inclusive),'examples':examples,'scope':'Approximate threadCPUDelta attribution to endpoint stacks; wait endpoints separated, not active instruction percentages. Categories are exclusive by ordered rules, not summed inclusive fractions. Projection subcategories partition only projection stack category; overlapping inclusive table separate. No allocation-byte totals or causal gain forecast.'}
(r/'categories.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['examples']},indent=2))
