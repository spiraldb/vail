from pathlib import Path
from collections import defaultdict,Counter
import json
r=Path(__file__).parent;d=json.loads((r/'actual-ir-dag.json').read_text());nodes=d['nodes'];maps=[(k,x)for k,x in nodes.items()if x.get('op')=='array_map'];groups=defaultdict(list);allops=Counter(x.get('operator')for x in nodes.values()if x.get('op')in ['binary','integer_binary'])
def canon(x,env):
 if isinstance(x,dict)and set(x)=={'expr_ref'}:return canon(nodes[x['expr_ref']],env)
 if isinstance(x,dict):
  if x.get('op')=='lambda_variable':return {'op':'lambda_variable','name':env.get(x['name'],x['name'])}
  return {k:canon(v,env)for k,v in x.items()}
 if isinstance(x,list):return [canon(y,env)for y in x]
 return x
for mid,m in maps:
 env={m['parameter']:'@item'};owner=json.dumps(canon(m['value'],{}),sort_keys=True);seen=set()
 def walk(v):
  if isinstance(v,dict)and set(v)=={'expr_ref'}:
   nid=v['expr_ref']
   if nid in seen:return
   seen.add(nid);n=nodes[nid];op=n.get('op')
   if op=='array_index'or op in ['binary','integer_binary']and n.get('operator')in ['mod','div','floordiv','pow']:
    key=(owner,json.dumps(canon(n,env),sort_keys=True));groups[key].append({'map':mid,'node':nid,'op':op,'operator':n.get('operator')})
   for child in n.values():walk(child)
  elif isinstance(v,dict):
   for child in v.values():walk(child)
  elif isinstance(v,list):
   for child in v:walk(child)
 walk(m['body'])
summary=[]
for (owner,expression),uses in groups.items():
 summary.append({'count':len(uses),'expression':json.loads(expression),'owner_sha_input':owner,'uses':uses})
result={'binary_operator_counts':dict(allops),'groups':summary,'scope':'ActualconstructedIR from samebenchmark. Each group requires structurally identical mapowner and expression after only alpha-renaming its own mapparameter; no commute/fold/predicatealgebra assumed. Repeatednodes countedonce per mapbody. These are producer candidates, not proof every intermediate executes unchanged after lowereroptimizations.'};(r/'ir-duplicates.json').write_text(json.dumps(result,indent=2)+'\n')
print('Operators',dict(allops))
for x in summary:print('COUNT',x['count'],'EXPR',json.dumps(x['expression']))
