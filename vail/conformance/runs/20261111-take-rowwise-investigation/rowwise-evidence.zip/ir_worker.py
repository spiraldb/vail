from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json
import vail as hl,vail._native as native
from vail.expressions import NativeExpr
r=Path(__file__).parent;old=Path('/private/tmp/vail-six-slower-20261111');p=json.loads((old/'pins.json').read_text());assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()==p['native_sha256'];src=old/'benchmark_matrix_table.py';tree=ast.parse(src.read_text());helpers=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='many_aggs');helpers.decorator_list=[];fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='test_matrix_table_many_aggs_row_wise');fn.decorator_list=[];fn.body[-1]=ast.Return(value=fn.body[-1].value.func.value);m=ast.Module(body=[helpers,fn],type_ignores=[]);ast.fix_missing_locations(m);api=SimpleNamespace(**vars(hl));api.read_matrix_table=hl.MatrixTable.read_legacy;ns={'hl':api};exec(compile(m,str(src),'exec'),ns);table=ns[fn.name](p['fixtures']['profile']['root']);ir=table._native.ir();nodes={};owners={}
def convert(x):
 if isinstance(x,NativeExpr):
  identity=str(x.node_identity())
  if identity not in nodes:
   owners[identity]=x;nodes[identity]=None;nodes[identity]=convert(x.view())
  return {'expr_ref':identity}
 if isinstance(x,dict):return {str(k):convert(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [convert(v)for v in x]
 if x is None or isinstance(x,(str,int,float,bool)):return x
 if hasattr(x,'__arrow_c_stream__'):
  import pyarrow as pa
  t=pa.RecordBatchReader.from_stream(x).read_all()
  return {'arrow_literal':t.to_pylist(),'arrow_schema':str(t.schema)}
 return {'repr':repr(x)}
data={'table':convert(ir),'nodes':nodes,'native_sha256':p['native_sha256'],'scope':'IR-only originaltableconstruction; no query/physicalplan action'};(r/'actual-ir-dag.json').write_text(json.dumps(data,indent=2)+'\n');print('IR nodes',len(nodes),flush=True)
