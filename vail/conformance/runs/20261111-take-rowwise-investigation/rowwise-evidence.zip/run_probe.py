from pathlib import Path
import json,os,sys
from owned import run
r=Path(__file__).parent;pins=json.loads(Path('/private/tmp/vail-six-slower-20261111/pins.json').read_text());mode=sys.argv[1];e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc',RAYON_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
if mode=='trace':e['VAIL_TRACE_FORCE_COUNT_PLAN']='1'
args=['nice','-n','10',pins['vail_python'],str(r/'probe_worker.py'),mode]
if mode=='profile':args=['nice','-n','10','/opt/homebrew/bin/samply','record','--save-only','--duration','12','--rate','1000','--unstable-presymbolicate','--profile-name','Vail many row-wise aggregates full Hail input','--output',str(r/'rowwise-profile.json.gz'),pins['vail_python'],str(r/'probe_worker.py'),mode]
receipt=run(args,r/mode,e,120);(r/(mode+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print('COMPLETE',mode,flush=True)
