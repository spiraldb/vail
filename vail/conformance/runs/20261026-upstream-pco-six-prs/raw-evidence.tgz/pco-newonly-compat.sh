#!/usr/bin/env bash
set -eu
base=/home/danielking/vortex-pr-stack-20261026
cd "$base/source"
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH" CARGO_TARGET_DIR="$base/target" CARGO_BUILD_JOBS=8 CARGO_INCREMENTAL=0 RUSTFLAGS="-C target-cpu=native"
mkdir -p "$base/compat/newonly-new" "$base/compat/newonly-old"
build() {
 local label="$1"
 timeout 1200 cargo test -p vortex-file --test pco_file_compatibility --no-run --locked --message-format=json > "$base/results/$label-build.jsonl" 2> "$base/results/$label-build.log"
 python3 - "$base/results/$label-build.jsonl" > "$base/results/$label-executable.txt" <<'PY'
import json,sys
rows=[json.loads(s) for s in open(sys.argv[1])]
print(next(x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='pco_file_compatibility' and x.get('executable')))
PY
 sha256sum "$(cat "$base/results/$label-executable.txt")" > "$base/results/$label-executable.sha256"
 sha256sum encodings/pco/src/{array,lib}.rs vortex-file/tests/pco_file_compatibility.rs > "$base/results/$label-source.sha256"
}
tar -xzf "$base/pco-clean-pr3.tar.gz"
find encodings/pco/src -type f -exec touch {} +
build newonly-compat-new
PCO_COMPAT_MODE=write PCO_COMPAT_DIR="$base/compat/newonly-new" timeout 180 cargo test -p vortex-file --test pco_file_compatibility --locked -- --nocapture > "$base/results/newonly-compat-new-write.log" 2>&1
cp vortex-file/tests/pco_file_compatibility.rs "$base/compat/newonly-public-harness.rs"
tar -xzf "$base/pco-stack-base.tar.gz"
cp "$base/compat/newonly-public-harness.rs" vortex-file/tests/pco_file_compatibility.rs
find encodings/pco/src -type f -exec touch {} +
build newonly-compat-old
PCO_COMPAT_MODE=read PCO_COMPAT_DIR="$base/compat/newonly-new" timeout 180 cargo test -p vortex-file --test pco_file_compatibility --locked -- --nocapture > "$base/results/newonly-compat-old-read-new.log" 2>&1
PCO_COMPAT_MODE=write PCO_COMPAT_DIR="$base/compat/newonly-old" timeout 180 cargo test -p vortex-file --test pco_file_compatibility --locked -- --nocapture > "$base/results/newonly-compat-old-write.log" 2>&1
tar -xzf "$base/pco-clean-pr6.tar.gz"
find encodings/pco/src -type f -exec touch {} +
build newonly-compat-new-final
PCO_COMPAT_MODE=read PCO_COMPAT_DIR="$base/compat/newonly-old" timeout 180 cargo test -p vortex-file --test pco_file_compatibility --locked -- --nocapture > "$base/results/newonly-compat-new-read-old.log" 2>&1
sha256sum "$base/compat/newonly-new/"* "$base/compat/newonly-old/"* > "$base/results/newonly-compat-fixtures.sha256"
echo DONE
