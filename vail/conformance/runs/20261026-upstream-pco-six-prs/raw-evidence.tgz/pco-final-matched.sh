#!/usr/bin/env bash
set -eu
base=/home/danielking/vortex-pr-stack-20261026
cd "$base/source"
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH" CARGO_TARGET_DIR="$base/target" CARGO_BUILD_JOBS=8 CARGO_INCREMENTAL=0 RUSTFLAGS="-C target-cpu=native"
rustc -Vv > "$base/results/matched-toolchain.txt"
lscpu > "$base/results/matched-cpu.txt"
for stage in baseline pr3 pr4 pr5 pr6; do
 if [ "$stage" = baseline ]; then archive="$base/pco-final-baseline.tar.gz"; else archive="$base/pco-matched-$stage.tar.gz"; fi
 tar -xzf "$archive"
 find encodings/pco/src encodings/pco/benches -type f -exec touch {} +
 sha256sum "$archive" encodings/pco/src/{lib,array}.rs encodings/pco/benches/selection.rs > "$base/results/matched-$stage-source.sha256"
 timeout 1200 cargo bench -p vortex-pco --bench selection --no-run --locked --message-format=json > "$base/results/matched-$stage-build.jsonl" 2> "$base/results/matched-$stage-build.log"
 exe=$(python3 - "$base/results/matched-$stage-build.jsonl" <<'PY'
import json,sys
rows=[json.loads(s) for s in open(sys.argv[1])]
print(next(x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='selection' and x.get('executable')))
PY
 )
 printf '%s\n' "$exe" > "$base/results/matched-$stage-executable.txt"
 sha256sum "$exe" > "$base/results/matched-$stage-executable.sha256"
 if [ "$stage" = baseline ]; then
  timeout 180 "$exe" --test narrow_repeated --color never > "$base/results/narrow-final-oracles.log" 2>&1
  /usr/bin/time -v -o "$base/results/narrow-final-process.txt" timeout 180 "$exe" --bench narrow_repeated --timer os --sample-count 3 --sample-size 1 --min-time 0 --color never > "$base/results/narrow-final-os.log" 2>&1
  cat "$base/results/narrow-final-os.log"
 fi
 /usr/bin/time -v -o "$base/results/matched-$stage-oracle-process.txt" timeout 180 "$exe" --test --color never > "$base/results/matched-$stage-oracles.log" 2>&1
 /usr/bin/time -v -o "$base/results/matched-$stage-timed-process.txt" timeout 180 "$exe" --bench --timer os --sample-count 3 --sample-size 1 --min-time 0 --color never > "$base/results/matched-$stage-os.log" 2>&1
 printf 'COMPLETE %s\n' "$stage"
done
