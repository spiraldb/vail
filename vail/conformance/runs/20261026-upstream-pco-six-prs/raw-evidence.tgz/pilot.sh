#!/usr/bin/env bash
set -euo pipefail
cd /home/danielking/vortex-pr-stack-20261026
mapfile -t executables < <(find target/release/deps -maxdepth 1 -name 'selection-*' -type f -executable)
test "${#executables[@]}" -eq 1
executable="${executables[0]}"
git -C source rev-parse HEAD > results/pilot-source.txt
sha256sum "$executable" > results/pilot-executable.sha256
printf '%s\n' 'One untimed public-oracle pass, then three OS-timed samples per case, exactly one operation/sample. Fixtures and public oracles are outside measured closures. 256 metadata opens include result destruction; buffers/children ready, no IO/value decode. First probes256 fresh states/prepared owner; retained probes1048576 requests/prewarmed state. Fixed workloads across every implementation. Global timeout180sec.' > results/pilot-protocol.txt
"$executable" --test > results/pilot-untimed.log 2>&1
"$executable" --timer os --sample-count 3 --sample-size 1 --min-time 0 --color never > results/pilot-timed.log 2>&1
cat results/pilot-timed.log
