#!/usr/bin/env bash
set -eu
base=/home/danielking/vortex-pr-stack-20261026
cd "$base/source"
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH" CARGO_TARGET_DIR="$base/target" CARGO_BUILD_JOBS=8 CARGO_INCREMENTAL=0 RUSTFLAGS="-C target-cpu=native"
mkdir -p "$base/compat/presence-new" "$base/compat/presence-old"
build() {
 local label="$1"
 timeout 1200 cargo test -p vortex-file --test pco_logical_pages_compat --no-run --locked --message-format=json > "$base/results/$label-build.jsonl" 2> "$base/results/$label-build.log"
 python3 - "$base/results/$label-build.jsonl" > "$base/results/$label-executable.txt" <<'PY'
import json,sys
rows=[json.loads(s) for s in open(sys.argv[1])]
print(next(x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='pco_logical_pages_compat' and x.get('executable')))
PY
 sha256sum "$(cat "$base/results/$label-executable.txt")" > "$base/results/$label-executable.sha256"
 sha256sum encodings/pco/src/{array,lib}.rs vortex-file/tests/pco_logical_pages_compat.rs > "$base/results/$label-source.sha256"
}
tar -xzf "$base/pco-presence-pr3.tar.gz"
find encodings/pco/src -type f -exec touch {} +
build presence-compat-new
PCO_COMPAT_MODE=write PCO_COMPAT_DIR="$base/compat/presence-new" timeout 180 cargo test -p vortex-file --test pco_logical_pages_compat --locked -- --nocapture > "$base/results/presence-compat-new-write.log" 2>&1
cp vortex-file/tests/pco_logical_pages_compat.rs "$base/compat/presence-public-harness.rs"
tar -xzf "$base/pco-stack-base.tar.gz"
cp "$base/compat/presence-public-harness.rs" vortex-file/tests/pco_logical_pages_compat.rs
find encodings/pco/src -type f -exec touch {} +
build presence-compat-old
PCO_COMPAT_MODE=read PCO_COMPAT_DIR="$base/compat/presence-new" timeout 180 cargo test -p vortex-file --test pco_logical_pages_compat --locked -- --nocapture > "$base/results/presence-compat-old-read-new.log" 2>&1
PCO_COMPAT_MODE=write PCO_COMPAT_DIR="$base/compat/presence-old" timeout 180 cargo test -p vortex-file --test pco_logical_pages_compat --locked -- --nocapture > "$base/results/presence-compat-old-write.log" 2>&1
tar -xzf "$base/pco-presence-pr3.tar.gz"
find encodings/pco/src -type f -exec touch {} +
build presence-compat-new-final
PCO_COMPAT_MODE=read PCO_COMPAT_DIR="$base/compat/presence-old" timeout 180 cargo test -p vortex-file --test pco_logical_pages_compat --locked -- --nocapture > "$base/results/presence-compat-new-read-old.log" 2>&1
sha256sum "$base/compat/presence-new/"* "$base/compat/presence-old/"* > "$base/results/presence-compat-fixtures.sha256"
echo DONE
