Wall timings exclude accounting and post-timing scalar inspection.
open-only/open-first include public array-plugin metadata decode/validation/index preparation with compressed buffers and validity children already available; no file IO.
probe-first starts with prepared metadata/index; probe retains touched pages across iterations.
CPU ticks are OS process user+system ticks; sub-tick readings are resolution-limited, not zero CPU.
RSS snapshots may miss transient peaks. GNU time maximum RSS is whole-process peak including fixtures/compression and post-timing inspection, not operation-only peak.
