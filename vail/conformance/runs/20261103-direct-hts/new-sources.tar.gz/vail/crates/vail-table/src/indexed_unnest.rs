//! Fuse an entry update with a narrow, single-list row expansion.
//! Only parent indices cross expansion; the original entry owner stays local
//! to this input batch until the final aligned update has produced its output.
use crate::plan::PhysicalPlan;
use arrow_array::{Array, ArrayRef, BooleanArray, Int32Array, ListArray, RecordBatch};
use arrow_schema::{DataType, Field, Schema, SchemaRef};
use arrow_select::{filter::filter_record_batch, take::take};
use datafusion_common::{DataFusionError, NullHandling, Result, ScalarValue};
use datafusion_execution::TaskContext;
use datafusion_expr::ColumnarValue;
use datafusion_physical_expr::{
    PhysicalExpr, ScalarFunctionExpr,
    expressions::{BinaryExpr, Column, IsNotNullExpr, IsNullExpr, Literal},
    scalar_subquery::ScalarSubqueryExpr,
};
use datafusion_physical_plan::{
    DisplayAs, DisplayFormatType, ExecutionPlan, PlanProperties, SendableRecordBatchStream,
    filter::FilterExec, projection::ProjectionExec, stream::RecordBatchStreamAdapter,
    unnest::UnnestExec,
};
use futures::TryStreamExt;
use std::{collections::HashMap, fmt, sync::Arc};
use vail_execution::logical_expr::{AlignedSelection, SelectedAlignedProgram};

#[derive(Debug, Clone)]
enum Step {
    Project {
        expressions: Vec<Arc<dyn PhysicalExpr>>,
        marker_in: usize,
        marker_out: usize,
        schema: SchemaRef,
    },
    Filter {
        predicate: Arc<dyn PhysicalExpr>,
        projection: Option<Vec<usize>>,
        schema: SchemaRef,
    },
}
#[derive(Debug)]
struct Program {
    source_schema: SchemaRef,
    output_schema: SchemaRef,
    restored_schema: SchemaRef,
    unnest_schema: SchemaRef,
    source_entry: usize,
    source_list: usize,
    marker: usize,
    steps: Vec<Step>,
    arguments: Vec<Arc<dyn PhysicalExpr>>,
    selected: SelectedAlignedProgram,
    output: Vec<Arc<dyn PhysicalExpr>>,
    input_marker_schema: SchemaRef,
    raw_entry: usize,
    before: Vec<Step>,
    producer: Option<Arc<dyn PhysicalExpr>>,
}

fn marker_schema(schema: &SchemaRef, marker: usize, dtype: DataType, nullable: bool) -> SchemaRef {
    let mut fields = schema.fields().to_vec();
    fields[marker] = Arc::new(Field::new(fields[marker].name(), dtype, nullable));
    Arc::new(Schema::new_with_metadata(fields, schema.metadata().clone()))
}
type Dependencies = HashMap<(usize, usize, usize), bool>;
fn depends(
    expression: &Arc<dyn PhysicalExpr>,
    index: usize,
    target: Option<&Arc<dyn PhysicalExpr>>,
    memo: &mut Dependencies,
) -> bool {
    let address = Arc::as_ptr(expression) as *const () as usize;
    let ignored = target.map_or(0, |target| Arc::as_ptr(target) as *const () as usize);
    let key = (address, index, ignored);
    if let Some(answer) = memo.get(&key) {
        return *answer;
    }
    let answer = if target.is_some_and(|target| Arc::ptr_eq(expression, target)) {
        false
    } else if let Some(column) = expression.downcast_ref::<Column>() {
        column.index() == index
    } else {
        expression
            .children()
            .iter()
            .any(|child| depends(child, index, target, memo))
    };
    memo.insert(key, answer);
    answer
}
type MetadataMemo = HashMap<(usize, usize, usize), bool>;
fn total_metadata(
    expression: &Arc<dyn PhysicalExpr>,
    schema: &Schema,
    target: Option<&Arc<dyn PhysicalExpr>>,
    memo: &mut MetadataMemo,
) -> bool {
    let key = (
        Arc::as_ptr(expression) as *const () as usize,
        schema as *const Schema as usize,
        target.map_or(0, |target| Arc::as_ptr(target) as *const () as usize),
    );
    if let Some(answer) = memo.get(&key) {
        return *answer;
    }
    let result = total_metadata_node(expression, schema, target, memo);
    memo.insert(key, result);
    result
}
fn total_metadata_node(
    expression: &Arc<dyn PhysicalExpr>,
    schema: &Schema,
    target: Option<&Arc<dyn PhysicalExpr>>,
    memo: &mut MetadataMemo,
) -> bool {
    if target.is_some_and(|target| Arc::ptr_eq(expression, target)) {
        return true;
    }
    let expression = crate::projection_broadcast::count_inner(expression);
    if target.is_some_and(|target| Arc::ptr_eq(&expression, target)) {
        return true;
    }
    // ScalarSubqueryExec produces these query-scoped values before its child
    // executes. The deferred expression remains visible to dependency visitors.
    if expression.is::<ScalarSubqueryExpr>() {
        return true;
    }
    if let Some(function) = expression.downcast_ref::<ScalarFunctionExpr>() {
        let typed = vail_execution::logical_expr::semantic_kernel(function.fun())
            .is_some_and(|(expr, _)| expr.is_pure());
        let named = function
            .fun()
            .inner()
            .is::<datafusion_functions::core::named_struct::NamedStructFunc>()
            && function.args().len() % 2 == 0
            && function.args().iter().step_by(2).all(|name| {
                name.downcast_ref::<Literal>()
                    .is_some_and(|value| matches!(value.value(), ScalarValue::Utf8(Some(_))))
            });
        let length = vail_execution::array_length::is_outer_length(function.fun())
            && function
                .args()
                .first()
                .is_some_and(|arg| matches!(arg.data_type(schema), Ok(DataType::List(_))));
        if !typed && !named && !length {
            return false;
        }
    } else if let Some(binary) = expression.downcast_ref::<BinaryExpr>() {
        use datafusion_expr::Operator;
        if !matches!(
            binary.op(),
            Operator::Eq
                | Operator::NotEq
                | Operator::Lt
                | Operator::LtEq
                | Operator::Gt
                | Operator::GtEq
                | Operator::And
                | Operator::Or
        ) {
            return false;
        }
    } else if !expression.is::<Column>()
        && !expression.is::<Literal>()
        && !expression.is::<IsNullExpr>()
        && !expression.is::<IsNotNullExpr>()
    {
        return false;
    }
    expression
        .children()
        .iter()
        .all(|child| total_metadata(child, schema, target, memo))
}
fn replace(
    expression: &Arc<dyn PhysicalExpr>,
    target: &Arc<dyn PhysicalExpr>,
    value: &Arc<dyn PhysicalExpr>,
    memo: &mut HashMap<usize, Arc<dyn PhysicalExpr>>,
) -> Result<Arc<dyn PhysicalExpr>> {
    let address = Arc::as_ptr(expression) as *const () as usize;
    if let Some(answer) = memo.get(&address) {
        return Ok(answer.clone());
    }
    let answer = if Arc::ptr_eq(expression, target) {
        value.clone()
    } else {
        let children = expression
            .children()
            .into_iter()
            .map(|child| replace(child, target, value, memo))
            .collect::<Result<Vec<_>>>()?;
        if children
            .iter()
            .zip(expression.children())
            .all(|(a, b)| Arc::ptr_eq(a, b))
        {
            expression.clone()
        } else {
            expression.clone().with_new_children(children)?
        }
    };
    memo.insert(address, answer.clone());
    Ok(answer)
}

// Projections preserve the original row domain. The marker therefore remains
// an ordinal into the same raw input batch, even after metadata filters.
fn deferred_input(
    mut input: PhysicalPlan,
    mut marker: usize,
) -> Result<Option<(PhysicalPlan, usize, Vec<Step>, Arc<dyn PhysicalExpr>)>> {
    let mut before = Vec::new();
    let mut dependencies = Dependencies::new();
    let mut metadata = MetadataMemo::new();
    while let Some(project) = input.downcast_ref::<ProjectionExec>() {
        let Some(entry) = project.expr().get(marker) else {
            return Ok(None);
        };
        let expression = crate::projection_broadcast::count_inner(&entry.expr);
        let mut producer = false;
        let incoming = if let Some(column) = expression.downcast_ref::<Column>() {
            column.index()
        } else {
            let Some(function) = expression.downcast_ref::<ScalarFunctionExpr>() else {
                return Ok(None);
            };
            let aligned = if vail_execution::logical_expr::deferrable_aligned_entry_argument(
                function.fun(),
            )
            .is_some()
            {
                expression.clone()
            } else {
                let Some((native, schema)) =
                    vail_execution::logical_expr::semantic_kernel(function.fun())
                else {
                    return Ok(None);
                };
                if !native.is_pure() || function.args().len() != 1 || schema.fields().len() != 1 {
                    return Ok(None);
                }
                let vail_execution::expressions::Expr::ArrayMap { value, .. } = native else {
                    return Ok(None);
                };
                if !matches!(value.as_ref(), vail_execution::expressions::Expr::Column { name } if schema.index_of(name).ok()==Some(0))
                {
                    return Ok(None);
                }
                crate::projection_broadcast::count_inner(&function.args()[0])
            };
            let Some(function) = aligned.downcast_ref::<ScalarFunctionExpr>() else {
                return Ok(None);
            };
            let Some(argument) =
                vail_execution::logical_expr::deferrable_aligned_entry_argument(function.fun())
            else {
                return Ok(None);
            };
            let Some(argument_expr) = function.args().get(argument) else {
                return Ok(None);
            };
            let argument_expr = crate::projection_broadcast::count_inner(argument_expr);
            let Some(column) = argument_expr.downcast_ref::<Column>() else {
                return Ok(None);
            };
            let index = column.index();
            if function.args().iter().enumerate().any(|(i, e)| {
                i != argument
                    && (depends(e, index, None, &mut dependencies)
                        || !total_metadata(
                            e,
                            project.input().schema().as_ref(),
                            None,
                            &mut metadata,
                        ))
            }) {
                return Ok(None);
            }
            producer = true;
            index
        };
        if project.expr().iter().enumerate().any(|(i, e)| {
            i != marker
                && (depends(&e.expr, incoming, None, &mut dependencies)
                    || !total_metadata(
                        &e.expr,
                        project.input().schema().as_ref(),
                        None,
                        &mut metadata,
                    ))
        }) {
            return Ok(None);
        }
        before.push(Step::Project {
            expressions: project.expr().iter().map(|e| e.expr.clone()).collect(),
            marker_in: incoming,
            marker_out: marker,
            schema: marker_schema(&project.schema(), marker, DataType::Int32, false),
        });
        if producer {
            let entry = entry.expr.clone();
            let raw = project.input().clone();
            if !matches!(raw.schema().field(incoming).data_type(), DataType::List(_)) {
                return Ok(None);
            }
            before.reverse();
            return Ok(Some((raw, incoming, before, entry)));
        }
        marker = incoming;
        input = project.input().clone();
    }
    Ok(None)
}

type UnnestTails = HashMap<usize, (PhysicalPlan, bool)>;
fn has_unnest_tail(plan: &PhysicalPlan, memo: &mut UnnestTails) -> bool {
    let key = Arc::as_ptr(plan) as *const () as usize;
    if let Some((_, answer)) = memo.get(&key) {
        return *answer;
    }
    let answer = if plan.is::<UnnestExec>() {
        true
    } else if let Some(project) = plan.downcast_ref::<ProjectionExec>() {
        has_unnest_tail(project.input(), memo)
    } else if let Some(filter) = plan.downcast_ref::<FilterExec>() {
        has_unnest_tail(filter.input(), memo)
    } else {
        false
    };
    memo.insert(key, (plan.clone(), answer));
    answer
}
fn candidate(
    projection: &ProjectionExec,
    tails: &mut UnnestTails,
    defer: bool,
) -> Result<Option<(PhysicalPlan, Program)>> {
    // Reject unrelated maps before preparing a selected entry evaluator.
    if !has_unnest_tail(projection.input(), tails) {
        return Ok(None);
    }
    let mut found = None;
    let mut dependencies = Dependencies::new();
    let mut metadata = MetadataMemo::new();
    for entry in projection.expr() {
        let target = crate::projection_broadcast::count_inner(&entry.expr);
        let Some(outer) = target.downcast_ref::<ScalarFunctionExpr>() else {
            continue;
        };
        if outer.args().len() != 1 {
            continue;
        }
        let inner = crate::projection_broadcast::count_inner(&outer.args()[0]);
        let Some(inner) = inner.downcast_ref::<ScalarFunctionExpr>() else {
            continue;
        };
        let Some(selected) =
            vail_execution::logical_expr::selected_entry_projection(inner.fun(), outer.fun())
        else {
            continue;
        };
        let Some(argument) = inner.args().get(selected.entry_argument) else {
            continue;
        };
        let argument = crate::projection_broadcast::count_inner(argument);
        let Some(column) = argument.downcast_ref::<Column>() else {
            continue;
        };
        let marker = column.index();
        if inner.args().iter().enumerate().any(|(i, arg)| {
            i != selected.entry_argument && depends(arg, marker, None, &mut dependencies)
        }) {
            continue;
        }
        if found.is_some() {
            return Ok(None);
        }
        found = Some((target.clone(), selected, inner.args().to_vec(), marker));
    }
    let Some((target, selected, arguments, final_marker)) = found else {
        return Ok(None);
    };
    if projection.expr().iter().any(|entry| {
        depends(&entry.expr, final_marker, Some(&target), &mut dependencies)
            || !total_metadata(
                &entry.expr,
                projection.input().schema().as_ref(),
                Some(&target),
                &mut metadata,
            )
    }) {
        return Ok(None);
    }
    let mut current = projection.input().clone();
    let mut marker = final_marker;
    let mut steps = vec![];
    loop {
        if let Some(project) = current.downcast_ref::<ProjectionExec>() {
            let Some(forward) = project.expr().get(marker) else {
                return Ok(None);
            };
            let forward = crate::projection_broadcast::count_inner(&forward.expr);
            let Some(column) = forward.downcast_ref::<Column>() else {
                return Ok(None);
            };
            let marker_in = column.index();
            if project.expr().iter().enumerate().any(|(i, e)| {
                i != marker
                    && (depends(&e.expr, marker_in, None, &mut dependencies)
                        || !total_metadata(
                            &e.expr,
                            project.input().schema().as_ref(),
                            None,
                            &mut metadata,
                        ))
            }) {
                return Ok(None);
            }
            steps.push(Step::Project {
                expressions: project.expr().iter().map(|e| e.expr.clone()).collect(),
                marker_in,
                marker_out: marker,
                schema: marker_schema(&project.schema(), marker, DataType::Int32, false),
            });
            marker = marker_in;
            current = project.input().clone();
        } else if let Some(filter) = current.downcast_ref::<FilterExec>() {
            if filter.fetch().is_some() {
                return Ok(None);
            }
            let projection = filter
                .projection()
                .as_ref()
                .map(|indices| indices.as_ref().to_vec());
            let marker_in = projection
                .as_ref()
                .map_or(Some(marker), |indices: &Vec<usize>| {
                    indices.get(marker).copied()
                });
            let Some(marker_in) = marker_in else {
                return Ok(None);
            };
            if depends(filter.predicate(), marker_in, None, &mut dependencies)
                || !total_metadata(
                    filter.predicate(),
                    filter.input().schema().as_ref(),
                    None,
                    &mut metadata,
                )
            {
                return Ok(None);
            }
            if projection
                .as_ref()
                .is_some_and(|p| p.iter().filter(|&&index| index == marker_in).count() != 1)
            {
                return Ok(None);
            }
            steps.push(Step::Filter {
                predicate: filter.predicate().clone(),
                projection,
                schema: marker_schema(&filter.schema(), marker, DataType::Int32, false),
            });
            marker = marker_in;
            current = filter.input().clone();
        } else {
            break;
        }
    }
    let Some(unnest) = current.downcast_ref::<UnnestExec>() else {
        return Ok(None);
    };
    let [list] = unnest.list_column_indices() else {
        return Ok(None);
    };
    if list.depth != 1
        || !unnest.struct_column_indices().is_empty()
        || unnest.options().null_handling != NullHandling::Drop
        || unnest.options().recursions.iter().any(|r| r.depth != 1)
        || marker == list.index_in_input_schema
        || unnest.schema().fields().len() != unnest.input().schema().fields().len()
        || unnest.input().schema().field(marker).data_type() != selected.entry_type()
        || !matches!(
            unnest
                .input()
                .schema()
                .field(list.index_in_input_schema)
                .data_type(),
            DataType::List(_)
        )
    {
        return Ok(None);
    }
    steps.reverse();
    let replacement: Arc<dyn PhysicalExpr> = Arc::new(Column::new(
        projection.input().schema().field(final_marker).name(),
        final_marker,
    ));
    let mut replacements = HashMap::new();
    let output = projection
        .expr()
        .iter()
        .map(|entry| replace(&entry.expr, &target, &replacement, &mut replacements))
        .collect::<Result<Vec<_>>>()?;
    let (input, raw_entry, before, producer) = if defer {
        match deferred_input(unnest.input().clone(), marker)? {
            Some((input, entry, before, producer)) => (input, entry, before, Some(producer)),
            None => (unnest.input().clone(), marker, vec![], None),
        }
    } else {
        (unnest.input().clone(), marker, vec![], None)
    };
    let input_marker_schema = marker_schema(&input.schema(), raw_entry, DataType::Int32, false);
    Ok(Some((
        input.clone(),
        Program {
            source_schema: input.schema(),
            input_marker_schema,
            raw_entry,
            before,
            producer,
            output_schema: projection.schema(),
            restored_schema: marker_schema(
                &projection.input().schema(),
                final_marker,
                selected.output_type().clone(),
                true,
            ),
            unnest_schema: marker_schema(&unnest.schema(), marker, DataType::Int32, false),
            source_entry: marker,
            source_list: list.index_in_input_schema,
            marker: final_marker,
            steps,
            arguments,
            selected,
            output,
        },
    )))
}

impl Program {
    fn chunk(
        &self,
        input: &RecordBatch,
        parents: Vec<i32>,
        items: Vec<i32>,
    ) -> Result<Option<RecordBatch>> {
        let parents = Int32Array::from(parents);
        let items = Int32Array::from(items);
        let list = input
            .column(self.source_list)
            .as_any()
            .downcast_ref::<ListArray>()
            .unwrap();
        let columns = input
            .columns()
            .iter()
            .enumerate()
            .map(|(index, array)| {
                if index == self.source_list {
                    Ok(take(list.values().as_ref(), &items, None)?)
                } else {
                    Ok(take(array.as_ref(), &parents, None)?)
                }
            })
            .collect::<Result<Vec<_>>>()?;
        let mut batch = RecordBatch::try_new(self.unnest_schema.clone(), columns)?;
        batch = self.apply_steps(batch, &self.steps)?;
        if batch.num_rows() == 0 {
            return Ok(None);
        }
        Ok(Some(batch))
    }
    fn apply_steps(&self, mut batch: RecordBatch, steps: &[Step]) -> Result<RecordBatch> {
        for step in steps {
            if batch.num_rows() == 0 {
                return Ok(batch);
            }
            batch = match step {
                Step::Project {
                    expressions,
                    marker_in,
                    marker_out,
                    schema,
                } => {
                    let columns = expressions
                        .iter()
                        .enumerate()
                        .map(|(i, expression)| {
                            if i == *marker_out {
                                Ok(batch.column(*marker_in).clone())
                            } else {
                                expression.evaluate(&batch)?.into_array(batch.num_rows())
                            }
                        })
                        .collect::<Result<Vec<_>>>()?;
                    RecordBatch::try_new(schema.clone(), columns)?
                }
                Step::Filter {
                    predicate,
                    projection,
                    schema,
                } => {
                    let predicate = predicate.evaluate(&batch)?.into_array(batch.num_rows())?;
                    let predicate = predicate
                        .as_any()
                        .downcast_ref::<BooleanArray>()
                        .ok_or_else(|| {
                            DataFusionError::Execution("fused filter is not boolean".into())
                        })?;
                    let filtered = filter_record_batch(&batch, predicate)?;
                    let filtered = match projection {
                        Some(indices) => filtered.project(indices)?,
                        None => filtered,
                    };
                    RecordBatch::try_new(schema.clone(), filtered.columns().to_vec())?
                }
            };
        }
        Ok(batch)
    }
    fn metadata_input(&self, input: &RecordBatch) -> Result<RecordBatch> {
        let count = i32::try_from(input.num_rows())
            .map_err(|_| DataFusionError::Execution("raw row count exceeds int32".into()))?;
        let mut columns = input.columns().to_vec();
        columns[self.raw_entry] = Arc::new(Int32Array::from_iter_values(0..count));
        self.apply_steps(
            RecordBatch::try_new(self.input_marker_schema.clone(), columns)?,
            &self.before,
        )
    }
    fn finish(&self, batch: RecordBatch, owner: ArrayRef, trace: bool) -> Result<RecordBatch> {
        let parents = batch
            .column(self.marker)
            .as_any()
            .downcast_ref::<Int32Array>()
            .ok_or_else(|| DataFusionError::Internal("fused entry parent marker changed".into()))?
            .clone();
        let arguments = self
            .arguments
            .iter()
            .enumerate()
            .map(|(i, argument)| {
                if i == self.selected.entry_argument {
                    Ok(ColumnarValue::Scalar(ScalarValue::Null))
                } else {
                    argument.evaluate(&batch)
                }
            })
            .collect::<Result<Vec<_>>>()?;
        let mapped = self
            .selected
            .invoke(
                &arguments,
                AlignedSelection {
                    entries: owner,
                    parents,
                },
            )?
            .into_array(batch.num_rows())?;
        if trace {
            let output = mapped.as_any().downcast_ref::<ListArray>().unwrap();
            eprintln!(
                "VAIL_FUSED_UNNEST_BODY rows={} lanes={}",
                batch.num_rows(),
                output.values().len()
            );
        }
        let mut columns = batch.columns().to_vec();
        columns[self.marker] = mapped;
        let batch = RecordBatch::try_new(self.restored_schema.clone(), columns)?;
        let columns = self
            .output
            .iter()
            .map(|expression| expression.evaluate(&batch)?.into_array(batch.num_rows()))
            .collect::<Result<Vec<_>>>()?;
        Ok(RecordBatch::try_new(self.output_schema.clone(), columns)?)
    }
}
#[derive(Debug)]
struct IndexedUnnestExec {
    input: PhysicalPlan,
    template: PhysicalPlan,
    program: Arc<Program>,
    cache: Arc<PlanProperties>,
}
impl DisplayAs for IndexedUnnestExec {
    fn fmt_as(&self, _: DisplayFormatType, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "IndexedUnnestEntriesExec")
    }
}
impl ExecutionPlan for IndexedUnnestExec {
    fn name(&self) -> &'static str {
        "IndexedUnnestEntriesExec"
    }
    fn properties(&self) -> &Arc<PlanProperties> {
        &self.cache
    }
    fn children(&self) -> Vec<&PhysicalPlan> {
        vec![&self.input]
    }
    fn with_new_children(self: Arc<Self>, children: Vec<PhysicalPlan>) -> Result<PhysicalPlan> {
        if children.len() != 1 || children[0].schema() != self.program.source_schema {
            return Err(DataFusionError::Plan(
                "indexed expansion source schema changed".into(),
            ));
        }
        fn rebuild(
            plan: &PhysicalPlan,
            source: &PhysicalPlan,
            replacement: &PhysicalPlan,
            memo: &mut HashMap<usize, PhysicalPlan>,
        ) -> Result<PhysicalPlan> {
            if Arc::ptr_eq(plan, source) {
                return Ok(replacement.clone());
            }
            let key = Arc::as_ptr(plan) as *const () as usize;
            if let Some(answer) = memo.get(&key) {
                return Ok(answer.clone());
            }
            let children = plan
                .children()
                .iter()
                .map(|child| rebuild(child, source, replacement, memo))
                .collect::<Result<Vec<_>>>()?;
            let result = plan.clone().with_new_children(children)?;
            memo.insert(key, result.clone());
            Ok(result)
        }
        let template = rebuild(
            &self.template,
            &self.input,
            &children[0],
            &mut HashMap::new(),
        )?;
        let cache = template.properties().clone();
        Ok(Arc::new(Self {
            input: children[0].clone(),
            template,
            program: self.program.clone(),
            cache,
        }))
    }
    fn apply_expressions(
        &self,
        visitor: &mut dyn FnMut(
            &Arc<dyn PhysicalExpr>,
        ) -> Result<datafusion_common::tree_node::TreeNodeRecursion>,
    ) -> Result<datafusion_common::tree_node::TreeNodeRecursion> {
        let mut expressions = self
            .program
            .arguments
            .iter()
            .enumerate()
            .filter(|(i, _)| *i != self.program.selected.entry_argument)
            .map(|(_, expr)| expr)
            .collect::<Vec<_>>();
        if let Some(producer) = &self.program.producer {
            expressions.push(producer);
        }
        for step in self.program.before.iter().chain(&self.program.steps) {
            match step {
                Step::Project {
                    expressions: values,
                    marker_out,
                    ..
                } => expressions.extend(
                    values
                        .iter()
                        .enumerate()
                        .filter(|(i, _)| i != marker_out)
                        .map(|(_, value)| value),
                ),
                Step::Filter { predicate, .. } => expressions.push(predicate),
            }
        }
        expressions.extend(self.program.output.iter());
        datafusion_physical_plan::apply_expression_roots(expressions, visitor)
    }
    fn execute(
        &self,
        partition: usize,
        context: Arc<TaskContext>,
    ) -> Result<SendableRecordBatchStream> {
        let mut input = self.input.execute(partition, context.clone())?;
        let program = self.program.clone();
        let schema = program.output_schema.clone();
        let batch_size = context.session_config().batch_size().max(1);
        // Flat entry lanes are a different domain from outer DataFusion rows.
        let entry_batch_size = std::env::var("VAIL_EXPERIMENT_ENTRY_BATCH_SIZE")
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .filter(|value| *value > 0)
            .unwrap_or(262_144);
        let trace = std::env::var_os("VAIL_TRACE_FUSED_UNNEST").is_some();
        if trace {
            eprintln!("VAIL_FUSED_UNNEST_EXEC partition={partition}");
        }
        Ok(Box::pin(RecordBatchStreamAdapter::new(
            schema,
            async_stream::try_stream! {
                while let Some(batch) = input.try_next().await? {
                    if batch.schema() != program.source_schema { Err(DataFusionError::Execution("indexed expansion input schema changed".into()))?; }
                    let entries = batch.column(program.raw_entry).as_any().downcast_ref::<ListArray>().unwrap();
                    let lengths = (0..entries.len()).map(|row| if entries.is_null(row) { 0 } else { entries.value_length(row) as usize }).collect::<Vec<_>>();
                    if trace { eprintln!("VAIL_FUSED_UNNEST_OWNER rows={} entries={} bytes={} deferred={}",batch.num_rows(),entries.values().len(),entries.get_buffer_memory_size(),program.producer.is_some()); }
                    let metadata = program.metadata_input(&batch)?;
                    let lists = metadata.column(program.source_list).as_any().downcast_ref::<ListArray>().unwrap();
                    let raw_parents = metadata.column(program.source_entry).as_any().downcast_ref::<Int32Array>().unwrap();
                    let mut owner = if program.producer.is_none() { Some(batch.column(program.raw_entry).clone()) } else { None };
                    let mut pending = Some(batch);
                    let mut parents = Vec::new(); let mut items = Vec::new(); let mut lanes = 0usize;
                    for row in 0..=metadata.num_rows() {
                        let range = if row==metadata.num_rows() { 0..1 } else if lists.is_null(row) { 0..0 } else { lists.value_offsets()[row]..lists.value_offsets()[row+1] };
                        for item in range {
                            let end = row==metadata.num_rows();
                            let entry_count = if end { 0 } else { lengths[raw_parents.value(row) as usize] };
                            if !parents.is_empty() && (end || parents.len() >= batch_size || lanes.saturating_add(entry_count) > entry_batch_size) {
                                if let Some(selected) = program.chunk(&metadata,std::mem::take(&mut parents),std::mem::take(&mut items))? {
                                    if owner.is_none() {
                                        let raw = pending.take().unwrap();
                                        let prepared = program.producer.as_ref().unwrap().evaluate(&raw)?.into_array(raw.num_rows())?;
                                        if prepared.len()!=raw.num_rows() || prepared.data_type()!=program.selected.entry_type() { Err(DataFusionError::Execution("deferred entry shape or descriptor differs".into()))?; }
                                        if trace { eprintln!("VAIL_FUSED_PRODUCER_EVAL rows={}",raw.num_rows()); }
                                        owner = Some(prepared);
                                    }
                                    yield program.finish(selected,owner.as_ref().unwrap().clone(),trace)?;
                                }
                                lanes = 0;
                            }
                            if !end {
                                parents.push(i32::try_from(row).map_err(|_| DataFusionError::Execution("expanded parent exceeds int32".into()))?); items.push(item);
                                lanes = lanes.checked_add(entry_count).ok_or_else(|| DataFusionError::Execution("expanded lane count overflow".into()))?;
                            }
                        }
                    }
                }
            },
        )))
    }
}

pub(crate) fn optimize(plan: PhysicalPlan) -> Result<PhysicalPlan> {
    if std::env::var_os("VAIL_EXPERIMENT_FUSED_UNNEST").is_none() {
        return Ok(plan);
    }
    let defer = std::env::var_os("VAIL_EXPERIMENT_FUSED_PRODUCER").is_some();
    fn visit(
        plan: PhysicalPlan,
        memo: &mut HashMap<usize, (PhysicalPlan, PhysicalPlan)>,
        tails: &mut UnnestTails,
        defer: bool,
    ) -> Result<PhysicalPlan> {
        let key = Arc::as_ptr(&plan) as *const () as usize;
        if let Some((_, result)) = memo.get(&key) {
            return Ok(result.clone());
        }
        let mut changed = false;
        let children = plan
            .children()
            .into_iter()
            .map(|child| {
                let replacement = visit(child.clone(), memo, tails, defer)?;
                changed |= !Arc::ptr_eq(child, &replacement);
                Ok(replacement)
            })
            .collect::<Result<Vec<_>>>()?;
        let current = if changed {
            plan.clone().with_new_children(children)?
        } else {
            plan.clone()
        };
        let result: PhysicalPlan =
            if let Some(projection) = current.downcast_ref::<ProjectionExec>() {
                if let Some((input, program)) = candidate(projection, tails, defer)? {
                    Arc::new(IndexedUnnestExec {
                        input,
                        template: current.clone(),
                        program: Arc::new(program),
                        cache: current.properties().clone(),
                    })
                } else {
                    current
                }
            } else {
                current
            };
        memo.insert(key, (plan, result.clone()));
        Ok(result)
    }
    visit(plan, &mut HashMap::new(), &mut HashMap::new(), defer)
}
