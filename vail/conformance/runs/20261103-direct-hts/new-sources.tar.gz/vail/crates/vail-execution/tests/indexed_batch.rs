use arrow_array::{Array, Int32Array, ListArray, StructArray};
use std::sync::Arc;
use vail_execution::expressions::{ArrayReduction, Expr, Type, lower, project_batch};

#[path = "common/indexed_batch.rs"]
mod fixture;
use fixture::*;

#[test]
fn nested_selection_preserves_missing_entries_lists_and_callback_captures() {
    let (batch, expression) = fixture([1, -1], true, 8);
    let output = project_batch(&batch, &[("result".into(), expression.clone())]).unwrap();
    let lists = output
        .column(0)
        .as_any()
        .downcast_ref::<ListArray>()
        .unwrap();
    let values = lists
        .values()
        .as_any()
        .downcast_ref::<StructArray>()
        .unwrap();
    assert_eq!(
        values
            .column(1)
            .as_any()
            .downcast_ref::<Int32Array>()
            .unwrap(),
        &Int32Array::from(vec![Some(1), None, None, Some(93)])
    );
    assert_eq!(
        values
            .column(2)
            .as_any()
            .downcast_ref::<Int32Array>()
            .unwrap(),
        &Int32Array::from(vec![Some(10), Some(20), None, Some(40)])
    );
    let selected = values
        .column(0)
        .as_any()
        .downcast_ref::<ListArray>()
        .unwrap();
    assert_eq!(
        selected
            .iter()
            .map(|list| list.map(|list| list
                .as_any()
                .downcast_ref::<Int32Array>()
                .unwrap()
                .values()
                .to_vec()))
            .collect::<Vec<_>>(),
        vec![Some(vec![3, 4]), None, None, Some(vec![6])]
    );
    let sliced =
        project_batch(&batch.slice(1, 1), &[("result".into(), expression.clone())]).unwrap();
    assert_eq!(sliced.column(0).as_ref(), &lists.slice(1, 1) as &dyn Array);
    let empty = project_batch(&batch.slice(0, 0), &[("result".into(), expression)]).unwrap();
    assert_eq!(empty.num_rows(), 0);
}

#[test]
fn list_bounds_errors_only_observe_present_entries() {
    let (batch, expression) = fixture([1, 99], false, 8);
    let result = project_batch(&batch, &[("result".into(), expression)]).unwrap();
    assert_eq!(result.num_rows(), 2);
    let (batch, expression) = fixture([1, 99], true, 8);
    let error = project_batch(&batch, &[("result".into(), expression)]).unwrap_err();
    assert!(
        error.to_string().contains("array index out of bounds"),
        "{error}"
    );
}

#[test]
fn literal_slash_field_and_nested_field_are_distinct() {
    let (batch, mut expression) = fixture([1, -1], true, 8);
    let Expr::AlignedMatrixMap { body, dtype, .. } = &mut expression else {
        unreachable!()
    };
    let entry_type = Type::from_arrow(
        batch
            .column(0)
            .as_any()
            .downcast_ref::<ListArray>()
            .unwrap()
            .values()
            .data_type(),
    )
    .unwrap();
    let entry = field(input("entry", None, entry_type), "value");
    *body = Arc::new(Expr::ArrayReduce {
        operation: ArrayReduction::Sum,
        filter_missing: true,
        value: Arc::new(Expr::Array {
            elements: vec![field(entry.clone(), "a/b"), field(field(entry, "a"), "b")],
            element_type: int(),
        }),
    });
    *dtype = array(int());
    let output = lower(&expression, batch.schema().as_ref())
        .unwrap()
        .evaluate(&batch)
        .unwrap()
        .into_array(2)
        .unwrap();
    assert_eq!(
        output
            .as_any()
            .downcast_ref::<ListArray>()
            .unwrap()
            .values()
            .as_any()
            .downcast_ref::<Int32Array>()
            .unwrap(),
        &Int32Array::from(vec![Some(11), Some(22), None, Some(44)])
    );
}
