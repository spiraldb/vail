#!/bin/bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
BASE="$HOME/cloud-scan-20261023"
while [[ ! -f "$BASE/setup-complete" ]]; do
 if ! pgrep -f '^bash /home/danielking/setup-cloud-scan-20261023.sh$' >/dev/null; then echo 'Build stopped without success'; exit 1; fi
 sleep 5
done
mkdir -p "$BASE/data/hail" "$BASE/results"
OLD="$HOME/hail-benchmark-data-20261020-04cbaea"
for file in "$OLD"/*; do
 [[ $(basename "$file") == vail || $(basename "$file") == hail ]] && continue
 ln -s "$file" "$BASE/data/$(basename "$file")" 2>/dev/null || true
done
for file in "$OLD/hail"/*; do ln -s "$file" "$BASE/data/hail/$(basename "$file")" 2>/dev/null || true; done
find "$BASE/data" -type l -printf '%p -> %l\n' > "$BASE/results/fixture-links.txt"
export VAIL_BENCHMARK_UPSTREAM="$BASE/upstream/hail/python/benchmark/hail"
export VAIL_SOURCE_REVISION=e79cf6ffeb624756cc27769cd6031b0f12858651
export HAIL_BENCHMARK_CORES=32 HAIL_BENCHMARK_MEMORY=64g VAIL_BENCHMARK_MAX_RSS_GIB=96
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PYTHONPATH="$BASE/harness:$BASE/upstream/hail/python"
"$BASE/vail-env/bin/python" - <<'PY'
import hashlib,json,platform,subprocess,os,importlib.metadata
from pathlib import Path
import vail,psutil
base=Path.home()/'cloud-scan-20261023'
import vail._native as native
p=Path(native.__file__)
j=dict(source_commit=os.environ['VAIL_SOURCE_REVISION'],native_module=str(p),native_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),hail_version=subprocess.check_output([str(Path.home()/"hail-env/bin/python"),"-c","import hail; print(hail.__version__)"],text=True).strip(),vail_version=importlib.metadata.version('vail'),cpu=subprocess.check_output(['lscpu'],text=True),memory_bytes=psutil.virtual_memory().total,platform=platform.platform())
(base/'results'/'machine-provenance.json').write_text(json.dumps(j,indent=2))
PY
# A complete normal build is required before this process starts timed queries.
"$BASE/vail-env/bin/python" "$BASE/harness/test_adapter.py"
"$BASE/vail-env/bin/python" "$BASE/harness/run_scan.py" --data-dir "$BASE/data" --output-dir "$BASE/results/upstream" --hail-python "$HOME/hail-env/bin/python" --vail-python "$BASE/vail-env/bin/python" --repetitions 3 --timeout 250 --fixture-timeout 1800
 touch "$BASE/upstream-benchmarks-complete"
