"""One loader-only recovery of the already built wheel; no queries or rebuilds."""
import hashlib,json,os,platform,subprocess,time
from pathlib import Path
B=Path('/home/danielking/native-benchmark-20261112')
O=B/'results/runtime-recovery';O.mkdir(exist_ok=False)
assert (B/'bootstrap.exit').read_text().strip()=='1'
(O/'original-bootstrap.log').write_bytes((B/'bootstrap.log').read_bytes())
(O/'original-bootstrap.exit').write_bytes((B/'bootstrap.exit').read_bytes())
native=next((B/'vail-env/lib').glob('python*/site-packages/vail/_native.abi3.so'))
r=subprocess.run(['readelf','-lW',str(native)],capture_output=True,text=True,check=True,timeout=10)
(O/'readelf.txt').write_text(r.stdout)
env=os.environ.copy();env.pop('PYTHONPATH',None)
env['GLIBC_TUNABLES']='glibc.rtld.optional_static_tls=65536'
vail_code=r'''
from pathlib import Path
import json,hashlib,sys,os,platform,importlib.metadata
import vail,vail._native as n
b=Path('/home/danielking/native-benchmark-20261112');src=b/'source/vail/python/vail';package=Path(vail.__file__).parent
front={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest()for p in package.rglob('*.py')}
for p,h in front.items():assert hashlib.sha256((src/p).read_bytes()).hexdigest()==h,p
print(json.dumps({'python':sys.executable,'frontend':str(package),'frontend_sha256':front,'native_sha256':hashlib.sha256(Path(n.__file__).read_bytes()).hexdigest(),'native':n.__file__,'allocator':n._benchmark_allocator,'packages':sorted((x.metadata['Name'],x.version)for x in importlib.metadata.distributions()),'GLIBC_TUNABLES':os.environ['GLIBC_TUNABLES'],'glibc':platform.libc_ver()}))
'''
hail_code=r'''
from pathlib import Path
import json,hashlib,sys,os,platform,importlib.metadata
import hail
j=Path(hail.__file__).parent/'backend/hail-all-spark.jar';assert j.is_file()
print(json.dumps({'python':sys.executable,'version':hail.__version__,'jar':str(j),'jar_sha256':hashlib.sha256(j.read_bytes()).hexdigest(),'packages':sorted((x.metadata['Name'],x.version)for x in importlib.metadata.distributions()),'GLIBC_TUNABLES':os.environ['GLIBC_TUNABLES'],'glibc':platform.libc_ver()}))
'''
for name,code in [('vail',vail_code),('hail',hail_code)]:
 r=subprocess.run([str(B/(name+'-env')/'bin/python'),'-c',code],env=env,capture_output=True,text=True,timeout=60)
 (O/(name+'-stdout')).write_text(r.stdout);(O/(name+'-stderr')).write_text(r.stderr)
 if r.returncode:raise RuntimeError(name+' import failed; STOP before recovery')
 data=json.loads(r.stdout);(B/(name+'-ready.json')).write_text(json.dumps(data,indent=2)+'\n')
(B/'hardware.txt').write_text(subprocess.run(['lscpu'],capture_output=True,text=True,check=True,timeout=10).stdout)
# Freeze the exact installed distribution identities without requiring pip.
for name in ['vail','hail']:
 data=json.loads((B/(name+'-ready.json')).read_text());(B/(name+'-requirements.txt')).write_text('\n'.join(n+'=='+v for n,v in data['packages'])+'\n')
receipt={'same_installed_native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'original_bootstrap_exit':1,'loader_tunables':env['GLIBC_TUNABLES'],'glibc':platform.libc_ver(),'success':True,'no_rebuild':True,'no_query':True,'completed_unix':time.time()}
(O/'complete.json').write_text(json.dumps(receipt,indent=2)+'\n');(B/'runtime-ready.exit').write_text('0\n');print(json.dumps(receipt),flush=True)
