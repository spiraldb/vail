"""Prepare exact-size Hail fixtures, then native copies, outside timed actions."""
from pathlib import Path
import hashlib,json,os,sys,struct,math
BASE=Path('/home/danielking/native-benchmark-20261112');HERE=BASE/'protocol';DATA=BASE/'data'
os.environ['VAIL_BENCHMARK_UPSTREAM']=str(HERE/'upstream')
sys.path.insert(0,str(HERE))
import upstream_benchmark_coverage as coverage
kind=sys.argv[1];out=BASE/'results'/('fixtures-'+kind);out.mkdir(parents=True,exist_ok=False)
plan=json.loads((HERE/'fixture-plan.json').read_text())

def canonical(x):
 if x is None or isinstance(x,(str,bool,int)):return x
 if isinstance(x,float):return {'float':x.hex() if not math.isnan(x)else'nan'}
 if isinstance(x,(list,tuple)):return [canonical(v)for v in x]
 if isinstance(x,(set,frozenset)):
  return {'set':sorted((canonical(v)for v in x),key=lambda v:json.dumps(v,sort_keys=True,ensure_ascii=True))}
 if isinstance(x,dict):
  pairs=[[canonical(k),canonical(v)]for k,v in x.items()]
  return {'dict':sorted(pairs,key=lambda pair:json.dumps(pair[0],sort_keys=True,ensure_ascii=True))}
 if hasattr(x,'contig')and hasattr(x,'position'):return {'locus':[x.contig,int(x.position),x.reference_genome.name]}
 if hasattr(x,'ploidy')and hasattr(x,'phased'):return {'call':[[int(x[i])for i in range(x.ploidy)],bool(x.phased)]}
 if hasattr(x,'items'):return {'struct':{k:canonical(v)for k,v in x.items()}}
 if hasattr(x,'item'):return canonical(x.item())
 raise TypeError(type(x).__name__)

def observation(hl,path):
 obj=hl.read_table(str(path))if path.suffix=='.ht'else hl.read_matrix_table(str(path))
 if path.suffix=='.ht':count=obj.count();prefix=obj.take(3)
 else:count=list(obj.count());prefix=obj.head(3,3).entries().take(9)
 return {'count':count,'partitions':obj.n_partitions(),'prefix':canonical(prefix)}

if kind=='hail':
 import hail as hl
 hl.init(master='local[32]',quiet=True,global_seed=20261112,log=str(out/'hail.log'),tmp_dir=str(BASE/'hail-tmp'),spark_conf={'spark.driver.memory':'16g','spark.executor.memory':'16g','spark.ui.enabled':'false'})
 try:
  completed=[]
  for group in plan:
   paths=coverage._make_original_exact_fixtures(hl,'hail',group['names'],DATA,group['parameters'])
   manifest=coverage._fixture_manifest(DATA,group['names'],group['parameters']);assert manifest.stem==group['key']
   manifest.parent.mkdir(parents=True,exist_ok=True);manifest.write_text(json.dumps({'paths':paths,'origin':'fresh Hail-generated/public upstream files','parameters':group['parameters'],'global_seed':20261112},indent=2)+'\n')
   completed.append({'key':group['key'],'manifest':str(manifest),'paths':paths});(out/'progress.json').write_text(json.dumps(completed,indent=2)+'\n');print('HAIL_FIXTURE',len(completed),len(plan),group['names'],flush=True)
  paths=sorted({raw for group in completed for value in group['paths'].values()for raw in(value if isinstance(value,list)else[value])if raw!='__worker_temporary__'and Path(raw).suffix in ['.ht','.mt']})
  observations={raw:observation(hl,Path(raw))for raw in paths}
  (out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
 finally:hl.stop()
elif kind=='native':
 import vail as hl
 reference=json.loads((BASE/'results/fixtures-hail/observations.json').read_text());done=[]
 for raw,expected in reference.items():
  source=Path(raw);target=DATA/'vail-from-hail'/source.relative_to(DATA/'hail');target.parent.mkdir(parents=True,exist_ok=True)
  obj=hl.Table.read_legacy(raw)if source.suffix=='.ht'else hl.MatrixTable.read_legacy(raw)
  obj.write(str(target))
  actual=observation(hl,target)
  if actual['count']!=expected['count']or actual['prefix']!=expected['prefix']:raise RuntimeError('Native logical count/prefix mismatch: '+raw)
  done.append({'source':raw,'target':str(target),'source_observation':expected,'native_observation':actual});(out/'progress.json').write_text(json.dumps(done,indent=2)+'\n');print('NATIVE_FIXTURE',len(done),len(reference),target,flush=True)
 (out/'observations.json').write_text(json.dumps(done,indent=2)+'\n')
else:raise ValueError(kind)
(out/'complete.json').write_text(json.dumps({'kind':kind,'complete':True,'scope':'Original upstream fixture sizes; fresh seed20261112; full counts and small logical prefixes compared, not full-data equality; native partition/layout differences retained'})+'\n')
