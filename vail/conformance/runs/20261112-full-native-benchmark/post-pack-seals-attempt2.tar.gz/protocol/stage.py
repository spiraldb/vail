"""Bound one setup/benchmark phase and seal only its completed evidence."""
import argparse,hashlib,json,os,signal,sys,tarfile,time
from pathlib import Path
BASE=Path('/home/danielking/native-benchmark-20261112-attempt2');HERE=BASE/'protocol';ENV_BASE=Path('/home/danielking/native-benchmark-20261112')
p=argparse.ArgumentParser();p.add_argument('stage',choices=['fixtures-hail','fixtures-native','enroll','enroll-sidecars','preflight','rep1','rep2','rep3','final']);a=p.parse_args()
for name,h in json.loads((HERE/'ASSETS.json').read_text()).items():
 if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=h:raise RuntimeError('Protocol changed:'+name)
os.chdir(BASE)
os.environ.update(GLIBC_TUNABLES='glibc.rtld.optional_static_tls=16384',PATH='/home/danielking/.cargo/bin:/home/danielking/.local/bin:'+os.environ.get('PATH','/usr/bin:/bin'),JAVA_HOME='/usr/lib/jvm/java-11-openjdk-amd64',SPARK_LOCAL_IP='127.0.0.1',RAYON_NUM_THREADS='32',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',HAIL_BENCHMARK_CORES='32',HAIL_BENCHMARK_MEMORY='16g',VAIL_BENCHMARK_MAX_RSS_GIB='96')
for k in list(os.environ):
 if k=='PYTHONPATH' or k.startswith(('VAIL_EXPERIMENT_','VAIL_DISABLE_','VAIL_TRACE_')):os.environ.pop(k)
results=BASE/'results';results.mkdir(exist_ok=True);supervisor=results/(a.stage+'-supervisor');supervisor.mkdir(exist_ok=False)
py=ENV_BASE/('hail-env'if a.stage=='fixtures-hail'else'vail-env')/'bin/python';cap = 7200 if a.stage.startswith('rep') else 3600
if a.stage in ['fixtures-hail','fixtures-native']:command=[str(py),str(HERE/'fixtures.py'),a.stage.split('-',1)[1]]
else:
 if (BASE/'runtime-ready.exit').read_text().strip()!='0':raise RuntimeError('Normal build not successfully complete')
 lock={'current':json.loads((BASE/'vail-ready.json').read_text()),'hail':json.loads((BASE/'hail-ready.json').read_text())}
 assert all(v['GLIBC_TUNABLES']==os.environ['GLIBC_TUNABLES'] for v in lock.values())
 expected=BASE/'artifact-lock.json'
 if expected.exists():
  if json.loads(expected.read_text())!=lock:raise RuntimeError('Runtime artifact identity changed')
 else:expected.write_text(json.dumps(lock,indent=2)+'\n')
 if a.stage in ['enroll','enroll-sidecars']:command=[str(py),str(HERE/'enroll.py'),'--out',str(results/'enrollment.json')]
 elif a.stage=='final':command=[str(py),str(HERE/'enroll.py'),'--out',str(results/'final-enrollment.json'),'--check',str(results/'enrollment.json'),'--full']
 else:command=[str(py),str(HERE/'phase.py'),'--phase',a.stage,'--out',str(results/a.stage),'--enrollment',str(results/'enrollment.json')]
from owned import execute
started=time.monotonic();success=False
try:
 receipt,text=execute(command,supervisor/'command',cap,deadline=time.monotonic()+cap+30)
 if receipt['error']or receipt['returncode']!=0 or not receipt['owned_group_clean']:raise RuntimeError('Stage failed; provider STOP before recovery:'+json.dumps(receipt))
 archive=BASE/(a.stage+'.tar.gz');files=list(supervisor.rglob('*'))
 if a.stage in ['enroll','enroll-sidecars']:files +=[BASE/'artifact-lock.json',results/'enrollment.json',BASE/'hardware.txt',BASE/'source-lock.json',BASE/'vail-ready.json',BASE/'hail-ready.json',BASE/'bootstrap.log',BASE/'vail-requirements.txt',BASE/'hail-requirements.txt']
 elif a.stage=='final':files +=[results/'final-enrollment.json']
 else:files +=list((results/a.stage).rglob('*'))
 with tarfile.open(archive,'w:gz')as t:
  total=0
  for f in files:
   if not f.is_file():continue
   total+=f.stat().st_size
   if total>1024**3:raise RuntimeError('1GiB evidence cap')
   t.add(f,arcname=str(f.relative_to(BASE)),recursive=False)
 packed={'stage':a.stage,'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'seconds':time.monotonic()-started};(results/(a.stage+'-packed.json')).write_text(json.dumps(packed)+'\n');success=True;print(json.dumps(packed),flush=True)
finally:(supervisor/'result.json').write_text(json.dumps({'success':success,'seconds':time.monotonic()-started})+'\n')
