"""Full runtime initialization gate for the unchanged normal installed artifacts."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
from owned import execute
B=Path('/home/danielking/native-benchmark-20261112-attempt2')
ORIGINAL=Path('/home/danielking/native-benchmark-20261112')
out=B/'results/runtime-gate';out.mkdir(parents=True,exist_ok=False)
os.environ.update(GLIBC_TUNABLES='glibc.rtld.optional_static_tls=16384',JAVA_HOME='/usr/lib/jvm/java-11-openjdk-amd64',SPARK_LOCAL_IP='127.0.0.1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
os.environ.pop('PYTHONPATH',None)
codes={
'vail':r'''
from pathlib import Path
import json,hashlib,sys,os,platform,importlib.metadata
import vail,vail._native as n
b=Path('/home/danielking/native-benchmark-20261112');src=b/'source/vail/python/vail';package=Path(vail.__file__).parent
front={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest()for p in package.rglob('*.py')}
for p,h in front.items():assert hashlib.sha256((src/p).read_bytes()).hexdigest()==h,p
print('IDENTITY '+json.dumps({'python':sys.executable,'frontend':str(package),'frontend_sha256':front,'native_sha256':hashlib.sha256(Path(n.__file__).read_bytes()).hexdigest(),'native':n.__file__,'allocator':n._benchmark_allocator,'packages':sorted((x.metadata['Name'],x.version)for x in importlib.metadata.distributions()),'GLIBC_TUNABLES':os.environ['GLIBC_TUNABLES'],'glibc':platform.libc_ver()}))
''',
'hail':r'''
from pathlib import Path
import json,hashlib,sys,os,platform,importlib.metadata
import hail as hl
b=Path('/home/danielking/native-benchmark-20261112-attempt2')
hl.init(master='local[32]',quiet=True,log=str(b/'results/runtime-gate/hail.log'),tmp_dir=str(b/'hail-tmp'),spark_conf={'spark.driver.memory':'16g','spark.executor.memory':'16g','spark.ui.enabled':'false'})
try:
 print('INITIALIZED '+hl.__version__,flush=True)
finally:hl.stop()
print('STOPPED',flush=True)
j=Path(hl.__file__).parent/'backend/hail-all-spark.jar';assert j.is_file()
print('IDENTITY '+json.dumps({'python':sys.executable,'version':hl.__version__,'jar':str(j),'jar_sha256':hashlib.sha256(j.read_bytes()).hexdigest(),'packages':sorted((x.metadata['Name'],x.version)for x in importlib.metadata.distributions()),'GLIBC_TUNABLES':os.environ['GLIBC_TUNABLES'],'glibc':platform.libc_ver()}))
'''}
for name,code in codes.items():
 command=[str(ORIGINAL/(name+'-env')/'bin/python'),'-c',code]
 receipt,text=execute(command,out/name,120)
 if receipt['error']or receipt['returncode']!=0 or not receipt['owned_group_clean']:raise RuntimeError('Runtime gate failed; provider STOP first: '+json.dumps(receipt))
 identities=[json.loads(line.removeprefix('IDENTITY '))for line in text.splitlines()if line.startswith('IDENTITY ')]
 assert len(identities)==1
 if name=='hail':assert 'INITIALIZED 'in text and'STOPPED'in text
 (B/(name+'-ready.json')).write_text(json.dumps(identities[0],indent=2)+'\n')
for name in ['source-lock.json','source-manifest.json','hardware.txt','vail-requirements.txt','hail-requirements.txt']:
 (B/name).write_bytes((ORIGINAL/name).read_bytes())
receipt={'success':True,'same_installed_native_sha256':json.loads((B/'vail-ready.json').read_text())['native_sha256'],'loader_tunables':os.environ['GLIBC_TUNABLES'],'hail_initialized_and_stopped':True,'no_query':True,'no_rebuild':True,'completed_unix':time.time()}
(out/'complete.json').write_text(json.dumps(receipt,indent=2)+'\n');(B/'runtime-ready.exit').write_text('0\n');print(json.dumps(receipt),flush=True)
