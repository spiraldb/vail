from pathlib import Path
import subprocess,os,json,statistics,hashlib
r=Path('/private/tmp/vail-entry-selection-20261102');py='/Users/danielking/projects/vail/vail/.venv/bin/python'
env=os.environ.copy();env.update(PYTHONPATH=str(r/'package-4'),RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.pop('VAIL_EXPERIMENT_REE_STATS',None)
for flag in [0,1]:
 e=env.copy();e.pop('VAIL_DIAGNOSTIC_SELECTED_ALIGNED',None)
 if flag:e['VAIL_DIAGNOSTIC_SELECTED_ALIGNED']='1'
 with (r/f'final-oracle-{flag}.json').open('w') as out,(r/f'final-oracle-{flag}.stderr').open('w') as err:
  p=subprocess.run(['nice','-n','10',py,'/private/tmp/vail-split-fundamental-20261030/oracles.py'],env=e,stdout=out,stderr=err,timeout=120)
 print('oracle',flag,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
assert json.loads((r/'final-oracle-0.json').read_text())==json.loads((r/'final-oracle-1.json').read_text())
for case in ['split-real','split-many','empty','one','short','wide']:
 for run,flag in enumerate([0,1,1,0]):
  e=env.copy();e.pop('VAIL_DIAGNOSTIC_SELECTED_ALIGNED',None)
  if flag:e['VAIL_DIAGNOSTIC_SELECTED_ALIGNED']='1'
  with (r/f'{case}-{run}-{flag}.jsonl').open('w') as out,(r/f'{case}-{run}-{flag}.stderr').open('w') as err:
   p=subprocess.run(['nice','-n','10',py,str(r/'probe.py'),case],env=e,stdout=out,stderr=err,timeout=120)
  print(case,run,flag,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
summary={}
for case in ['split-real','split-many','empty','one','short','wide']:
 by_flag={0:[],1:[]}
 for run,flag in enumerate([0,1,1,0]):
  rows=[json.loads(x) for x in (r/f'{case}-{run}-{flag}.jsonl').read_text().splitlines()];samples=[x for x in rows if 'sample' in x]
  assert len(samples)==7
  by_flag[flag].append({metric:statistics.median(x[metric] for x in samples) for metric in ['wall','cpu']})
 summary[case]={'process_medians':by_flag,'candidate_over_baseline':{m:statistics.median(x[m] for x in by_flag[1])/statistics.median(x[m] for x in by_flag[0]) for m in ['wall','cpu']}}
(r/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
