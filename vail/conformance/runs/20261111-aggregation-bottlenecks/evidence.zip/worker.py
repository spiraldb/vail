from pathlib import Path
from types import SimpleNamespace
import ast,ctypes,hashlib,json,os,resource,sys,time
import vail as hl,vail._native as native
root=Path('/private/tmp/vail-multi-sink-bench-20261111');r=Path('/private/tmp/vail-rowwise-hardware-20261111');case=sys.argv[1];out=Path(sys.argv[2]);pins=json.loads((root/'pins.json').read_text());ready=json.loads((root/'revision8/ready.json').read_text());spec=json.loads((root/'cases.json').read_text())[case]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(native.__file__)==ready['identity']['sha256'];source=root/spec['source'];assert sha(source)==pins['source_sha256'][spec['source']]
fns=[];tree=ast.parse(source.read_text())
for wanted in spec.get('helpers',[])+[spec['function']]:
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==wanted);fn.decorator_list=[];fns.append(fn)
m=ast.Module(body=fns,type_ignores=[]);ast.fix_missing_locations(m);api=SimpleNamespace(**vars(hl))
if spec['reader']=='legacy':api.read_matrix_table=hl.MatrixTable.read_legacy
ns={'hl':api};exec(compile(m,str(source),'exec'),ns);query=ns[spec['function']];fixture=pins['fixtures'][spec['fixture']]['root']
fields=json.loads((r/'rusage-v4-fields.json').read_text())
class Info(ctypes.Structure):_fields_=[('ri_uuid',ctypes.c_uint8*16)]+[(f,ctypes.c_uint64)for f in fields]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True);lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
samples=[]
def snap():
 i=Info();ret=lib.proc_pid_rusage(os.getpid(),4,ctypes.byref(i))
 if ret:raise OSError(ctypes.get_errno(),'proc_pid_rusage')
 u=resource.getrusage(resource.RUSAGE_SELF)
 return {'rusage_v4':{f:int(getattr(i,f))for f in fields},'posix':{k:getattr(u,k)for k in ['ru_utime','ru_stime','ru_minflt','ru_majflt','ru_inblock','ru_oublock','ru_nvcsw','ru_nivcsw']}}
assert query(fixture)is None
for n in range(3):
 before=snap();start=time.perf_counter();assert query(fixture)is None;wall=time.perf_counter()-start;after=snap();delta={group:{k:after[group][k]-v for k,v in d.items()}for group,d in before.items()};cpu=delta['posix']['ru_utime']+delta['posix']['ru_stime'];v=delta['rusage_v4'];row={'wall_seconds':wall,'cpu_seconds':cpu,'average_busy_cores':cpu/wall,'delta':delta,'before':before,'after':after,'ipc':v['ri_instructions']/v['ri_cycles']if v['ri_cycles'] else None};samples.append(row);print(json.dumps(row),flush=True)
(out/'result.json').write_text(json.dumps({'case':case,'source':ready['source'],'native_sha256':sha(native.__file__),'spec':spec,'samples':samples,'scope':'Frozen numeric checkpoint; original AST/action,1warmup3diagnostic actions. OS rusage counters process only; not wall comparison or hardware saturation proof. Global system activity not attributed.'},indent=2))
