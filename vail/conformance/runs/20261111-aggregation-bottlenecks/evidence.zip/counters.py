from pathlib import Path
import os,json,sys,shutil,hashlib
root=Path('/private/tmp/vail-multi-sink-bench-20261111');sys.path.insert(0,str(root));from owned import run
r=Path(__file__).parent;ready=json.loads((root/'revision8/ready.json').read_text());e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc',RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
out=r/'counter-worker';out.mkdir()
command=['nice','-n','10','/usr/bin/xctrace','record','--no-prompt','--template','CPU Counters','--time-limit','15s','--output',str(r/'cpu-counters.trace'),'--launch','--',ready['python'],str(r/'worker.py'),'many_row_hail',str(out)]
receipt=run(command,r/'xctrace',e,90)
(r/'counter-receipt.json').write_text(json.dumps(receipt,indent=2));print('COUNTERS COMPLETE')
