from pathlib import Path
import xml.etree.ElementTree as E,json,collections,hashlib
r=Path(__file__).parent;root=E.parse(r/'aggregated-counters.xml').getroot();refs={e.attrib['id']:e for e in root.iter()if'id'in e.attrib}
def resolve(e):
 while'ref'in e.attrib:e=refs[e.attrib['ref']]
 return e
node=list(root)[1];intervals={};docs={}
for row in node.findall('row'):
 cells=[resolve(e)for e in row]
 t,dur,metric,label,thread,process,value,core,percent,doc=cells
 key=(int(t.text),int(dur.text),thread.attrib['id'],int(core.text));a=intervals.setdefault(key,{})
 assert metric.text not in a
 a[metric.text]=float(value.text)
 if doc.tag=='markdown-text':docs[metric.text]=' '.join(resolve(e).text or ''for e in doc if resolve(e).tag=='string')
sums=collections.defaultdict(lambda:collections.Counter());counts=collections.Counter();durations=collections.Counter()
for (t,d,thread,core),v in intervals.items():
 assert set(v)=={'cycle','delivery','discarded','processing','useful'},v
 assert abs(sum(v[k]for k in v if k!='cycle')-1)<1e-6
 if v['cycle']<=0:continue
 for group in ['all','E'if core<4 else'P']:
  counts[group]+=1;durations[group]+=d
  for k,x in v.items():sums[group][k]+=x if k=='cycle'else x*v['cycle']
result={'scope':'Entiretarget CPUcounter trace includesimport,onewarmup,threeoriginalactions. Not a warm-only/action-phase sample.','definitions':docs,'groups':{g:{'intervals':counts[g],'observed_interval_nanoseconds':durations[g],'cycles':v['cycle'],'cycle_weighted_percent':{k:100*x/v['cycle']for k,x in v.items()if k!='cycle'}}for g,v in sums.items()},'method':'MetricTable per-thread/core nonoverlapping recorded hardware-counter intervals; resolveXMLrefIDs, paireachfractionwithitsowncyclecount, verifyfourfractions sum1, weightbycycles. P/E splitfromtrace CPU0–3E,4–13P. NativeApple topdown categories do not measureDRAMGB/s orfloatingpointFLOPS; mixedcore global weighting not a peakperformancepercentage.','source_sha256':hashlib.sha256((r/'aggregated-counters.xml').read_bytes()).hexdigest()}
(r/'validated-counter-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['groups'],indent=2))
