from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,os,sys,time
import vail as hl,vail._native as native
r=Path(sys.argv[1]);root=Path('/private/tmp/vail-multi-sink-bench-20261111');pins=json.loads((root/'pins.json').read_text());ready=json.loads((r/'ready.json').read_text());mode='profile'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(native.__file__)==ready['identity']['sha256'];source=root/'benchmark_matrix_table.py';assert sha(source)==pins['source_sha256']['benchmark_matrix_table.py']
name='test_matrix_table_many_aggs_row_wise';tree=ast.parse(source.read_text());fns=[]
for wanted in ['many_aggs',name]:
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==wanted);fn.decorator_list=[];fns.append(fn)
m=ast.Module(body=fns,type_ignores=[]);ast.fix_missing_locations(m);api=SimpleNamespace(**vars(hl));ns={'hl':api};exec(compile(m,str(source),'exec'),ns);query=ns[name];fixture=pins['fixtures']['native_profile']['root']
meta={'mode':mode,'native_sha256':sha(native.__file__),'fixture':fixture,'source_sha256':sha(source),'source':ready['source'],'scope':'Exact original many_aggs+rowwise benchmark; diagnostics only, separate from matched timings'}
if mode=='trace':
 t=time.perf_counter();cpu=time.process_time();assert query(fixture)is None;meta.update(wall=time.perf_counter()-t,cpu=time.process_time()-cpu)
elif mode=='profile':
 assert query(fixture)is None
 start=time.monotonic();warm=time.time();cpu=time.process_time();calls=0
 while time.monotonic()-start<6:
  assert query(fixture)is None;calls+=1
 meta.update(warm_epoch=warm,end_epoch=time.time(),loop_wall=time.monotonic()-start,loop_cpu=time.process_time()-cpu,repeated_calls=calls)
else:
 assert mode=='decompose'
 # Same original AST, except return the receiver of its final force-count call.
 construct=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef)and n.name==name);construct.decorator_list=[];construct.name='construct';last=construct.body[-1];assert isinstance(last,ast.Expr)and isinstance(last.value,ast.Call)and last.value.func.attr=='_force_count';construct.body[-1]=ast.Return(value=last.value.func.value);m=ast.Module(body=[construct],type_ignores=[]);ast.fix_missing_locations(m);exec(compile(m,str(source),'exec'),ns)
 assert query(fixture)is None
 samples=[]
 for i in range(3):
  c=time.process_time();t=time.perf_counter();table=ns['construct'](fixture);frontwall=time.perf_counter()-t;frontcpu=time.process_time()-c
  c=time.process_time();t=time.perf_counter();count=table._force_count();actionwall=time.perf_counter()-t;actioncpu=time.process_time()-c;assert count==24885
  samples.append({'frontend_wall':frontwall,'frontend_cpu':frontcpu,'action_wall':actionwall,'action_cpu':actioncpu})
 prepared=[]
 for i in range(3):
  c=time.process_time();t=time.perf_counter();assert table._force_count()==24885;prepared.append({'wall':time.perf_counter()-t,'cpu':time.process_time()-c})
 meta.update(samples=samples,prepared_same_table=prepared,scope=meta['scope']+'; decomposition and repeated prepared logical-table are separate diagnostic actions, not original lifecycle timings. Force_count includes physical preparation each call.')
(r/(mode+'-result.json')).write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2),flush=True)
