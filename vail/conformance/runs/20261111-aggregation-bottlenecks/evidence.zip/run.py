from pathlib import Path
import os,json,sys,shutil,hashlib
root=Path('/private/tmp/vail-multi-sink-bench-20261111');sys.path.insert(0,str(root));from owned import run
r=Path(__file__).parent;ready=json.loads((root/'revision8/ready.json').read_text());e={k:v for k,v in os.environ.items()if not k.startswith(('VAIL_','MIMALLOC_','MALLOC_','JEMALLOC_','_RJEM_','Malloc'))and k not in ['PYTHONPATH','DYLD_INSERT_LIBRARIES','LD_PRELOAD']};e.update(PYTHONMALLOC='default',ARROW_DEFAULT_MEMORY_POOL='mimalloc',RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
receipts=[]
for case in ['many_row_hail','many_row_native','sex_qc_hail']:
 assert shutil.disk_usage(r).free>5*1024**3
 receipts.append(run(['nice','-n','10',ready['python'],str(r/'worker.py'),case,str(r/case)],r/case,e,120))
(r/'receipts.json').write_text(json.dumps(receipts,indent=2));print('DIAGNOSTIC COMPLETE')
