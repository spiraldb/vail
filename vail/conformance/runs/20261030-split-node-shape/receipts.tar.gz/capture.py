import os,json,sys,subprocess,time,hashlib,resource
from pathlib import Path
r=Path('/private/tmp/vail-split-node-shape-20261030');fixture=Path('/private/tmp/vail-split-fundamental-20261030/profile-first-200.mt')
if len(sys.argv)>1:
 import vail as hl
 action,mode=sys.argv[1:];out=Path(os.environ['VAIL_TRACE_PLAN_DIR']);mt=hl.read_matrix_table(str(fixture));split=hl.split_multi_hts(mt,**({} if mode=='default' else {'permit_shuffle':True}))
 (out/'unbound-logical-explain.txt').write_text(split._mir.core._native.logical_plan())
 if action=='force':
  result=split._force_count_rows();assert result==204;summary={'rows':result}
 else:
  result=split.localize_entries('entries','columns').collect();assert len(result)==204;assert all(len(row.entries)==2535 for row in result)
  summary={'rows':len(result),'entry_slots':sum(len(row.entries) for row in result),'defined_entries':sum(e is not None for row in result for e in row.entries),'first_row':{'position':result[0].locus.position,'alleles':result[0].alleles}}
 summary.update(action=action,mode=mode,fixture=str(fixture),source='5ac7ae023+diagnostic-only-hooks',threads=4,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
 (out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
else:
 import psutil
 env=os.environ.copy();env.update(PYTHONPATH=str(r/'package'),RAYON_NUM_THREADS='4',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 for action,mode in [('force','default'),('force','shuffle'),('collect','default')]:
  out=r/f'{action}-{mode}';out.mkdir(exist_ok=False);e=env.copy();e['VAIL_TRACE_PLAN_DIR']=str(out)
  with (out/'stdout').open('w') as o,(out/'stderr').open('w') as err:
   p=subprocess.Popen(['nice','-n','10','/Users/danielking/projects/vail/vail/.venv/bin/python',__file__,action,mode],env=e,stdout=o,stderr=err)
   try:
    end=time.monotonic()+90
    while p.poll() is None:
     if time.monotonic()>end:raise TimeoutError('capture90s')
     try:
      if psutil.Process(p.pid).memory_info().rss>4*1024**3:raise RuntimeError('captureRSS4GiB')
     except psutil.NoSuchProcess:pass
     if sum(x.stat().st_size for x in out.iterdir() if x.is_file())>64*1024**2:raise RuntimeError('trace64MiB')
     time.sleep(.1)
    assert p.returncode==0,(out/'stderr').read_text()[-4000:]
   finally:
    if p.poll() is None:p.kill();p.wait()
  print(action,mode,'CAPTURED',flush=True)
